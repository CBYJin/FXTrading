"use strict";

// Unpkg imports
const Web3Modal = window.Web3Modal.default;
const WalletConnectProvider = window.WalletConnectProvider.default;
const EvmChains = window.EvmChains;

// Web3modal instance
let web3Modal;

// wallet provider instance
let provider;
let web3;

const contractAddress = "0xe79C340BD8A17B1D48b17564B9C69255925D1Df0";
var spAccount = '';
var ownerAddress;
var defaultAccount;
var prevAccount;
var contract;

var balance_bnb = 0;
var contract_balance;
var contract_deposits;
var contract_payouts;
var contract_rebates;
var contract_rewards;
var contract_refunds;

var activeDeposits = 0;
var deposits_count = 0;
var dividends = 0;
var last_payout = 0;
var next_payout = 0;

var structure;
const deptime = [];
const depend = [];
const depamount = [];
var yieldsTicker = 0;
const tarifs = [];

var appPath = '';

function init() {
    console.log("WalletConnectProvider is", WalletConnectProvider);

    const providerOptions = {
        walletconnect: {
            package: WalletConnectProvider,
            options: {
                infuraId: "d6075d6a8fb244ffa2637028fd666244", //update infura key
            },
            chains: [56]
        },
    };

    web3Modal = new Web3Modal({
        cacheProvider: true, // optional
        providerOptions, // required
    });

}

/**
 * UI action after Web3modal dialog has chosen a provider
 */
async function fetchAccountData() {
    // Get a Web3 instance for the wallet
    web3 = new Web3(provider);
    console.log("Web3 instance is", web3);

    const accounts = await web3.eth.getAccounts();
    defaultAccount = accounts[0];


    if (defaultAccount !== '') {
        $('#my-wallet').val(defaultAccount);
        console.log("defaultAccount: " + $('#my-wallet').val());
        $('#wallet-status').html('<strong>CONNECTED</strong>');
        console.log('Wallet Connected!');
    }

    await loadContract();
    await loadAccount(defaultAccount);
}

async function loadContract() {
    contract = new web3.eth.Contract(contractABI, contractAddress);
    console.log('Contract Loaded: ' + contract);

    await contract.methods.dev().call().then(function(result) {
        ownerAddress = result;
        console.log('Owner: ' + ownerAddress);
    });

    await contract.methods.getBalance().call().then(function(result) {
        contract_balance = parseFloat(web3.utils.fromWei(result, 'ether')).toFixed(4);
        $('#contract-balance-usdt').html(contract_balance + ' BNB');
        console.log('Contract Balance: ' + contract_balance);
    });

    await contract.methods.contractInfo().call().then(function(results) {
        /*
		2:uint256: _refunded 0
		4:uint256: _rb 0
		*/
        contract_deposits = parseFloat(web3.utils.fromWei(results[0], 'ether')).toFixed(4);
        contract_payouts = parseFloat(web3.utils.fromWei(results[1], 'ether')).toFixed(4);
        contract_rewards = parseFloat(web3.utils.fromWei(results[3], 'ether')).toFixed(4);

        $('#contract-deposits-usdt').html(contract_deposits + ' BNB');
        $('#contract-payouts-usdt').html(contract_payouts + ' BNB');
        $('#contract-rewards-usdt').html(contract_rewards + ' BNB');

        console.log('Contract Deposits: ' + contract_deposits);
        console.log('Contract Payouts: ' + contract_payouts);
        console.log('Contract Rewards: ' + contract_rewards);

    });


}

async function loadAccount(wallet) {
    let myBNB = await web3.eth.getBalance(wallet);
    balance_bnb = parseFloat(web3.utils.fromWei(myBNB, 'ether'));
    myBNB = parseFloat(balance_bnb).toFixed(8).toLocaleString("en-US");
    $('#my-balance-bnb').html(myBNB + ' BNB');
    console.log('My BNB: ' + balance_bnb);

    await contract.methods.memberStats(wallet).call().then(function(results) {
        dividends = parseFloat(web3.utils.fromWei(results[5], 'ether')).toFixed(4);
        $('#yields').html(dividends);
        $('#txtdividends').val(dividends);
        let deposit = parseFloat(web3.utils.fromWei(results[0], 'ether')).toFixed(4);
        $('#my-deposits').html(deposit + ' BNB');
        $('#my-payouts').html(parseFloat(web3.utils.fromWei(results[1], 'ether')).toFixed(4) + ' BNB');
        $('#my-commissions').html(parseFloat(web3.utils.fromWei(results[3], 'ether')).toFixed(4) + ' BNB');
        $('#my-rebates').html(parseFloat(web3.utils.fromWei(results[2], 'ether')).toFixed(4) + ' BNB');

        if (deposit > 0) {
            $('#txtreferral').val(appPath + 'index.php?r=' + wallet);
        }
    });

    const ttype = ["BASIC", "VIP"];

    await contract.methods.players(wallet).call().then(function(results) {

        $('#ttype').html(ttype[parseInt(results[8])])

    });

    await contract.methods.memberStruct(wallet).call().then(function(results) {
        if (results[0] != '0x0000000000000000000000000000000000000000') {
            spAccount = results[0];
        }

        deposits_count = results[1];
        structure = results[2];

    });

    console.log('Sponsor: ' + spAccount);
    $('#wallet-sponsor').html(truncateWallet(spAccount));
    //if(spAccount !== ''){
    //document.querySelector("#sp-wallet").innerHTML = '<a href="https://bscscan.com/address/'+spAccount+'" target="_blank">'+truncateWallet(spAccount)+'</a>';
    //}

    /*
	await contract.methods.nextWithdraw(wallet).call().then(function(result){ 
	    
	    next_payout = parseFloat(result);    
    	console.log('Next Payout: ' + next_payout);        
	    if(next_payout > 86400)
	    {
	        if(Date.now() > parseFloat(next_payout * 1000)){
    			//can withdraw
    			$('#payout-timer').hide();
		        document.getElementById("btn-withdraw").disabled = false;
		        document.getElementById("btn-reinvest").disabled = false;
		    
    			//$('#dateNextPayout').html('YOU CAN NOW WITHDRAW ANYTIME');
			
		    }else{
		
    	        var theDate = timeConverter(next_payout*1000);
    		
    	        console.log('Next Payout: ' + theDate);
    	        console.log('Next Payout: ' + timeDisplay(next_payout * 1000));
    		
    	    	$('#myFlipper').data('datetime',theDate);
    		    $('#myFlipper').flipper('init');
    		    $('#payout-timer').show();
    		    
    		    document.getElementById("btn-withdraw").disabled = true;
		        document.getElementById("btn-reinvest").disabled = true;
		        
		    }
		}else{
		    $('#payout-timer').hide();
		    document.getElementById("btn-withdraw").disabled = false;
		    document.getElementById("btn-reinvest").disabled = false;
		}
	    
	});	
    */


    $("#deposits-body").html('');

    if (deposits_count > 0) {
        const status = ['REFUND', 'REFUNDED'];
        var slink;
        activeDeposits = 0;
        for (let i = 0; i < deposits_count; i++) {
            await contract.methods.memberDeposit(wallet, i).call().then(function(result) {

                if (next_payout <= 691200 && i == 0) {
                    last_payout = parseFloat(result[0]);
                    next_payout = last_payout + next_payout;
                }

                if (result[4] == 0) {
                    deptime[i] = parseFloat(result[0]);
                    depend[i] = deptime[i] + parseInt(result[2]) * 86400;
                    depamount[i] = parseFloat(parseFloat(parseFloat(result[1]) / 1e18)).toFixed(2);
                    activeDeposits++;
                    //if(last_payout > 0){
                    //    slink = '<a href="javascript:;" style="text-decoration:none;color:#ccc;">REFUND</a>';
                    //}else{
                    slink = '<a href="javascript:refund(' + i + ');" style="text-decoration:none;" class="btn btn-success">REFUND</a>';
                    //}
                } else {
                    slink = 'REFUNDED';
                }

                $("#deposits-body").append('<tr><td align="center" style="white-space:nowrap;">' + timeDisplay(parseFloat(result[0]) * 1000) + '</td>' +
                    '<td align="center" style="white-space:nowrap;">' + parseFloat(parseFloat(parseFloat(result[1]) / 1e18)).toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, '$1,') + ' BNB</td>' +
                    '<td align="center">' + result[2] + '</td>' +
                    '<td align="center" style="white-space:nowrap;">' + result[3] + '%</td>' +
                    '<td align="center">' + slink + '</td></tr>');

            });

        }

        if (activeDeposits > 0) {
            //yieldsTicker = setTimeout(updateYields, 1000); 
        }

    }



    let downlines = 0;
    let ctr = 1;
    let cnt = 0;
    $("#my-dl1").html('0');
    $("#my-dl2").html('0');
    $("#my-dl3").html('0');
    $("#my-dl4").html('0');
    $("#my-dl5").html('0');

    for (let i = 0; i < structure.length; i++) {
        downlines = structure[i];
        $("#my-dl" + (i + 1)).html(downlines);
    }

    var addresses = [];
    downlines = 0;
    ctr = 1;
    $("#downlines-body").html('');
    for (let i = 0; i < structure.length; i++) {
        downlines = structure[i];
        for (let j = 0; j < downlines; j++) {
            await contract.methods.memberDownline(wallet, i + 1, j).call().then(function(result) {
                addresses[ctr - 1] = result;
                $("#downlines-body").append('<tr><td align="center">' + ctr + '.</td><td><a href="https://bscscan.com/address/' + result + '" class="text-default" style="text-decoration:none;" target ="blank">' + truncateWallet(result) + '</a></td><td align="center">' + (i + 1) + '</td><td style="white-space: nowrap;text-align:right" id="j' + ctr + '">&nbsp;</td></tr>');
                ctr++;
            });
        }
    }

    for (let i = 0; i < addresses.length; i++) {
        await totalDeposit(i + 1, addresses[i]);
    }
    //console.log('DL: '+ cnt);

    //for(let i = 0; i < addresses.length; i++){
    //	await totalDeposit(i+1, addresses[i]);
    //}		


    //setTimeout(loadAccount(wallet), 180000);
}

async function totalDeposit(ctr, address) {
    await contract.methods.players(address).call().then(function(result) {
        var deposits = parseFloat(parseFloat(result[2]) / 1e18).toFixed(4).replace(/(\d)(?=(\d{3})+\.)/g, '$1,');
        $('#j' + ctr).html(deposits.toLocaleString("en-US") + ' BNB');
    });
}

function updateYields() {
    if (defaultAccount === '') {
        $('#my-dividends-usdt').html('0.00 BNB');
        return;
    }
    var rIndex = getRateIndex();
    var yields = 0;
    for (let i = 0; i < deptime.length; i++) {

        let from = last_payout > deptime[i] ? last_payout : deptime[i];
        let to = (Date.now() / 1000) > depend[i] ? depend[i] : (Date.now() / 1000);
        if (from < to) {
            yields += parseFloat(depamount[i]) * (parseFloat(to) - parseFloat(from)) * parseFloat(tarifs[rIndex].percentage) / parseFloat(tarifs[rIndex].days) / parseFloat(8640000);
        }
    }

    //$('#my-dividends-usdt').html(parseFloat(parseFloat(yields) + parseFloat(dividends_sukli) + parseFloat(commissions)).toFixed(4) + ' USDT');
    yieldsTicker = setTimeout(updateYields, 1000);
}

async function depositUSDT(amt) {
    if (!web3 || defaultAccount === '' || spAccount === '') {
        return false;
    }
    try {
        const sender = await contract.methods.Deposit(spAccount).send({
                from: defaultAccount,
                value: web3.utils.toWei(amt, "ether")
            })
            .then(function(result) {
                loadAccount(defaultAccount);
            }).catch(err => function() {
                console.log(err);
            });

    } catch (err) {
        console.log(err);
    }
}

async function withdrawUSDT(amt) {
    if (!web3 || defaultAccount === '') {
        return false;
    }
    try {
        const sender = await contract.methods.Withdraw(web3.utils.toWei(amt, "ether")).send({
                from: defaultAccount
            })
            .then(function(result) {
                loadAccount(defaultAccount);
            }).catch(err => function() {
                console.log(err);
            });
    } catch (err) {
        console.log(err);
    }

}


async function Refund(index) {
    if (!web3 || defaultAccount == '') {
        return false;
    }

    try {
        const sender = await contract.methods.Refund(index).send({
                from: defaultAccount
            })
            .then(function(result) {
                //loadContract();
                loadAccount(defaultAccount);
            }).catch(err => function() {
                console.log(err);
            });
    } catch (err) {
        console.log(err);
    }

}

function timeConverter(createdAt) {
    var date = new Date(createdAt);

    var year = date.getFullYear();
    var month = date.getMonth() + 1;
    var day = date.getDate();

    var hour = date.getHours();
    var minute = date.getMinutes();
    var second = date.getSeconds();

    //return year+"-"+month+"-"+day+" "+hour+":"+minute+":"+second;
    return [date.getFullYear(), (month > 9 ? '' : '0') + month, (day > 9 ? '' : '0') + day].join('-') + " " + [(hour > 9 ? '' : '0') + hour, (minute > 9 ? '' : '0') + minute, (second > 9 ? '' : '0') + second].join(':');

}

function timeDisplay(createdAt) {
    var date = new Date(createdAt);
    //date = convertTZ(date, "Asia/Taipei")
    //console.log(date);
    var mm = date.getMonth() + 1; // getMonth() is zero-based
    var dd = date.getDate();
    var dateFormat = [date.getFullYear(), (mm > 9 ? '' : '0') + mm, (dd > 9 ? '' : '0') + dd].join('-');
    var timeFormat = formatAMPM(date);
    return [dateFormat, timeFormat].join(' ');
}

function convertTZ(date, tzString) {
    return new Date((typeof date === "string" ? new Date(date) : date).toLocaleString("en-US", {
        timeZone: tzString
    }));
}

function formatAMPM(date) {
    var hours = date.getHours();
    var minutes = date.getMinutes();
    var ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12;
    hours = hours ? hours : 12; // the hour '0' should be '12'
    minutes = minutes < 10 ? '0' + minutes : minutes;
    var strTime = hours + ':' + minutes + ' ' + ampm;
    return strTime;
}

function truncateWallet(wallet) {
    if (wallet === '') {
        return '0x000000...000000';
    }
    var acct = wallet.toString();
    var addr = acct[0] +
        acct[1] +
        acct[2] +
        acct[3] +
        acct[4] +
        acct[5] +
        acct[6] +
        acct[7] +
        acct[8] + '...' +

        acct[acct.length - 6] +
        acct[acct.length - 5] +
        acct[acct.length - 4] +
        acct[acct.length - 3] +
        acct[acct.length - 2] +
        acct[acct.length - 1];
    return addr;
}



/**
 * Fetch account data for UI when
 * - User switches accounts in wallet
 * - User switches networks in wallet
 * - User connects wallet initially
 */
async function refreshAccountData() {
    await fetchAccountData(provider);
}

/**
 * Connect wallet
 */
async function connect() {
    console.log("Opening a dialog", web3Modal);
    try {
        provider = await web3Modal.connect();
    } catch (e) {
        console.log("Could not get a wallet connection", e);
        return;
    }

    const result = await provider.request({
        method: 'wallet_switchEthereumChain',
        params: [{
            chainId: "0x38"
        }]
    });

    // Subscribe to accounts change
    provider.on("accountsChanged", (accounts) => {
        fetchAccountData();
    });

    // Subscribe to chainId change
    provider.on("chainChanged", (chainId) => {
        fetchAccountData();
    });

    // Subscribe to networkId change
    provider.on("networkChanged", (networkId) => {
        fetchAccountData();
    });

    await refreshAccountData();
}


/**
 * Disconnect wallet
 */
async function disconnect() {

    if (provider.close) {
        await provider.close();
        await web3Modal.clearCachedProvider();
        provider = null;
    }

    defaultAccount = '';

    document.querySelector("#disco-p").style.display = "block";
    document.querySelector("#btnConnectWallet").style.display = "block";
    document.querySelector("#conn-btn").style.display = "block";
    document.querySelector("#first-timer").style.display = "block";

    $("#conn-btn").css("text-align", "center");


}


/**
 * Main entry point.
 */
window.addEventListener("load", async () => {
    //init();
    //connect();
});