(function(g) {
    var window = this;
    'use strict';
    var mUN = function(l, c, Y) {
            g.H(function(X) {
                l.D = g.xm(c, Y);
                g.pL(X)
            })
        },
        ea = function(l) {
            l.isActive() || l.start()
        },
        W7L = function(l, c) {
            return c ? l.captionsInitialState : "CAPTIONS_INITIAL_STATE_UNKNOWN"
        },
        M9e = function(l) {
            return g.A2(l) || l.B("web_enable_caption_language_preference_stickiness")
        },
        sQQ = function(l, c) {
            var Y = new g.GX;
            Y.languageCode = l.languageCode;
            Y.languageName = l.languageName;
            Y.name = l.name;
            Y.displayName = l.displayName;
            Y.kind = l.kind;
            Y.isDefault = !1;
            Y.D = l.D;
            Y.isTranslateable = l.isTranslateable;
            Y.vssId = l.vssId;
            Y.url = l.url;
            Y.translationLanguage = c;
            l.xtags && (Y.xtags = l.xtags);
            l.captionId && (Y.captionId = l.captionId);
            return Y
        },
        BEe = function(l, c) {
            var Y, X, k;
            return g.H(function(r) {
                if (r.D == 1) return Y = l + "|" + c, g.n(r, g.l1(), 2);
                if (r.D != 3) {
                    X = r.G;
                    if (!X) throw g.Rf("gct");
                    return g.n(r, g.Ku(X), 3)
                }
                k = r.G;
                return r.return(k.get("captions", Y))
            })
        },
        L7E = function(l, c, Y) {
            BEe(l, c).then(function(X) {
                X && Y(X.trackData, new g.GX(X.metadata))
            })
        },
        uWM = function(l) {
            if (!EpQ.test(l)) throw Error("'" + l + "' is not a valid hex color");
            l.length == 4 && (l = l.replace(gpN, "#$1$1$2$2$3$3"));
            l = l.toLowerCase();
            l = parseInt(l.slice(1), 16);
            return [l >> 16, l >> 8 & 255, l & 255]
        },
        AdL = function() {
            var l = void 0;
            l = l === void 0 ? {} : l;
            var c = "suggest_correction" in g.bHE ? g.bHE.suggest_correction : "Edit caption";
            c = c || "";
            var Y = {},
                X;
            for (X in l) {
                Y = {
                    dA: Y.dA
                };
                Y.dA = X;
                var k = function(r) {
                    return function() {
                        return String(l[r.dA])
                    }
                }(Y);
                c = c.replace(new RegExp("\\$\\{" + Y.dA + "\\}", "gi"), k);
                c = c.replace(new RegExp("\\$" + Y.dA, "gi"), k)
            }
            return c
        },
        F7N = function() {
            return g.VK("yt-player-caption-display-settings")
        },
        JB = function() {
            this.segments = []
        },
        I4a = function(l, c) {
            var Y = g.dA(l.segments, c);
            Y >= 0 || Y < 0 && (-Y - 1) % 2 === 1 || (Y = -Y - 1, Y > 0 && c - l.segments[Y - 1] === 1 && Y < l.segments.length && l.segments[Y] - c === 1 ? (g.Fc(l.segments, Y), g.Fc(l.segments, Y - 1)) : Y > 0 && c - l.segments[Y - 1] === 1 ? l.segments[Y - 1] = c : Y < l.segments.length && l.segments[Y] - c === 1 ? l.segments[Y] = c : (g.eW(l.segments, Y, 0, c), g.eW(l.segments, Y + 1, 0, c)))
        },
        lIe = function(l, c, Y, X, k, r) {
            g.C.call(this);
            this.policy = l;
            this.player = c;
            this.AJ = Y;
            this.U = X;
            this.N = k;
            this.j = r;
            this.T = new JB;
            this.W = -1;
            this.K = this.G = this.D = null;
            this.Kh = 0;
            this.C = new g.gY(this.hZ, 1E3, this);
            this.events = new g.Cr(this);
            g.Z(this, this.C);
            g.Z(this, this.events);
            this.events.Z(c, "SEEK_COMPLETE", this.Tx);
            this.Tx();
            this.hZ()
        },
        cGQ = function(l) {
            return l.D && l.D.W ? l.D.W + l.player.tW() < l.player.getCurrentTime() : !1
        },
        Yuc = function(l, c) {
            if (l.policy.IA && l.player.Qi()) {
                var Y = g.Md(c, l.policy, {});
                Y.set("pot", l.player.Qi());
                Y = Y.Fq()
            } else Y = g.Md(c, l.policy, {}).Fq();
            var X = {
                format: "RAW",
                withCredentials: !0
            };
            if (l.policy.Ch) {
                X.method = "POST";
                var k = c.T;
                k && Object.keys(k).length > 0 ? X.postBody = g.AC(k, g.cO) : X.postBody = (0, g.Rs)([120, 0])
            }
            l.N && (X.responseType = "arraybuffer");
            var r = ++l.Kh,
                e = (0, g.nb)();
            l.K = g.HU(Y, X, 3, 100).then(function(d) {
                if (l.policy.Vk && r % 100 === 1) {
                    var y = (0, g.nb)();
                    l.player.Gz("caprsp", {
                        rn: r,
                        ms: y - e,
                        kb: (d.xhr.responseText.length / 1024).toFixed()
                    })
                }
                a: {
                    d = d.xhr;l.vU();
                    if (l.G) {
                        var O = !(l.N ? d.response :
                            d.responseText) || d.status >= 400;
                        if (y = g.HAL(d)) {
                            d = g.Md(l.G, l.policy, {});
                            l.G.Lx(d, y);
                            Yuc(l, l.G);
                            break a
                        }
                        O ? l.player.Gz("capfail", {
                            status: d.status
                        }) : (l.player.Wp().BI("fcb_r"), y = l.G.Rh[0].BU, l.U != null && l.W !== y && (O = l.G.Rh[0], l.N ? l.U(d.response, (O.startTime + l.player.tW()) * 1E3) : l.U(d.responseText, (O.startTime + l.player.tW()) * 1E3), l.W = y))
                    }
                    l.G = null;l.K = null
                }
            }).Kx(function(d) {
                l.G = null;
                l.K = null;
                var y;
                l.player.Gz("capfail", {
                    rn: r,
                    status: (y = d.xhr) == null ? void 0 : y.status
                })
            });
            l.G = c;
            I4a(l.T, l.G.Rh[0].BU)
        },
        dz = function(l, c) {
            g.P1.call(this, c);
            this.D = l;
            this.V = c;
            this.K = null;
            this.W = !1;
            this.logger = new g.eh("caps");
            this.C = g.xu(this.V.L()) && !this.D.isManifestless
        },
        kfN = function(l, c) {
            var Y = [],
                X;
            for (X in l.D.D)
                if (l.D.D.hasOwnProperty(X)) {
                    var k = l.D.D[X];
                    if (g.q_(k, c || null)) {
                        var r = k.info.id,
                            e = r,
                            d = "." + r,
                            y = "",
                            O = "";
                        if (k = k.info.captionTrack) r = k.languageCode, e = k.displayName, d = k.vssId, y = k.kind, O = k.id;
                        else {
                            k = r;
                            var D = g.Wwi.get(k);
                            D == null && (D = XsN[k] || XsN[k.replace(/-/g, "_")], g.Wwi.set(k, D));
                            k = D;
                            e = k || e
                        }
                        Y.push(new g.GX({
                            id: X,
                            languageCode: r,
                            languageName: e,
                            is_servable: !0,
                            is_default: !0,
                            is_translateable: !1,
                            vss_id: d,
                            kind: y,
                            captionId: O
                        }))
                    }
                }
            return Y
        },
        rG6 = function(l, c) {
            return c != null && c in l.D.D ? l.D.D[c] : null
        },
        eqi = function(l, c, Y) {
            var X = [],
                k;
            for (k in l.D.D)
                if (l.D.D.hasOwnProperty(k)) {
                    var r = l.D.D[k];
                    if (g.q_(r, Y || null)) {
                        var e = r.info.captionTrack;
                        e && e.languageCode === c && X.push(r)
                    }
                }
            return X.length ? X[0] : null
        },
        y9 = function(l, c, Y, X, k, r, e, d, y, O) {
            var D = O.isInline() && !0,
                t = {};
            Object.assign(t, c);
            Object.assign(t, l.params);
            Object.assign(t, Y);
            var U = {};
            Object.assign(U, c.QF);
            l.params.QF && Object.assign(U, l.params.QF);
            Object.assign(U, Y.QF);
            D && (t.windowOpacity = .6, U.backgroundOpacity = 0);
            t.QF = U;
            var G = t.oH === 1,
                f = [{
                    J: "span",
                    X: "captions-text",
                    S: {
                        style: "word-wrap: normal; display: block;"
                    }
                }],
                a, p, S;
            (d = d.oh("caption_edit_on_hover") && ((a = O.getVideoData().getPlayerResponse()) == null ? void 0 : (p = a.captions) == null ? void 0 : (S = p.playerCaptionsTracklistRenderer) == null ? void 0 : S.openTranscriptCommand)) &&
            f.unshift({
                J: "button",
                X: "caption-edit",
                S: {
                    tabindex: "0",
                    "aria-label": AdL()
                },
                Y: [{
                    J: "svg",
                    S: {
                        fill: "#e3e3e3",
                        height: "100%",
                        viewBox: "5 5 38 38",
                        width: "100%"
                    },
                    Y: [{
                        J: "path",
                        S: {
                            d: "M9 39h2.2l24.25-24.25-1.1-1.1-1.1-1.1L9 36.8Zm-3 3v-6.4L35.4 6.2q.85-.85 2.12-.82 1.27.02 2.12.87L41.8 8.4q.85.85.85 2.1t-.85 2.1L12.4 42Zm33.5-31.55L37.45 8.4Zm-4.05 4.3-1.1-1.1-1.1-1.1 2.2 2.2Z"
                        }
                    }]
                }]
            });
            g.B.call(this, {
                J: "div",
                X: "caption-window",
                S: {
                    id: "caption-window-" + l.id,
                    dir: G ? "rtl" : "ltr",
                    tabindex: "0",
                    lang: t.lang
                },
                Y: f
            });
            var x =
                this;
            this.C = [];
            this.PU = !1;
            this.G = l;
            this.NQ = this.Ch = null;
            this.playerWidth = r;
            this.playerHeight = e;
            this.U = null;
            this.maxWidth = r * .96;
            this.maxHeight = e * .96;
            this.D = t;
            this.DZ = Y;
            this.Kh = c;
            this.T = this.wf("captions-text");
            this.qJ = this.T.style.getPropertyValue("box-decoration-break") !== "" || this.T.style.getPropertyValue("-webkit-box-decoration-break") !== "";
            this.ZA = JGQ(X, k, r, e);
            this.fC = y;
            d && (this.W = this.wf("caption-edit"), this.Z(this.W, "click", function() {
                x.fC()
            }));
            this.type = 0;
            this.Ud = this.ZA * d8E(U);
            this.V2 = D;
            l = new g.$O(this.element, !0);
            g.Z(this, l);
            l.subscribe("dragstart", this.pB, this);
            l.subscribe("dragmove", this.iP, this);
            l.subscribe("dragend", this.mL, this);
            this.iQ = this.uQ = this.Gc = this.ph = 0;
            l = "";
            this.D.windowOpacity && (l = uWM(this.D.windowColor), l = "rgba(" + l[0] + "," + l[1] + "," + l[2] + "," + this.D.windowOpacity + ")");
            c = {
                "background-color": l,
                display: this.D.isVisible === !1 ? "none" : "",
                "text-align": yGU[this.D.textAlign]
            };
            this.qJ && (c["border-radius"] = l ? this.Ud / 8 + "px" : "");
            (this.K =
                this.G.params.oH === 2 || this.G.params.oH === 3) && OP6(this, this.element);
            g.dg(this.element, c);
            if (D) {
                var h;
                (h = this.element.parentElement) == null || h.style.setProperty("--caption-window-color", l)
            }
            switch (this.D.F4) {
                case 0:
                case 1:
                case 2:
                    g.Jj(this.element, "ytp-caption-window-top");
                    break;
                case 6:
                case 7:
                case 8:
                    g.Jj(this.element, "ytp-caption-window-bottom")
            }
        },
        OP6 = function(l, c) {
            var Y = "vertical-rl";
            l.D.gV === 1 && (Y = "vertical-lr");
            g.f6 && (Y = Y === "vertical-lr" ? "tb-lr" : "tb-rl");
            g.dg(c, "-o-writing-mode", Y);
            g.dg(c, "-webkit-writing-mode", Y);
            g.dg(c, "writing-mode", Y);
            g.dg(c, "text-orientation", "upright");
            g.Jj(c, "ytp-vertical-caption");
            l.G.params.oH === 3 && (g.dg(c, "text-orientation", ""), g.dg(c, "transform", "rotate(180deg)"))
        },
        d8E = function(l) {
            var c = 1 + .25 * (l.fontSizeIncrement || 0);
            if (l.offset === 0 || l.offset === 2) c *= .8;
            return c
        },
        D86 = function(l, c) {
            var Y = {},
                X = c.background ? c.background : l.D.QF.background;
            if (c.backgroundOpacity != null || c.background) {
                var k = c.backgroundOpacity != null ? c.backgroundOpacity : l.D.QF.backgroundOpacity;
                X = uWM(X);
                Y.background = "rgba(" + X[0] + "," + X[1] + "," + X[2] + "," + k + ")";
                l.qJ && (Y["box-decoration-break"] = "clone", Y["border-radius"] = l.Ud / 8 + "px")
            }
            if (c.fontSizeIncrement != null || c.offset != null) Y["font-size"] = l.ZA * d8E(c) + "px";
            X = 1;
            k = c.color || l.D.QF.color;
            if (c.color || c.textOpacity != null) k = uWM(k), X = c.textOpacity == null ? l.D.QF.textOpacity : c.textOpacity, k = "rgba(" + k[0] + "," + k[1] + "," + k[2] + "," + X + ")",
                Y.color = k, Y.fill = k;
            var r = c.charEdgeStyle;
            r === 0 && (r = void 0);
            if (r) {
                k = "rgba(34, 34, 34, " + X + ")";
                var e = "rgba(204, 204, 204, " + X + ")";
                c.j2 && (e = k = c.j2);
                var d = l.ZA / 16 / 2,
                    y = Math.max(d, 1),
                    O = Math.max(2 * d, 1),
                    D = Math.max(3 * d, 1),
                    t = Math.max(5 * d, 1);
                X = [];
                switch (r) {
                    case 4:
                        for (; D <= t; D += d) X.push(O + "px " + O + "px " + D + "px " + k);
                        break;
                    case 1:
                        O = window.devicePixelRatio >= 2 ? .5 : 1;
                        for (r = y; r <= D; r += O) X.push(r + "px " + r + "px " + k);
                        break;
                    case 2:
                        X.push(y + "px " + y + "px " + e);
                        X.push("-" + y + "px -" + y + "px " + k);
                        break;
                    case 3:
                        for (D = 0; D < 5; D++) X.push("0 0 " +
                            O + "px " + k)
                }
                Y["text-shadow"] = X.join(", ")
            }
            k = "";
            switch (c.fontFamily) {
                case 1:
                    k = '"Courier New", Courier, "Nimbus Mono L", "Cutive Mono", monospace';
                    break;
                case 2:
                    k = '"Times New Roman", Times, Georgia, Cambria, "PT Serif Caption", serif';
                    break;
                case 3:
                    k = '"Deja Vu Sans Mono", "Lucida Console", Monaco, Consolas, "PT Mono", monospace';
                    break;
                case 5:
                    k = '"Comic Sans MS", Impact, Handlee, fantasy';
                    break;
                case 6:
                    k = '"Monotype Corsiva", "URW Chancery L", "Apple Chancery", "Dancing Script", cursive';
                    break;
                case 7:
                    k = g.BU() ?
                        '"Carrois Gothic SC", sans-serif-smallcaps' : 'Arial, Helvetica, Verdana, "Marcellus SC", sans-serif';
                    break;
                case 0:
                case 4:
                    k = '"YouTube Noto", Roboto, Arial, Helvetica, Verdana, "PT Sans Caption", sans-serif'
            }
            k && (Y["font-family"] = k);
            k = c.offset;
            k == null && (k = l.D.QF.offset);
            switch (k) {
                case 0:
                    Y["vertical-align"] = "sub";
                    break;
                case 2:
                    Y["vertical-align"] = "super"
            }
            c.fontFamily === 7 && (Y["font-variant"] = "small-caps");
            c.bold && (Y["font-weight"] = "bold");
            c.italic && (Y["font-style"] = "italic");
            c.underline && (Y["text-decoration"] =
                "underline");
            c.Ohf && (Y.visibility = "hidden");
            c.YI === 1 && l.K && (Y["text-combine-upright"] = "all", Y["text-orientation"] = "mixed", k = g.lz || g.Na, l.G.params.oH === 3 ? Y.transform = k ? "rotate(90deg)" : "rotate(180deg)" : k && (Y.transform = "rotate(-90deg)"));
            if (c.textEmphasis === 1 || c.textEmphasis === 2 || c.textEmphasis === 3 || c.textEmphasis === 4 || c.textEmphasis === 5)
                if (g.lz) Y["font-weight"] = "bold";
                else switch (Y["text-emphasis-style"] = "filled circle", Y["text-emphasis-color"] = "currentcolor", Y["webkit-text-emphasis"] = "filled circle",
                    c.textEmphasis) {
                    case 4:
                    case 3:
                        Y["text-emphasis-position"] = "under left";
                        Y["webkit-text-emphasis-position"] = "under left";
                        break;
                    case 5:
                    case 2:
                        Y["text-emphasis-position"] = "over right", Y["webkit-text-emphasis-position"] = "over right"
                }
            return Y
        },
        On = function(l) {
            l = l.split("px");
            return l.length > 0 ? (l = Number(l[0])) ? l : 0 : 0
        },
        tRe = function(l) {
            l.U = g.eR("SPAN");
            g.dg(l.U, {
                display: "block"
            });
            g.Jj(l.U, "caption-visual-line");
            l.T.appendChild(l.U)
        },
        U8V = function(l, c) {
            var Y = g.eR("SPAN");
            g.dg(Y, {
                display: "inline-block",
                "white-space": "pre-wrap"
            });
            g.dg(Y, D86(l, c));
            Y.classList.add("ytp-caption-segment");
            l.U.appendChild(Y);
            Y.previousElementSibling && (g.dg(Y.previousElementSibling, {
                "border-top-right-radius": "0",
                "border-bottom-right-radius": "0"
            }), g.dg(Y, {
                "border-top-left-radius": "0",
                "border-bottom-left-radius": "0"
            }));
            return Y
        },
        GfL = function(l, c, Y) {
            l.PU = l.PU || !!Y;
            var X = {};
            Object.assign(X, l.D.QF);
            Object.assign(X, Y || c.D);
            Object.assign(X, l.DZ.QF);
            (Y = !l.U) && tRe(l);
            for (var k = l.Ch && l.NQ && g.C8(X, l.NQ) ? l.Ch : U8V(l, X), r = typeof c.text === "string", e = r ? c.text.split("\n") : [c.text], d = 0; d < e.length; d++) {
                var y = d > 0 || !c.append,
                    O = e[d];
                y && !Y ? (tRe(l), k = U8V(l, X)) : y && Y && (Y = !1);
                O && (k.appendChild(r ? g.JG(O) : O), r || O.tagName !== "RUBY" || O.childElementCount !== 4 || g.lz || !g.Os(O.children[2], "text-emphasis") || (y = l.K ? "padding-right" : "padding-top", g.Os(O.children[2], "text-emphasis-position") && (y =
                    l.K ? "padding-left" : "padding-bottom"), g.Yx ? g.dg(k, y, "1em") : g.dg(k, y, "0.5em")))
            }
            l.NQ = X;
            l.Ch = k;
            l.C.push(c)
        },
        JGQ = function(l, c, Y, X) {
            var k = c / 360 * 16;
            c >= l && (l = 640, X > Y * 1.3 && (l = 480), k = Y / l * 16);
            return k
        },
        PM7 = function() {
            this.K = this.time = this.mode = this.G = 0;
            this.T = new fIF(this);
            this.N = new fIF(this);
            this.D = [];
            this.clear()
        },
        qu7 = function(l, c, Y) {
            if (l === 255 && c === 255 || !l && !c) return {
                CZ: l,
                Fj: c,
                result: 0
            };
            l = bPa[l];
            c = bPa[c];
            if (l & 128) {
                var X;
                if (X = !(c & 128)) X = c, X = Y.UU() && Y.Fj === X;
                if (X) return {
                    CZ: l,
                    Fj: c,
                    result: 1
                }
            } else if (c & 128 && 1 <= l && l <= 31) return {
                CZ: l,
                Fj: c,
                result: 2
            };
            return {
                CZ: l,
                Fj: c,
                result: 3
            }
        },
        NTF = function(l, c, Y, X) {
            c === 255 && Y === 255 || !c && !Y ? (++l.K === 45 && l.reset(), l.T.G.clear(), l.N.G.clear()) : (l.K = 0, aIV(l.T, c, Y, X))
        },
        psM = function(l, c) {
            l.D.sort(function(k, r) {
                var e = k.time - r.time;
                return e === 0 ? k.order - r.order : e
            });
            for (var Y = g.b(l.D), X = Y.next(); !X.done; X = Y.next()) X = X.value, l.time = X.time, X.type === 0 ? NTF(l, X.IW, X.FZ, c) : X.type === 1 && l.G & 496 && aIV(l.N, X.IW, X.FZ, c);
            l.D.length = 0
        },
        D_ = function() {
            this.type = 0
        },
        tB = function() {
            this.state = this.Fj = this.CZ = 0
        },
        Rq6 = function() {
            this.timestamp = this.D = 0
        },
        Un = function(l) {
            this.N = l;
            this.K = [];
            this.D = this.G = this.row = 0;
            this.style = new D_;
            for (l = this.T = 0; l <= 15; l++) {
                this.K[l] = [];
                for (var c = 0; c <= 32; c++) this.K[l][c] = new Rq6
            }
        },
        GM = function(l, c) {
            if (l.style.type === 3) {
                for (var Y = 0, X = 0, k = l.N.time + 0, r = "", e = "", d = k, y = 1; y <= 15; ++y) {
                    for (var O = !1, D = X ? X : 1; D <= 32; ++D) {
                        var t = l.K[y][D];
                        if (t.D !== 0) {
                            Y === 0 && (Y = y, X = D);
                            O = String.fromCharCode(t.D);
                            var U = t.timestamp;
                            U < k && (k = U);
                            t.timestamp = d;
                            e && (r += e, e = "");
                            r += O;
                            O = !0
                        }
                        if ((t.D === 0 || D === 32) && O) {
                            e = "\n";
                            break
                        } else if (X && !O) break
                    }
                    if (Y && !O) break
                }
                r && c.T(Y, X, k, d, r)
            } else
                for (X = Y = 0, r = k = l.N.time + 0, e = 1; e <= 15; ++e)
                    for (d = "", y = 1; y <= 32; ++y)
                        if (D = l.K[e][y], t = D.D, t !== 0 && (Y === 0 && (Y = e, X = y), O = String.fromCharCode(t), U = D.timestamp, U <= k && (k = U), d += O, D.reset()), y === 32 || t === 0) d && c.T(Y, X, k, r, d), k = r, d = "", X = Y = 0
        },
        zqN = function(l, c) {
            switch (l) {
                case 0:
                    return iPa[(c & 127) - 32];
                case 1:
                    return SuQ[c & 15];
                case 2:
                    return vxQ[c & 31];
                case 3:
                    return x87[c & 31]
            }
            return 0
        },
        fC = function(l) {
            return l.K[l.row][l.G]
        },
        P6 = function(l, c, Y) {
            c >= 2 && l.G > 1 && (--l.G, fC(l).D = 0);
            var X = fC(l);
            X.timestamp = l.N.time + 0;
            X.D = zqN(c, Y);
            l.G < 32 && l.G++
        },
        nxN = function(l, c, Y, X) {
            for (var k = 0; k < X; k++)
                for (var r = 0; r <= 32; r++) {
                    var e = l.K[c + k][r],
                        d = l.K[Y + k][r];
                    e.D = d.D;
                    e.timestamp = d.timestamp
                }
        },
        b$ = function(l, c, Y) {
            for (var X = 0; X < Y; X++)
                for (var k = 0; k <= 32; k++) l.K[c + X][k].reset()
        },
        hqc = function(l) {
            l.row = l.D > 0 ? l.D : 1;
            l.G = 1;
            b$(l, 0, 15)
        },
        HPe = function(l) {
            this.K = l;
            this.N = 0;
            this.style = new D_;
            this.W = new Un(this.K);
            this.C = new Un(this.K);
            this.text = new Un(this.K);
            this.G = this.W;
            this.T = this.C;
            this.D = this.G
        },
        wsE = function(l, c, Y) {
            var X = l.G,
                k = !1;
            switch (l.style.get()) {
                case 4:
                case 1:
                case 2:
                    l.style.get() === 4 && X.D > 0 || (GM(X, Y), hqc(l.G), hqc(l.T), X.row = 15, X.D = c, k = !0)
            }
            l.style.set(3);
            l.D = X;
            l.D.style = l.style;
            l.K.mode = 1 << X.T;
            k ? X.G = 1 : X.D !== c && (X.D > c ? (GM(X, Y), b$(X, X.row - X.D, c)) : X.row < c && (c = X.D), X.D = c)
        },
        K3L = function(l) {
            l.style.set(1);
            l.D = l.T;
            l.D.D = 0;
            l.D.style = l.style;
            l.K.mode = 1 << l.D.T
        },
        TTM = function(l) {
            l.style.set(4);
            l.D = l.text;
            l.D.style = l.style;
            l.K.mode = 1 << l.D.T
        },
        fIF = function(l) {
            this.D = l;
            this.N = 0;
            this.K = new HPe(this.D);
            this.W = new HPe(this.D);
            this.G = new tB;
            this.T = this.K
        },
        aIV = function(l, c, Y, X) {
            l.G.update();
            c = qu7(c, Y, l.G);
            switch (c.result) {
                case 0:
                    return;
                case 1:
                case 2:
                    return
            }
            var k = c.CZ;
            Y = c.Fj;
            if (32 <= k || !k) l.D.mode & l.D.G && (c = k, c & 128 && (c = 127), Y & 128 && (Y = 127), l = l.T.D, c & 96 && P6(l, 0, c), Y & 96 && P6(l, 0, Y), c !== 0 && Y !== 0 && l.style.type === 3 && GM(l, X));
            else if (k & 16) a: if (!l.G.matches(k, Y) && (c = l.G, c.CZ = k, c.Fj = Y, c.state = 2, c = k & 8 ? l.W : l.K, l.T = c, l.D.mode = 1 << (l.N << 2) + (c.N << 1) + (c.style.type === 4 ? 1 : 0), (l.D.mode | 1 << (l.N << 2) + (c.N << 1) + (c.style.type !== 4 ? 1 : 0)) & l.D.G))
                if (Y & 64) {
                    X = [11, 11, 1, 2, 3, 4, 12, 13, 14, 15, 5, 6, 7, 8, 9, 10][(k & 7) << 1 | Y >> 5 & 1];
                    l = Y & 16 ? ((Y & 14) >> 1) * 4 : 0;
                    Y = c.D;
                    switch (c.style.get()) {
                        case 4:
                            X = Y.row;
                            break;
                        case 3:
                            if (X !== Y.row) {
                                if (X < Y.D && (X = Y.D, X === Y.row)) break;
                                var r = 1 + Y.row - Y.D,
                                    e = 1 + X - Y.D;
                                nxN(Y, e, r, Y.D);
                                c = r;
                                k = Y.D;
                                e < r ? (r = e + k - r, r > 0 && (c += r, k -= r)) : (r = r + k - e, r > 0 && (k -= r));
                                b$(Y, c, k)
                            }
                    }
                    Y.row = X;
                    Y.G = l + 1
                } else switch (k & 7) {
                    case 1:
                        switch (Y & 112) {
                            case 32:
                                P6(c.D, 0, 32);
                                break a;
                            case 48:
                                Y === 57 ? (X = c.D, fC(X).D = 0, X.G < 32 && X.G++) : P6(c.D, 1, Y & 15)
                        }
                        break;
                    case 2:
                        Y & 32 && P6(c.D, 2, Y & 31);
                        break;
                    case 3:
                        Y & 32 && P6(c.D, 3, Y & 31);
                        break;
                    case 4:
                    case 5:
                        if (32 <= Y && Y <= 47) switch (Y) {
                            case 32:
                                K3L(c);
                                break;
                            case 33:
                                X = c.D;
                                X.G > 1 && (--X.G, fC(X).D = 0);
                                break;
                            case 36:
                                X = c.D;
                                c = fC(X);
                                for (l = 0; l <= 15; l++)
                                    for (Y = 0; Y <= 32; Y++)
                                        if (X.K[l][Y] === c) {
                                            for (; Y <= 32; Y++) X.K[l][Y].reset();
                                            break
                                        }
                                break;
                            case 37:
                                wsE(c, 2, X);
                                break;
                            case 38:
                                wsE(c, 3, X);
                                break;
                            case 39:
                                wsE(c, 4, X);
                                break;
                            case 40:
                                P6(c.D, 0, 32);
                                break;
                            case 41:
                                c.style.set(2);
                                c.D = c.G;
                                c.D.D = 0;
                                c.D.style = c.style;
                                c.K.mode = 1 << c.D.T;
                                break;
                            case 42:
                                X = c.text;
                                X.D = 15;
                                X.style.set(4);
                                hqc(X);
                                TTM(c);
                                break;
                            case 43:
                                TTM(c);
                                break;
                            case 44:
                                l = c.G;
                                switch (c.style.get()) {
                                    case 1:
                                    case 2:
                                    case 3:
                                        GM(l, X)
                                }
                                b$(l,
                                    0, 15);
                                break;
                            case 45:
                                b: {
                                    l = c.D;
                                    switch (c.style.get()) {
                                        default:
                                            case 2:
                                            case 1:
                                            break b;
                                        case 4:
                                                if (l.row < 15) {
                                                ++l.row;
                                                l.G = 1;
                                                break b
                                            }break;
                                        case 3:
                                    }
                                    l.D < 2 && (l.D = 2, l.row < l.D && (l.row = l.D));c = l.row - l.D + 1;GM(l, X);nxN(l, c, c + 1, l.D - 1);b$(l, l.row, 1)
                                }
                                break;
                            case 46:
                                b$(c.T, 0, 15);
                                break;
                            case 47:
                                GM(c.G, X), c.T.updateTime(c.K.time + 0), X = c.T, c.T = c.G, c.G = X, K3L(c)
                        }
                        break;
                    case 7:
                        switch (Y) {
                            case 33:
                            case 34:
                            case 35:
                                X = c.D, (X.G += Y & 3) > 32 && (X.G = 32)
                        }
                }
        },
        jL7 = function() {},
        qo = function(l, c, Y, X, k, r, e) {
            r = r === void 0 ? !1 : r;
            e = e === void 0 ? null : e;
            g.r8.call(this, l, l + c, {
                priority: Y,
                namespace: "captions"
            });
            this.windowId = X;
            this.text = k;
            this.append = r;
            this.D = e
        },
        oxc = function(l, c, Y, X, k, r, e) {
            var d = r[0],
                y = e[d.getAttribute("p")];
            if (y.Ni === 1) {
                var O = r[1],
                    D = r[2];
                r = r[3];
                d.getAttribute("t");
                O.getAttribute("t");
                D.getAttribute("t");
                r.getAttribute("t");
                d.getAttribute("p");
                O.getAttribute("p");
                r.getAttribute("p");
                e = e[D.getAttribute("p")];
                d = VR7(d.textContent, O.textContent, D.textContent, r.textContent, e);
                return new qo(l, c, k, Y, d, X, y)
            }
            switch (y.Ni) {
                case 9:
                case 10:
                    y.textEmphasis = 1;
                    break;
                case 11:
                    y.textEmphasis = 2;
                    break;
                case 12:
                    y.textEmphasis = 3;
                    break;
                case 13:
                    y.textEmphasis = 4;
                    break;
                case 14:
                    y.textEmphasis = 5
            }
            return new qo(l, c, k, Y, d.textContent ||
                "", X, y)
        },
        VR7 = function(l, c, Y, X, k) {
            var r = g.BU(),
                e = r ? g.eR("DIV") : g.eR("RUBY"),
                d = g.eR("SPAN");
            d.textContent = l;
            e.appendChild(d);
            l = r ? g.eR("DIV") : g.eR("RP");
            l.textContent = c;
            e.appendChild(l);
            c = r ? g.eR("DIV") : g.eR("RT");
            c.textContent = Y;
            e.appendChild(c);
            Y = k.Ni;
            if (Y === 10 || Y === 11 || Y === 12 || Y === 13 || Y === 14)
                if (g.dg(c, "text-emphasis-style", "filled circle"), g.dg(c, "text-emphasis-color", "currentcolor"), g.dg(c, "webkit-text-emphasis", "filled circle"), k.Ni === 11 || k.Ni === 13) g.dg(c, "webkit-text-emphasis-position", "under left"), g.dg(c, "text-emphasis-position", "under left");
            Y = !0;
            if (k.Ni === 4 || k.Ni === 7 || k.Ni === 12 ||
                k.Ni === 14) g.dg(e, "ruby-position", "over"), g.dg(e, "-webkit-ruby-position", "before");
            else if (k.Ni === 5 || k.Ni === 6 || k.Ni === 11 || k.Ni === 13) g.dg(e, "ruby-position", "under"), g.dg(e, "-webkit-ruby-position", "after"), Y = !1;
            k = r ? g.eR("DIV") : g.eR("RP");
            k.textContent = X;
            e.appendChild(k);
            r && (X = Y, g.dg(e, {
                display: "inline-block",
                position: "relative"
            }), r = e.firstElementChild.nextElementSibling, g.dg(r, "display", "none"), r = r.nextElementSibling, g.dg(r, {
                "font-size": "0.5em",
                "line-height": "1.2em",
                "text-align": "center",
                position: "absolute",
                left: "50%",
                transform: "translateX(-50%)",
                width: "400%"
            }), g.dg(e.lastElementChild, "display", "none"), X ? (g.dg(e, "padding-top", "0.6em"), g.dg(r, "top", "0")) : (g.dg(e, "padding-bottom", "0.6em"), g.dg(r, "bottom", "0")));
            return e
        },
        au = function() {
            g.C.apply(this, arguments)
        },
        No = function(l, c, Y, X, k) {
            g.r8.call(this, l, l + c, {
                priority: Y,
                namespace: "captions"
            });
            this.id = X;
            this.params = k;
            this.D = []
        },
        CMQ = function(l) {
            var c = "_" + pC++;
            return new No(0, 0x8000000000000, 0, c, l)
        },
        Ru = function(l) {
            au.call(this);
            this.K = l;
            this.pens = {};
            this.C = {};
            this.U = {};
            this.T = "_" + pC++;
            this.W = {};
            this.G = this.D = null;
            this.N = !0
        },
        i$ = function(l, c) {
            l = l.getAttribute(c);
            if (l != null) return Number(l)
        },
        Sa = function(l, c) {
            l = l.getAttribute(c);
            if (l != null) return l === "1"
        },
        v6 = function(l, c) {
            l = i$(l, c);
            return l !== void 0 ? l : null
        },
        zM = function(l, c) {
            l = l.getAttribute(c);
            if (l != null) return xc.test(l), l
        },
        ZP7 = function(l, c) {
            var Y = {},
                X = c.getAttribute("ws");
            Object.assign(Y, X ? l.U[X] : l.K);
            l = v6(c, "mh");
            l != null && (Y.sF = l);
            l = v6(c, "ju");
            l != null && (Y.textAlign = l);
            l = v6(c, "pd");
            l != null && (Y.oH = l);
            l = v6(c, "sd");
            l != null && (Y.gV = l);
            l = zM(c, "wfc");
            l != null && (Y.windowColor = l);
            c = i$(c, "wfo");
            c !== void 0 && (Y.windowOpacity = c / 255);
            return Y
        },
        $8Q = function(l, c) {
            var Y = {},
                X = c.getAttribute("wp");
            X && Object.assign(Y, l.C[X]);
            l = v6(c, "ap");
            l != null && (Y.F4 = l);
            l = i$(c, "cc");
            l != null && (Y.EP = l);
            l = i$(c, "ah");
            l != null && (Y.cK = l);
            l = i$(c, "rc");
            l != null && (Y.SU = l);
            c = i$(c, "av");
            c != null && (Y.UZ = c);
            return Y
        },
        QLE = function(l, c, Y, X) {
            var k = {};
            Object.assign(k, $8Q(l, c));
            Object.assign(k, ZP7(l, c));
            X ? g.C8(k, l.K) ? (X = l.T, k = l.K) : X = "_" + pC++ : X = c.getAttribute("id") || "_" + pC++;
            l = i$(c, "t") + Y;
            c = i$(c, "d") || 0x8000000000000;
            if (k.oH === 2 || k.oH === 3) Y = k.SU, k.SU = k.EP, k.EP = Y;
            return new No(l, c, 0, X, k)
        },
        nC = function(l) {
            au.call(this);
            this.N = l;
            this.D = new Map;
            this.K = new Map;
            this.T = new Map;
            this.G = new Map
        },
        hB = function(l) {
            l = g.b0(Math.round(l), 0, 16777215).toString(16).toUpperCase();
            return "#000000".substring(0, 7 - l.length) + l
        },
        m8F = function(l, c, Y, X, k) {
            X === 0 && (X = 0x8000000000000);
            var r = {};
            c.wpWinPosId && Object.assign(r, l.K.get(c.wpWinPosId));
            c.wsWinStyleId && Object.assign(r, l.T.get(c.wsWinStyleId));
            l = c.rcRowCount;
            l !== void 0 && (r.SU = l);
            c = c.ccColCount;
            c !== void 0 && (r.EP = c);
            if (r.oH === 2 || r.oH === 3) c = r.SU, r.SU = r.EP, r.EP = c;
            return new No(Y, X, 0, k, r)
        },
        H6 = function(l, c, Y) {
            g.P1.call(this, l);
            this.videoData = c;
            this.audioTrack = Y;
            this.N = c.tI
        },
        wz = function(l, c, Y, X, k, r, e, d, y, O) {
            y9.call(this, l, c, Y, X, k, r, e, d, y, O);
            this.type = 1
        },
        KC = function(l, c, Y) {
            this.trackData = l;
            this.W = Y;
            this.version = this.N = this.K = this.byteOffset = 0;
            this.G = [];
            this.D = new DataView(this.trackData)
        },
        TM = function(l) {
            var c = l.byteOffset;
            l.byteOffset += 1;
            return l.D.getUint8(c)
        },
        V9 = function(l) {
            var c = l.byteOffset;
            l.byteOffset += 4;
            return l.D.getUint32(c)
        },
        ou = function(l, c) {
            au.call(this);
            this.G = l;
            this.K = c;
            this.track = this.K.languageName === "CC3" ? 4 : 0;
            this.D = new PM7;
            this.D.G = 1 << this.track
        },
        MRF = function(l) {
            if (typeof l === "string") return !1;
            l = new KC(l, 8, 0);
            return W3V(l)
        },
        W3V = function(l) {
            if (!(l.byteOffset < l.D.byteLength) || V9(l) !== 1380139777) return !1;
            l.version = TM(l);
            if (l.version > 1) return !1;
            TM(l);
            TM(l);
            TM(l);
            return !0
        },
        CC = function(l, c, Y, X, k, r, e, d, y, O) {
            y9.call(this, l, c, Y, X, k, r, e, d, y, O);
            var D = this;
            this.type = 2;
            this.xT = [];
            this.AJ = this.j = this.yf = 0;
            this.JJ = NaN;
            this.MJ = 0;
            this.OV = null;
            this.nh = new g.gY(this.To, 433, this);
            this.Ed = !1;
            this.W && (O.createClientVe(this.W, this, 167342), this.Z(this.W, "click", function() {
                O.logClick(D.W)
            }), l = new g.$O(this.element, !0), g.Z(this, l), l.subscribe("hoverstart", function() {
                O.logVisibility(D.W, !0)
            }, this));
            g.Jj(this.element, "ytp-caption-window-rollup");
            g.Z(this, this.nh);
            this.Ed = d.oh("html5_rollup_caption_window_enable_transition_end_listener");
            g.dg(this.element, "overflow", "hidden")
        },
        sLe = function(l, c) {
            if (!c) return "";
            l.K && l.G.params.gV !== 1 && (c *= -1);
            return "translate" + (l.K ? "X" : "Y") + "(" + c + "px)"
        },
        BTF = function(l) {
            l.xT = Array.from(l.element.getElementsByClassName("caption-visual-line"));
            for (var c = l.G.params.SU, Y = 0, X = 0, k = l.xT.length - 1; Y < c && k > -1;) {
                var r = l.xT[k];
                X += l.K ? r.offsetWidth : r.offsetHeight;
                Y++;
                k--
            }
            l.j = X;
            c = Math;
            Y = c.max;
            isNaN(l.JJ) && ((X = l.D.EP) ? (k = g.eR("SPAN"), g.Uu(k, "\u2013".repeat(X)), g.dg(k, D86(l, l.D.QF)), l.T.appendChild(k), l.JJ = k.offsetWidth, l.T.removeChild(k)) : l.JJ = 0);
            X = l.T;
            l.AJ = Y.call(c, l.JJ, l.MJ, (l.K ? X.offsetHeight : X.offsetWidth) + 1)
        },
        L3Q = function(l, c) {
            BTF(l);
            var Y = l.xT.reduce(function(r, e) {
                return (l.K ? e.offsetWidth : e.offsetHeight) + r
            }, 0);
            Y = l.j - Y;
            if (Y !== l.yf) {
                var X = Y > 0 && l.yf === 0,
                    k = Y < l.yf;
                c || isNaN(Y) || X || !k || (g.Jj(l.element, "ytp-rollup-mode"), l.Ed ? l.Z(l.element, "transitionend", l.To) : g.uf(l.nh));
                g.dg(l.T, "transform", sLe(l, Y));
                l.yf = Y
            }
            BTF(l)
        },
        ExE = function(l, c, Y, X) {
            var k = this;
            this.V = l;
            this.K = c;
            this.logger = Y;
            this.Hu = X;
            this.eC = [];
            this.GZ = [];
            this.D = null;
            this.gk = {
                Xrh: function() {
                    return k.D
                },
                Dl: function() {
                    return k.eC
                }
            };
            l = g.GR(this.V.L().experiments, "html5_override_micro_discontinuities_threshold_ms");
            this.G = l > 0 ? l : 10
        },
        AGc = function(l, c) {
            l.D = function(Y, X) {
                if (Y.info.N) {
                    var k = Y;
                    if (l.GZ.length > 0) {
                        for (k = l.GZ.shift(); l.GZ.length > 0;) k = g.c7(k, l.GZ.shift());
                        k = g.c7(k, Y)
                    }
                    if (k) {
                        Y = k;
                        try {
                            var r = g.YJ(Y) * 1E3
                        } catch (O) {
                            r = Y.info.startTime * 1E3
                        }
                        try {
                            var e = g.NjL(Y) * 1E3
                        } catch (O) {
                            e = Y.info.duration * 1E3
                        }
                        if (r < 0 || e < 0) r < 0 && (r = Y.info.startTime * 1E3), e < 0 && (e = Y.info.duration * 1E3);
                        Y.info.startTime = r / 1E3;
                        Y.info.T = r / 1E3;
                        Y.info.duration = e / 1E3;
                        Y.info.U = e / 1E3;
                        r = l.rN(k);
                        e = r.BU;
                        r = {
                            formatId: r.formatId,
                            startTimeMs: r.startTimeMs,
                            durationMs: r.durationMs,
                            w0: e,
                            S0: e
                        };
                        e = gxF(l.eC, r.startTimeMs);
                        var d = (Y = e >= 0 ? l.eC[e] : null) ?
                            Y.startTimeMs + Y.durationMs : 0,
                            y = r.startTimeMs + r.durationMs;
                        !Y || r.startTimeMs - d > l.G ? l.eC.splice(e + 1, 0, r) : (Y.durationMs = Math.max(d, y) - Y.startTimeMs, Y.S0 = Math.max(Y.S0, r.S0));
                        X(l.eC);
                        X = k.PP();
                        uwQ(l.K, X.buffer.slice(X.byteOffset, X.byteLength + X.byteOffset), c, k.info.T)
                    } else l.logger.D(350058965, "Empty slice")
                } else l.GZ.push(Y)
            };
            l.V.addEventListener("sabrCaptionsDataLoaded", l.D)
        },
        gxF = function(l, c) {
            l = g.dA(l, {
                startTimeMs: c
            }, function(Y, X) {
                return Y.startTimeMs - X.startTimeMs
            });
            return l >= 0 ? l : -l - 2
        },
        F3e = function(l, c) {
            g.P1.call(this, c);
            this.D = l;
            this.V = c;
            this.logger = new g.eh("caps");
            this.K = this.W = null;
            this.C = new ExE(this.V, this, this.logger, this.D.Hu)
        },
        uwQ = function(l, c, Y, X) {
            l.logger.debug(function() {
                return "SABR captions data received for " + X
            });
            l.W ? l.K == null ? l.logger.D(350058965, "Null loaded track meta data at captions data received") : Y.rX(c, l.K, X * 1E3) : l.logger.D(350058965, "Null Representation at captions data received")
        },
        IIe = function(l, c) {
            var Y = [],
                X;
            for (X in l.D.D)
                if (l.D.D.hasOwnProperty(X)) {
                    var k = l.D.D[X];
                    if (g.q_(k, c || null)) {
                        var r = k.info.id,
                            e = r,
                            d = "." + r,
                            y = "",
                            O = "";
                        if (k = k.info.captionTrack) r = k.languageCode, e = k.displayName, d = k.vssId, y = k.kind, O = k.id;
                        Y.push(new g.GX({
                            id: X,
                            languageCode: r,
                            languageName: e,
                            is_servable: !0,
                            is_default: !0,
                            is_translateable: !1,
                            vss_id: d,
                            kind: y,
                            captionId: O
                        }))
                    }
                }
            return Y
        },
        l16 = function(l, c, Y) {
            var X = [],
                k;
            for (k in l.D.D)
                if (l.D.D.hasOwnProperty(k)) {
                    var r = l.D.D[k];
                    if (g.q_(r, Y || null)) {
                        var e = r.info.captionTrack;
                        e && e.languageCode === c && X.push(r)
                    }
                }
            return X.length ? X[0] : null
        },
        c8a = function(l, c) {
            if (!g.O5L(l) || l.D != null && g.xu(c.L()) && !l.D.isManifestless && l.D.D.rawcc != null) return !1;
            c = !!l.D && l.D.isManifestless && Object.values(l.D.D).some(function(Y) {
                return g.q_(Y, "386")
            });
            l = !!l.D && !l.D.isManifestless && g.jV5(l.D);
            return c || l
        },
        Z_ = function() {
            au.call(this)
        },
        YIi = function(l, c, Y, X, k, r, e, d, y) {
            switch (e.tagName) {
                case "b":
                    d.bold = !0;
                    break;
                case "i":
                    d.italic = !0;
                    break;
                case "u":
                    d.underline = !0
            }
            for (var O = 0; O < e.childNodes.length; O++) {
                var D = e.childNodes[O];
                if (D.nodeType === 3) D = new qo(c, Y, X, k.id, D.nodeValue, r || O > 0, g.VS(d) ? void 0 : d), y.push(D), k.D.push(D);
                else {
                    var t = {};
                    Object.assign(t, d);
                    YIi(l, c, Y, X, k, !0, D, t, y)
                }
            }
        },
        Xaa = function(l) {
            var c = l.split(":");
            l = 0;
            c = g.b(c);
            for (var Y = c.next(); !Y.done; Y = c.next()) l = l * 60 + Number(Y.value);
            return l * 1E3
        },
        kxc = function(l, c, Y, X) {
            X = Object.assign({
                sF: 0
            }, X);
            return new No(l, c, Y, "_" + pC++, X)
        },
        $c = function(l, c) {
            g.C.call(this);
            this.V = l;
            this.fh = c;
            this.D = null;
            this.G = this.V.Gm();
            this.logger = new g.eh("caps")
        },
        ePN = function(l, c, Y) {
            if (typeof c === "string" || MRF(c)) return [{
                trackData: c,
                Ac: Y
            }];
            var X = new DataView(c);
            if (X.byteLength <= 8 || X.getUint32(4) !== 1718909296) return [];
            var k = g.nwy(X);
            if (l.G && k) {
                var r = g.NiK(k),
                    e = g.pIv(k);
                k = k.vW;
                r && k && l.G.bX(k, r, e)
            }
            l = g.YA(X, 1835295092);
            if (!l || !l.length || !l[0].size) return [];
            r = [];
            for (e = 0; e < l.length; e++) k = l[e], k = new Uint8Array(c, k.dataOffset, k.size - (k.dataOffset - k.offset)), k = g.nv(k), r.push({
                trackData: k,
                Ac: Y + e * 1E3
            });
            r8F(X, r, Y);
            return r = r.filter(function(d) {
                return !!d.trackData
            })
        },
        r8F = function(l, c, Y) {
            var X = g.Lo(l, 0, 1836476516),
                k = 9E4;
            X && (k = g.EX(X) || 9E4);
            X = 0;
            for (var r = g.YA(l, 1836019558), e = 0; e < r.length; e++) {
                var d = r[e];
                e < c.length && (d = g.Lo(l, d.dataOffset, 1953653094)) && (d = g.Lo(l, d.dataOffset, 1952867444)) && (d = g.l7(d) / k * 1E3, e === 0 && (X = d), c[e].Ac = d - X + Y || Y * e * 1E3)
            }
        },
        J87 = function(l) {
            var c = {};
            if (l = g.bz(l)) c.lang = l, g.g6L.test(l) && (c.oH = 1);
            return c
        },
        Q9 = function(l) {
            g.GH.call(this, l);
            var c = this;
            this.V = l;
            this.Ch = [];
            this.xT = {};
            this.Ed = {};
            this.U = !1;
            this.T = "NONE";
            this.D = this.j = this.AJ = this.ZA = this.iQ = null;
            this.V2 = {
                YA: function() {
                    c.YA()
                },
                rX: function(r, e, d, y) {
                    c.rX(r, e, d, y)
                }
            };
            this.G = null;
            this.fh = this.V.L();
            this.videoData = this.V.getVideoData();
            this.ph = this.V.m0();
            var Y;
            this.uQ = (Y = this.V.getVideoData(1)) == null ? void 0 : g.uz(Y);
            this.K = {
                QF: {}
            };
            this.W = {
                QF: {}
            };
            g.Eg(this.videoData) ? this.T = "OFFLINE" : c8a(this.videoData, this.V) ? this.T = "SABR_LIVE" : g.Bwn(this.videoData, this.V) ? this.T = "LIVE" : this.videoData.captionTracks.length ? this.T = "INNERTUBE" : this.videoData.EG && (this.T = "TTS");
            this.nh = this.fh.controlsType === "3";
            this.Ud = new $c(this.V, this.fh);
            this.JJ = new g.Cr(this);
            this.C = new g.B({
                J: "div",
                X: "ytp-caption-window-container",
                S: {
                    id: "ytp-caption-window-container"
                }
            });
            this.Kh = {
                top: 0,
                right: 0,
                bottom: 0,
                left: 0,
                width: 1,
                height: 1
            };
            Y = null;
            var X = g.C6("yt-html5-player-modules::subtitlesModuleData");
            X && (Y = new g.n6(X));
            this.storage = Y;
            var k;
            this.Gc = !((k = l.Vx()) == null || !k.ML());
            this.N = d5N(this);
            this.PU = !this.N && this.nh && this.Gc && (this.T === "LIVE" || this.T === "SABR_LIVE");
            g.Z(this, this.Ud);
            this.N ? this.yf = this.NQ = null : (this.NQ = new g.Ee(this.XA, void 0, this), g.Z(this, this.NQ), this.yf = new g.gY(this.ouT, 2E3, this),
                g.Z(this, this.yf));
            g.Z(this, this.JJ);
            g.oD(this.player, this.C.element, 4);
            g.Z(this, this.C);
            this.N || this.JJ.Z(l, "resize", this.FA);
            (this.Pu = g.jk(this.fh) && !g.q1() && !this.V.isFullscreen() && !this.N && !this.PU) && this.JJ.Z(l, "resize", this.RlJ);
            this.JJ.Z(l, "onPlaybackAudioChange", this.x0h);
            this.JJ.Z(l, g.Jv("captions"), function(r) {
                c.onCueRangeEnter(r)
            });
            this.JJ.Z(l, g.d8("captions"), function(r) {
                c.onCueRangeExit(r)
            });
            this.uQ && this.JJ.Z(l, "videodatachange", function(r, e) {
                c.onVideoDataChange(r, e)
            });
            y8N(this, F7N() || {});
            this.player.fV("onCaptionsModuleAvailable")
        },
        tui = function(l) {
            if (l.fh.Gc === 1 || l.videoData.lz === 1 || g.iG(l.videoData, "yt:cc") === "alwayson") return !0;
            if (l.videoData.captionTracks.length) var c = l.getAudioTrack().G;
            if (l.fh.Gc === 2) {
                if (g.A2(l.fh)) var Y = Om6(l);
                else if (l.storage) try {
                    Y = l.storage.get("module-enabled")
                } catch (k) {
                    l.storage.remove("module-enabled")
                } else Y = null;
                if (Y != null) return !!Y
            }
            Y = W7L(l.player.getAudioTrack(), g.A2(l.fh));
            var X = g.iG(l.videoData, "yt:cc");
            if (D5L(l) === void 0) {
                if (Y === "CAPTIONS_INITIAL_STATE_ON_RECOMMENDED") return X ? X === "on" : !0;
                if (Y === "CAPTIONS_INITIAL_STATE_OFF_RECOMMENDED") return X === "on"
            } else return X === "on";
            return c === "ON" ||
                g.iG(l.videoData, "yt:cc") === "on"
        },
        ms = function(l, c) {
            if (l.G && (c === void 0 || !c) || !l.videoData.captionTracks.length) return !1;
            l = l.getAudioTrack();
            return !!l.D || l.G === "FORCED_ON"
        },
        D5L = function(l) {
            var c = void 0,
                Y = g.WJ(g.ml(), 65);
            if (g.A2(l.fh) && Y != null) {
                if (Om6(l) != null) return !1;
                c = !Y
            }
            return c
        },
        Mo = function(l, c) {
            if (!l.D) return null;
            if (l.j && l.j.T) return l.j.T;
            c = U5V(l, c);
            c = g.c1(l.D.G, c);
            var Y = null;
            if (M9e(l.fh)) {
                var X = l.V.isInline() ? void 0 : g.VK("yt-player-caption-sticky-language");
                for (var k = [X, l.videoData.captionsLanguagePreference, l.fh.captionsLanguagePreference, g.iG(l.videoData, "yt:cc_default_lang")], r = !1, e = 0; e < k.length; e++) {
                    var d = k[e];
                    if (d) {
                        r = !0;
                        for (var y = 0; y < c.length; y++)
                            if (g.bz(c[y]) === d) return c[y];
                        for (y = 0; y < c.length; y++)
                            if (g.bz(c[y]).split("-")[0] === d.split("-")[0]) return c[y]
                    }
                }
                if (r && l.D && (k = l.D.N, k.length))
                    for (k = g.b(k),
                        r = k.next(); !r.done; r = k.next())
                        if (r = r.value, r.languageCode === X) {
                            Y = r;
                            break
                        }
            } else
                for (X = [l.videoData.captionsLanguagePreference, l.fh.captionsLanguagePreference, g.iG(l.videoData, "yt:cc_default_lang")], k = 0; k < X.length; k++)
                    for (r = 0; r < c.length; r++)
                        if (g.bz(c[r]) === X[k]) return c[r];
            X = null;
            l.j && l.j.K && (X = l.j.K);
            X || (X = c.find(function(O) {
                return O.isDefault
            }) || null);
            X || (X = c[0] || W6(l));
            X && Y && g.bz(X).split("-")[0] !== Y.languageCode.split("-")[0] && (X = sQQ(X, Y));
            return X
        },
        W6 = function(l) {
            return l.j && l.j.D
        },
        sn = function(l) {
            var c = W6(l);
            return !!c && l.G === c
        },
        GxF = function(l, c) {
            var Y = l.V.Vx().kM().textTracks;
            l = l.G.toString();
            for (var X = 0; X < Y.length; X++) {
                var k = Y[X];
                k.id === l && (c ? k.mode !== "showing" && (k.mode = "showing") : k.mode === "showing" && (k.mode = "disabled"))
            }
        },
        En = function(l, c, Y) {
            l.loaded && l.unload();
            Y != null && (l.U = Y, l.U && (g.A2(l.fh) ? B6(l, !!c) : LC(l, !!c)));
            f1a(l, l.G, c, l.U, !1);
            l.G = c;
            ms(l) && (c = W6(l), f1a(l, l.G, c, l.U, !0), l.G = c);
            var X;
            P_E(l, (X = l.G) != null ? X : void 0);
            l.load()
        },
        qIN = function(l, c) {
            if (c instanceof No) {
                var Y = l.xT[c.id];
                Y && Y.G !== c && (Y.dispose(), delete l.xT[c.id], Y = null);
                Y || (Y = bmc(l, c)) && (l.xT[c.id] = Y)
            } else Y = c.windowId, l.Ed[Y] || (l.Ed[Y] = []), l.Ed[Y].push(c)
        },
        bmc = function(l, c) {
            var Y = a1L(l);
            if (!Y) return null;
            var X = l.G ? g.bz(l.G) : null;
            X && g.g6L.test(X) && (c.params.oH = 1);
            var k = l.ph.getPlayerSize();
            X = k.height * l.Kh.height;
            k = k.width * l.Kh.width;
            l.fh.playerStyle !== "google-live" || l.K.isDefault || Object.assign(c.params, l.K);
            switch (c.params.sF != null ? c.params.sF : c.D.length > 1 ? 1 : 0) {
                case 1:
                    return new wz(c, l.K, l.W, Y.width, Y.height, k, X, l.fh.experiments, l.FU.bind(l), l.V);
                case 2:
                    return new CC(c, l.K, l.W, Y.width, Y.height, k, X, l.fh.experiments, l.FU.bind(l), l.V);
                default:
                    return new y9(c, l.K, l.W, Y.width, Y.height,
                        k, X, l.fh.experiments, l.FU.bind(l), l.V)
            }
        },
        y8N = function(l, c, Y) {
            Y = Y === void 0 ? !1 : Y;
            var X = gz.QF;
            l.K = {};
            Object.assign(l.K, gz);
            l.K.QF = {};
            Object.assign(l.K.QF, X);
            l.W = {
                QF: {}
            };
            var k = c.backgroundOverride ? l.W : l.K,
                r = c.background || X.background;
            xc.test(r);
            k.QF.background = r;
            k = c.colorOverride ? l.W : l.K;
            r = c.color || X.color;
            xc.test(r);
            k.QF.color = r;
            k = c.windowColorOverride ? l.W : l.K;
            r = c.windowColor || gz.windowColor;
            xc.test(r);
            k.windowColor = r;
            k = c.backgroundOpacityOverride ? l.W : l.K;
            r = c.backgroundOpacity;
            r == null && (r = X.backgroundOpacity);
            k.QF.backgroundOpacity = r;
            k = c.fontSizeIncrementOverride ? l.W : l.K;
            r = c.fontSizeIncrement;
            r == null && (r = X.fontSizeIncrement);
            k.QF.fontSizeIncrement = r;
            r = c.fontStyleOverride ? l.W : l.K;
            k = c.fontStyle;
            k == null && (k = X.bold && X.italic ? 3 : X.bold ? 1 : X.italic ? 2 : 0);
            r = r.QF;
            switch (k) {
                case 1:
                    r.bold = !0;
                    delete r.italic;
                    break;
                case 2:
                    delete r.bold;
                    r.italic = !0;
                    break;
                case 3:
                    r.bold = !0;
                    r.italic = !0;
                    break;
                default:
                    delete r.bold, delete r.italic
            }
            k = c.textOpacityOverride ? l.W : l.K;
            r = c.textOpacity;
            r == null && (r = X.textOpacity);
            k.QF.textOpacity = r;
            k = c.windowOpacityOverride ? l.W : l.K;
            r = c.windowOpacity;
            r == null && (r = gz.windowOpacity);
            k.windowOpacity =
                r;
            k = c.charEdgeStyleOverride ? l.W : l.K;
            r = c.charEdgeStyle;
            r == null && (r = X.charEdgeStyle);
            k.QF.charEdgeStyle = r;
            k = c.fontFamilyOverride ? l.W : l.K;
            r = c.fontFamily;
            r == null && (r = X.fontFamily);
            k.QF.fontFamily = r;
            l.loaded && l.FA();
            Y && g.jQ("yt-player-caption-display-settings", c, 2592E3)
        },
        N3U = function(l, c) {
            if (!l.D) return {};
            if (c) {
                g.VS(c) || l.RD(c.vss_id, "m");
                if (l.N || !g.gy(c)) return;
                if (g.VS(c)) {
                    En(l, null, !0);
                    return
                }
                for (var Y, X = g.c1(l.D.G, !0), k = 0; k < X.length; k++) {
                    var r = X[k];
                    r.languageCode !== c.languageCode || Y && (r.languageName !== c.languageName || (r.captionId || "") !== (c.captionId || "") || g.fu(r) !== c.displayName) || (Y = c.translationLanguage ? sQQ(r, c.translationLanguage) : r)
                }
                l.QU(c.position);
                !Y || Y === l.G && l.loaded || (c = g.sc(), X = g.bz(Y), c.length && X === c[c.length - 1] || (c.push(X), g.jQ("yt-player-caption-language-preferences", c)), M9e(l.fh) &&
                    !l.V.isInline() && g.jQ("yt-player-caption-sticky-language", X, 2592E3), En(l, Y, !0))
            } else return l.loaded && l.G && !sn(l) ? g.PZ(l.G) : {};
            return ""
        },
        RPE = function(l, c, Y) {
            c && !l.AJ ? (c = CMQ({
                oH: 0,
                lang: "en"
            }), l.AJ = [c, new qo(c.start, c.end - c.start, 0, c.id, Y != null ? Y : "Captions look like this")], l.player.jk(l.AJ)) : !c && l.AJ && (paQ(l, l.AJ), l.AJ = null)
        },
        paQ = function(l, c) {
            l.player.xP(c);
            c = g.b(c);
            for (var Y = c.next(); !Y.done; Y = c.next()) g.IU(l.Ch, Y.value);
            ea(l.NQ)
        },
        P_E = function(l, c) {
            l.fh.B("html5_modify_caption_vss_logging") && (l.videoData.lm = c)
        },
        a1L = function(l) {
            var c = l.ph.getVideoContentRect(!0).height,
                Y = l.ph.getVideoContentRect(!0).width;
            if (!c || !Y) return null;
            c *= l.Kh.height;
            Y *= l.Kh.width;
            return {
                width: Y,
                height: c
            }
        },
        LC = function(l, c) {
            if (l.storage) try {
                l.storage.set("module-enabled", c)
            } catch (Y) {}
        },
        B6 = function(l, c) {
            l.V.isInline() || g.jQ("yt-player-sticky-caption", c, 2592E3)
        },
        Om6 = function(l) {
            if (!l.V.isInline()) return g.VK("yt-player-sticky-caption")
        },
        d5N = function(l) {
            if (l.fh.B("safari_live_drm_captions_fix") && l.videoData.uK() && l.videoData.Hu() && g.Na) return !0;
            var c, Y = !((c = l.V.Vx()) == null || !c.qL());
            return l.nh && Y && l.T !== "LIVE" && l.T !== "SABR_LIVE"
        },
        U5V = function(l, c) {
            g.Cw(l.videoData) && (c = !0);
            c || (c = l.T === "TTS" ? !1 : l.T === "INNERTUBE" ? !1 : !0);
            return c || l.fh.B("web_deprecate_always_includes_asr_setting") && g.A2(l.fh) ? !0 : !!g.WJ(g.ml(), 66)
        },
        f1a = function(l, c, Y, X, k) {
            k ? l.zO(Y, !0, "g") : X ? c ? l.zO(Y, !!Y, "m") : Y && l.zO(Y, !0, "m") : !c && Y && l.zO(Y, !0, "s")
        };
    g.P1.prototype.O0 = g.dy(77, function() {
        return !1
    });
    g.P1.prototype.Co = g.dy(76, function() {});
    g.bg.prototype.Co = g.dy(75, function(l, c, Y) {
        var X = this;
        this.vU();
        c = this.KD(l, c);
        var k = this.Ih.L().B("html5_report_captions_ctmp_qoe"),
            r = (0, g.nb)();
        this.Lj();
        mUN(this, c, {
            format: "RAW",
            onSuccess: function(e) {
                X.D = null;
                if (k) {
                    var d = (e.responseText.length / 1024).toFixed(),
                        y = (0, g.nb)();
                    X.videoData.Gz("capresp", {
                        ms: y - r,
                        kb: d
                    })
                }
                Y.rX(e.responseText, l)
            },
            onError: k ? function(e) {
                var d;
                e = (d = e == null ? void 0 : e.status) != null ? d : 0;
                X.videoData.Gz("capfail", {
                    status: e
                })
            } : void 0,
            withCredentials: !0
        })
    });
    g.aS.prototype.Co = g.dy(74, function(l, c, Y) {
        var X = this;
        this.vU();
        c = this.KD(l, c);
        this.Lj();
        this.D = g.xm(c, {
            format: "RAW",
            onSuccess: function(k) {
                X.D = null;
                Y.rX(k.responseText, l)
            },
            withCredentials: !0
        })
    });
    g.E5.prototype.uJ = g.dy(73, function() {
        for (var l = g.IQ(document, "track", void 0, this.D), c = 0; c < l.length; c++) g.DI(l[c])
    });
    g.Kq.prototype.uJ = g.dy(72, function() {
        this.mediaElement.uJ()
    });
    g.E5.prototype.ML = g.dy(71, function() {
        return !(!this.D.textTracks || !this.D.textTracks.addEventListener)
    });
    g.Kq.prototype.ML = g.dy(70, function() {
        return this.mediaElement.ML()
    });
    g.E5.prototype.qL = g.dy(69, function() {
        return !!this.D.textTracks
    });
    g.Kq.prototype.qL = g.dy(68, function() {
        return this.mediaElement.qL()
    });
    g.E5.prototype.Zi = g.dy(67, function(l) {
        for (var c = 0; c < l.length; c++) this.D.appendChild(l[c])
    });
    g.Kq.prototype.Zi = g.dy(66, function(l) {
        this.mediaElement.Zi(l)
    });
    g.Fn.prototype.bX = g.dy(65, function(l, c, Y) {
        this.M0.bX(l, c, Y)
    });
    g.Mh.prototype.bX = g.dy(64, function(l, c, Y) {
        this.G.set(l, {
            UE: c,
            s5: Y
        })
    });
    g.sb.prototype.bX = g.dy(63, function(l, c, Y) {
        this.NQ.bX(l, c, Y)
    });
    g.Fn.prototype.U_ = g.dy(62, function(l) {
        return this.M0.U_(l)
    });
    g.sb.prototype.U_ = g.dy(61, function(l) {
        var c = 2;
        this.U.has(l) ? c = 0 : g.SkL(this, l) && (c = 1);
        return c
    });
    g.nX.prototype.b7 = g.dy(49, function(l) {
        var c = this.app.KC();
        return c ? c.b7(l) : !1
    });
    g.Wx.prototype.b7 = g.dy(48, function(l) {
        return this.DA.TL.b7(l)
    });
    g.VT.prototype.b7 = g.dy(47, function(l) {
        return this.zL().some(function(c) {
            return c.namespace === l
        })
    });
    g.Cq.prototype.b7 = g.dy(46, function() {
        return !1
    });
    g.nX.prototype.RD = g.dy(44, function(l, c) {
        var Y;
        (Y = this.app.MQ()) == null || Y.RD(l, c)
    });
    g.Wx.prototype.RD = g.dy(43, function(l, c) {
        this.DA.RD(l, c)
    });
    g.b5.prototype.RD = g.dy(42, function(l, c) {
        l = [l, c];
        g.PB(this, g.Ap(this.provider), "cfi", l)
    });
    g.K7.prototype.RD = g.dy(41, function(l, c) {
        this.qoe && this.qoe.RD(l, c)
    });
    g.rL.prototype.RD = g.dy(40, function(l, c) {
        this.hg().RD(l, c)
    });
    g.Cq.prototype.RD = g.dy(39, function() {});
    g.nX.prototype.zO = g.dy(38, function(l, c, Y) {
        var X;
        (X = this.app.MQ()) == null || X.zO(l, c, Y)
    });
    g.Wx.prototype.zO = g.dy(37, function(l, c, Y) {
        this.DA.zO(l, c, Y)
    });
    g.b5.prototype.zO = g.dy(36, function(l, c, Y) {
        if (this.yf !== l || this.fC !== c) c = c === "rawcc" ? "" : c, Y = [l, c, this.yf, Y], g.PB(this, g.Ap(this.provider), "cfs", Y), this.yf = l, this.fC = c
    });
    g.K7.prototype.zO = g.dy(35, function(l, c, Y) {
        this.qoe && this.qoe.zO(l, c, Y)
    });
    g.rL.prototype.zO = g.dy(34, function(l, c, Y) {
        this.hg().zO(l, c, Y)
    });
    g.Cq.prototype.zO = g.dy(33, function() {});
    g.gQ.prototype.Ar = g.dy(20, function() {
        return this.U
    });
    g.Pk.prototype.Ar = g.dy(19, function() {
        var l;
        return ((l = this.MQ()) == null ? void 0 : l.Gm()) || null
    });
    g.nX.prototype.Gm = g.dy(18, function() {
        return this.app.Ar()
    });
    g.Wx.prototype.Gm = g.dy(17, function() {
        return this.DA.Gm()
    });
    g.rL.prototype.Gm = g.dy(16, function() {
        var l;
        return ((l = this.tJ) == null ? void 0 : l.Ar()) || null
    });
    g.Cq.prototype.Gm = g.dy(15, function() {
        return null
    });
    g.Ko.prototype.N7 = g.dy(1, function(l) {
        return (l = this.RA(l)) ? l.D : 0
    });
    g.eM.prototype.N7 = g.dy(0, function() {
        return 0
    });
    var gpN = /#(.)(.)(.)/,
        EpQ = /^#(?:[0-9a-f]{3}){1,2}$/i,
        XsN = {
            aa: "Afar",
            ab: "Abkhazian",
            ace: "Acehnese",
            ach: "Acoli",
            ada: "Adangme",
            ady: "Adyghe",
            ae: "Avestan",
            aeb: "Tunisian Arabic",
            af: "Afrikaans",
            afh: "Afrihili",
            agq: "Aghem",
            ain: "Ainu",
            ak: "Akan",
            akk: "Akkadian",
            akz: "Alabama",
            ale: "Aleut",
            aln: "Gheg Albanian",
            alt: "Southern Altai",
            am: "Amharic",
            an: "Aragonese",
            ang: "Old English",
            anp: "Angika",
            ar: "Arabic",
            ar_001: "Arabic (world)",
            arc: "Aramaic",
            arn: "Mapuche",
            aro: "Araona",
            arp: "Arapaho",
            arq: "Algerian Arabic",
            ars: "Najdi Arabic",
            arw: "Arawak",
            ary: "Moroccan Arabic",
            arz: "Egyptian Arabic",
            as: "Assamese",
            asa: "Asu",
            ase: "American Sign Language",
            ast: "Asturian",
            av: "Avaric",
            avk: "Kotava",
            awa: "Awadhi",
            ay: "Aymara",
            az: "Azerbaijani",
            az_Cyrl: "Azerbaijani (Cyrillic)",
            az_Latn: "Azerbaijani (Latin)",
            ba: "Bashkir",
            bal: "Baluchi",
            ban: "Balinese",
            bar: "Bavarian",
            bas: "Basaa",
            bax: "Bamun",
            bbc: "Batak Toba",
            bbj: "Ghomala",
            be: "Belarusian",
            bej: "Beja",
            bem: "Bemba",
            bew: "Betawi",
            bez: "Bena",
            bfd: "Bafut",
            bfq: "Badaga",
            bg: "Bulgarian",
            bgc: "Haryanvi",
            bgn: "Western Balochi",
            bho: "Bhojpuri",
            bi: "Bislama",
            bik: "Bikol",
            bin: "Bini",
            bjn: "Banjar",
            bkm: "Kom",
            bla: "Siksik\u00e1",
            blo: "Anii",
            bm: "Bambara",
            bn: "Bangla",
            bo: "Tibetan",
            bpy: "Bishnupriya",
            bqi: "Bakhtiari",
            br: "Breton",
            bra: "Braj",
            brh: "Brahui",
            brx: "Bodo",
            bs: "Bosnian",
            bs_Cyrl: "Bosnian (Cyrillic)",
            bs_Latn: "Bosnian (Latin)",
            bss: "Akoose",
            bua: "Buriat",
            bug: "Buginese",
            bum: "Bulu",
            byn: "Blin",
            byv: "Medumba",
            ca: "Catalan",
            cad: "Caddo",
            car: "Carib",
            cay: "Cayuga",
            cch: "Atsam",
            ccp: "Chakma",
            ce: "Chechen",
            ceb: "Cebuano",
            cgg: "Chiga",
            ch: "Chamorro",
            chb: "Chibcha",
            chg: "Chagatai",
            chk: "Chuukese",
            chm: "Mari",
            chn: "Chinook Jargon",
            cho: "Choctaw",
            chp: "Chipewyan",
            chr: "Cherokee",
            chy: "Cheyenne",
            ckb: "Central Kurdish",
            co: "Corsican",
            cop: "Coptic",
            cps: "Capiznon",
            cr: "Cree",
            crh: "Crimean Tatar",
            cs: "Czech",
            csb: "Kashubian",
            csw: "Swampy Cree",
            cu: "Church Slavic",
            cv: "Chuvash",
            cy: "Welsh",
            da: "Danish",
            dak: "Dakota",
            dar: "Dargwa",
            dav: "Taita",
            de: "German",
            de_AT: "German (Austria)",
            de_CH: "German (Switzerland)",
            del: "Delaware",
            den: "Slave",
            dgr: "Dogrib",
            din: "Dinka",
            dje: "Zarma",
            doi: "Dogri",
            dsb: "Lower Sorbian",
            dua: "Duala",
            dum: "Middle Dutch",
            dv: "Divehi",
            dyo: "Jola-Fonyi",
            dyu: "Dyula",
            dz: "Dzongkha",
            dzg: "Dazaga",
            ebu: "Embu",
            ee: "Ewe",
            efi: "Efik",
            egy: "Ancient Egyptian",
            eka: "Ekajuk",
            el: "Greek",
            elx: "Elamite",
            en: "English",
            en_AU: "English (Australia)",
            en_CA: "English (Canada)",
            en_GB: "English (United Kingdom)",
            en_US: "English (United States)",
            enm: "Middle English",
            eo: "Esperanto",
            es: "Spanish",
            es_419: "Spanish (Latin America)",
            es_ES: "Spanish (Spain)",
            es_MX: "Spanish (Mexico)",
            et: "Estonian",
            eu: "Basque",
            ewo: "Ewondo",
            fa: "Persian",
            fa_AF: "Persian (Afghanistan)",
            fan: "Fang",
            fat: "Fanti",
            ff: "Fula",
            ff_Adlm: "Fula (Adlam)",
            ff_Latn: "Fula (Latin)",
            fi: "Finnish",
            fil: "Filipino",
            fj: "Fijian",
            fo: "Faroese",
            fon: "Fon",
            fr: "French",
            fr_CA: "French (Canada)",
            fr_CH: "French (Switzerland)",
            frm: "Middle French",
            fro: "Old French",
            frr: "Northern Frisian",
            frs: "Eastern Frisian",
            fur: "Friulian",
            fy: "Western Frisian",
            ga: "Irish",
            gaa: "Ga",
            gay: "Gayo",
            gba: "Gbaya",
            gd: "Scottish Gaelic",
            gez: "Geez",
            gil: "Gilbertese",
            gl: "Galician",
            gmh: "Middle High German",
            gn: "Guarani",
            goh: "Old High German",
            gon: "Gondi",
            gor: "Gorontalo",
            got: "Gothic",
            grb: "Grebo",
            grc: "Ancient Greek",
            gsw: "Swiss German",
            gu: "Gujarati",
            guz: "Gusii",
            gv: "Manx",
            gwi: "Gwich\u02bcin",
            ha: "Hausa",
            hai: "Haida",
            haw: "Hawaiian",
            he: "Hebrew",
            hi: "Hindi",
            hi_Latn: "Hindi (Latin)",
            hil: "Hiligaynon",
            hit: "Hittite",
            hmn: "Hmong",
            ho: "Hiri Motu",
            hr: "Croatian",
            hsb: "Upper Sorbian",
            ht: "Haitian Creole",
            hu: "Hungarian",
            hup: "Hupa",
            hy: "Armenian",
            hz: "Herero",
            ia: "Interlingua",
            iba: "Iban",
            ibb: "Ibibio",
            id: "Indonesian",
            ie: "Interlingue",
            ig: "Igbo",
            ii: "Sichuan Yi",
            ik: "Inupiaq",
            ilo: "Iloko",
            "in": "Indonesian",
            inh: "Ingush",
            io: "Ido",
            is: "Icelandic",
            it: "Italian",
            iu: "Inuktitut",
            iw: "Hebrew",
            ja: "Japanese",
            jbo: "Lojban",
            jgo: "Ngomba",
            jmc: "Machame",
            jpr: "Judeo-Persian",
            jrb: "Judeo-Arabic",
            jv: "Javanese",
            ka: "Georgian",
            kaa: "Kara-Kalpak",
            kab: "Kabyle",
            kac: "Kachin",
            kaj: "Jju",
            kam: "Kamba",
            kaw: "Kawi",
            kbd: "Kabardian",
            kbl: "Kanembu",
            kcg: "Tyap",
            kde: "Makonde",
            kea: "Kabuverdianu",
            kfo: "Koro",
            kg: "Kongo",
            kgp: "Kaingang",
            kha: "Khasi",
            kho: "Khotanese",
            khq: "Koyra Chiini",
            ki: "Kikuyu",
            kj: "Kuanyama",
            kk: "Kazakh",
            kk_Cyrl: "Kazakh (Cyrillic)",
            kkj: "Kako",
            kl: "Kalaallisut",
            kln: "Kalenjin",
            km: "Khmer",
            kmb: "Kimbundu",
            kn: "Kannada",
            ko: "Korean",
            kok: "Konkani",
            kok_Deva: "Konkani (Devanagari)",
            kok_Latn: "Konkani (Latin)",
            kos: "Kosraean",
            kpe: "Kpelle",
            kr: "Kanuri",
            krc: "Karachay-Balkar",
            krl: "Karelian",
            kru: "Kurukh",
            ks: "Kashmiri",
            ks_Arab: "Kashmiri (Arabic)",
            ks_Deva: "Kashmiri (Devanagari)",
            ksb: "Shambala",
            ksf: "Bafia",
            ksh: "Colognian",
            ku: "Kurdish",
            kum: "Kumyk",
            kut: "Kutenai",
            kv: "Komi",
            kw: "Cornish",
            kxv: "Kuvi",
            kxv_Deva: "Kuvi (Devanagari)",
            kxv_Latn: "Kuvi (Latin)",
            kxv_Orya: "Kuvi (Odia)",
            kxv_Telu: "Kuvi (Telugu)",
            ky: "Kyrgyz",
            la: "Latin",
            lad: "Ladino",
            lag: "Langi",
            lah: "Western Panjabi",
            lam: "Lamba",
            lb: "Luxembourgish",
            lez: "Lezghian",
            lg: "Ganda",
            li: "Limburgish",
            lij: "Ligurian",
            lkt: "Lakota",
            lmo: "Lombard",
            ln: "Lingala",
            lo: "Lao",
            lol: "Mongo",
            loz: "Lozi",
            lrc: "Northern Luri",
            lt: "Lithuanian",
            lu: "Luba-Katanga",
            lua: "Luba-Lulua",
            lui: "Luiseno",
            lun: "Lunda",
            luo: "Luo",
            lus: "Mizo",
            luy: "Luyia",
            lv: "Latvian",
            mad: "Madurese",
            maf: "Mafa",
            mag: "Magahi",
            mai: "Maithili",
            mak: "Makasar",
            man: "Mandingo",
            mas: "Masai",
            mde: "Maba",
            mdf: "Moksha",
            mdr: "Mandar",
            men: "Mende",
            mer: "Meru",
            mfe: "Morisyen",
            mg: "Malagasy",
            mga: "Middle Irish",
            mgh: "Makhuwa-Meetto",
            mgo: "Meta\u02bc",
            mh: "Marshallese",
            mi: "M\u0101ori",
            mic: "Mi'kmaw",
            min: "Minangkabau",
            mk: "Macedonian",
            ml: "Malayalam",
            mn: "Mongolian",
            mnc: "Manchu",
            mni: "Manipuri",
            mni_Beng: "Manipuri (Bangla)",
            mo: "Romanian",
            moh: "Mohawk",
            mos: "Mossi",
            mr: "Marathi",
            ms: "Malay",
            mt: "Maltese",
            mua: "Mundang",
            mul: "Multiple languages",
            mus: "Muscogee",
            mwl: "Mirandese",
            mwr: "Marwari",
            my: "Burmese",
            mye: "Myene",
            myv: "Erzya",
            mzn: "Mazanderani",
            na: "Nauru",
            nap: "Neapolitan",
            naq: "Nama",
            nb: "Norwegian Bokm\u00e5l",
            nd: "North Ndebele",
            nds: "Low German",
            nds_NL: "Low German (Netherlands)",
            ne: "Nepali",
            "new": "Newari",
            ng: "Ndonga",
            nia: "Nias",
            niu: "Niuean",
            nl: "Dutch",
            nl_BE: "Dutch (Belgium)",
            nmg: "Kwasio",
            nn: "Norwegian Nynorsk",
            nnh: "Ngiemboon",
            no: "Norwegian",
            nog: "Nogai",
            non: "Old Norse",
            nqo: "N\u2019Ko",
            nr: "South Ndebele",
            nso: "Northern Sotho",
            nus: "Nuer",
            nv: "Navajo",
            nwc: "Classical Newari",
            ny: "Nyanja",
            nym: "Nyamwezi",
            nyn: "Nyankole",
            nyo: "Nyoro",
            nzi: "Nzima",
            oc: "Occitan",
            oj: "Ojibwa",
            om: "Oromo",
            or: "Odia",
            os: "Ossetic",
            osa: "Osage",
            ota: "Ottoman Turkish",
            pa: "Punjabi",
            pa_Arab: "Punjabi (Arabic)",
            pa_Guru: "Punjabi (Gurmukhi)",
            pag: "Pangasinan",
            pal: "Pahlavi",
            pam: "Pampanga",
            pap: "Papiamento",
            pau: "Palauan",
            pcm: "Nigerian Pidgin",
            peo: "Old Persian",
            phn: "Phoenician",
            pi: "Pali",
            pl: "Polish",
            pon: "Pohnpeian",
            prg: "Prussian",
            pro: "Old Proven\u00e7al",
            ps: "Pashto",
            pt: "Portuguese",
            pt_BR: "Portuguese (Brazil)",
            pt_PT: "Portuguese (Portugal)",
            qu: "Quechua",
            raj: "Rajasthani",
            rap: "Rapanui",
            rar: "Rarotongan",
            rm: "Romansh",
            rn: "Rundi",
            ro: "Romanian",
            ro_MD: "Romanian (Moldova)",
            rof: "Rombo",
            rom: "Romany",
            ru: "Russian",
            rup: "Aromanian",
            rw: "Kinyarwanda",
            rwk: "Rwa",
            sa: "Sanskrit",
            sad: "Sandawe",
            sah: "Yakut",
            sam: "Samaritan Aramaic",
            saq: "Samburu",
            sas: "Sasak",
            sat: "Santali",
            sat_Olck: "Santali (Ol Chiki)",
            sba: "Ngambay",
            sbp: "Sangu",
            sc: "Sardinian",
            scn: "Sicilian",
            sco: "Scots",
            sd: "Sindhi",
            sd_Arab: "Sindhi (Arabic)",
            sd_Deva: "Sindhi (Devanagari)",
            se: "Northern Sami",
            see: "Seneca",
            seh: "Sena",
            sel: "Selkup",
            ses: "Koyraboro Senni",
            sg: "Sango",
            sga: "Old Irish",
            sh: "Serbo-Croatian",
            shi: "Tachelhit",
            shi_Latn: "Tachelhit (Latin)",
            shi_Tfng: "Tachelhit (Tifinagh)",
            shn: "Shan",
            shu: "Chadian Arabic",
            si: "Sinhala",
            sid: "Sidamo",
            sk: "Slovak",
            sl: "Slovenian",
            sm: "Samoan",
            sma: "Southern Sami",
            smj: "Lule Sami",
            smn: "Inari Sami",
            sms: "Skolt Sami",
            sn: "Shona",
            snk: "Soninke",
            so: "Somali",
            sog: "Sogdien",
            sq: "Albanian",
            sr: "Serbian",
            sr_Cyrl: "Serbian (Cyrillic)",
            sr_Latn: "Serbian (Latin)",
            srn: "Sranan Tongo",
            srr: "Serer",
            ss: "Swati",
            ssy: "Saho",
            st: "Southern Sotho",
            su: "Sundanese",
            su_Latn: "Sundanese (Latin)",
            suk: "Sukuma",
            sus: "Susu",
            sux: "Sumerian",
            sv: "Swedish",
            sw: "Swahili",
            sw_CD: "Swahili (Congo - Kinshasa)",
            swb: "Comorian",
            syc: "Classical Syriac",
            syr: "Syriac",
            szl: "Silesian",
            ta: "Tamil",
            te: "Telugu",
            tem: "Timne",
            teo: "Teso",
            ter: "Tereno",
            tet: "Tetum",
            tg: "Tajik",
            th: "Thai",
            ti: "Tigrinya",
            tig: "Tigre",
            tiv: "Tiv",
            tk: "Turkmen",
            tkl: "Tokelau",
            tl: "Tagalog",
            tlh: "Klingon",
            tli: "Tlingit",
            tmh: "Tamashek",
            tn: "Tswana",
            to: "Tongan",
            tog: "Nyasa Tonga",
            tok: "Toki Pona",
            tpi: "Tok Pisin",
            tr: "Turkish",
            trv: "Taroko",
            ts: "Tsonga",
            tsi: "Tsimshian",
            tt: "Tatar",
            tum: "Tumbuka",
            tvl: "Tuvalu",
            tw: "Twi",
            twq: "Tasawaq",
            ty: "Tahitian",
            tyv: "Tuvinian",
            tzm: "Central Atlas Tamazight",
            udm: "Udmurt",
            ug: "Uyghur",
            uga: "Ugaritic",
            uk: "Ukrainian",
            umb: "Umbundu",
            ur: "Urdu",
            uz: "Uzbek",
            uz_Arab: "Uzbek (Arabic)",
            uz_Cyrl: "Uzbek (Cyrillic)",
            uz_Latn: "Uzbek (Latin)",
            vai: "Vai",
            vai_Latn: "Vai (Latin)",
            vai_Vaii: "Vai (Vai)",
            ve: "Venda",
            vec: "Venetian",
            vi: "Vietnamese",
            vmw: "Makhuwa",
            vo: "Volap\u00fck",
            vot: "Votic",
            vun: "Vunjo",
            wa: "Walloon",
            wae: "Walser",
            wal: "Wolaytta",
            war: "Waray",
            was: "Washo",
            wo: "Wolof",
            xal: "Kalmyk",
            xh: "Xhosa",
            xnr: "Kangri",
            xog: "Soga",
            yao: "Yao",
            yap: "Yapese",
            yav: "Yangben",
            ybb: "Yemba",
            yi: "Yiddish",
            yo: "Yoruba",
            yrl: "Nheengatu",
            yue: "Cantonese",
            yue_Hans: "Cantonese (Simplified)",
            yue_Hant: "Cantonese (Traditional)",
            za: "Zhuang",
            zap: "Zapotec",
            zbl: "Blissymbols",
            zen: "Zenaga",
            zgh: "Standard Moroccan Tamazight",
            zh: "Chinese",
            zh_Hans: "Chinese (Simplified)",
            zh_Hant: "Chinese (Traditional)",
            zh_TW: "Chinese (Taiwan)",
            zu: "Zulu",
            zun: "Zuni",
            zxx: "No linguistic content",
            zza: "Zaza"
        };
    JB.prototype.contains = function(l) {
        l = g.dA(this.segments, l);
        return l >= 0 || l < 0 && (-l - 1) % 2 === 1
    };
    JB.prototype.length = function() {
        return this.segments.length / 2
    };
    g.P(lIe, g.C);
    g.J = lIe.prototype;
    g.J.Tz = function() {
        g.C.prototype.Tz.call(this);
        this.K && this.K.cancel()
    };
    g.J.Tx = function() {
        this.seekTo(this.player.getCurrentTime())
    };
    g.J.seekTo = function(l) {
        l -= this.player.tW();
        var c = this.D;
        this.D = g.LF(this.AJ.AE(l).Rh);
        c !== this.D && this.j && this.j()
    };
    g.J.reset = function() {
        this.T = new JB;
        this.W = -1;
        this.K && (this.K.cancel(), this.K = null)
    };
    g.J.hZ = function() {
        this.vU();
        var l;
        if (l = this.D != null) l = this.D, l = l.D.HM(l);
        if (l && !this.K && !(this.D && this.D.startTime - this.player.getCurrentTime() > 30)) {
            l = this.D;
            l = l.D.ZJ(l);
            var c = l.Rh[0],
                Y;
            if ((Y = this.player.getVideoData()) == null ? 0 : Y.enableServerStitchedDai)
                if (Y = this.player.Gm()) {
                    var X = c.D.info.id,
                        k = c.BU,
                        r = l.Rh[0].T;
                    if (this.policy.Ch) {
                        if (Y = Y.vk(r, k, X, 3)) l.T = Y
                    } else if (X = Y.Vy(r, k, X, 3))
                        if (Y = Y.U_(k), Y === 0) X && (l.D = new g.S4(X));
                        else if (Y === 2) {
                        this.C.start();
                        cGQ(this) && this.seekTo(this.player.getCurrentTime());
                        return
                    }
                }
            c.D.index.a5(c.BU) ? (this.T.contains(l.Rh[0].BU) || Yuc(this, l), this.D = g.LF(l.Rh)) : cGQ(this) && this.seekTo(this.player.getCurrentTime())
        }
        this.C.start()
    };
    g.P(dz, g.P1);
    g.J = dz.prototype;
    g.J.Co = function(l, c, Y) {
        var X = this;
        this.Lj();
        c = rG6(this, l.getId());
        c || (c = l.languageCode, c = this.D.isManifestless ? eqi(this, c, "386") : eqi(this, c));
        if (c) {
            var k = (c.index.N7(c.index.jl()) - c.index.getStartTime(c.index.jl())) * 1E3,
                r = this.V.L(),
                e = new g.Bmn(r),
                d = function() {
                    X.K && X.K.reset();
                    X.W = !0
                };
            r.B("html5_keep_caption_data_after_seek") && (d = null);
            this.K = new lIe(e, this.V, c, function(y, O) {
                Y.rX(y, l, O, k)
            }, this.C || g.I3(c.info), d)
        }
    };
    g.J.O0 = function() {
        var l = this.W;
        this.W = !1;
        return l
    };
    g.J.LO = function(l) {
        var c = this.V.L().B("html5_fallback_if_rawcc_missing");
        var Y = this.D.D.rawcc != null;
        if (!this.C || !Y && c) c = this.D.isManifestless ? kfN(this, "386") : kfN(this);
        else {
            if (!Y) {
                this.logger.D(386248249, "rawcc used but unavailable");
                return
            }
            c = [new g.GX({
                id: "rawcc",
                languageCode: "rawcc",
                languageName: "CC1",
                is_servable: !0,
                is_default: !0,
                is_translateable: !1,
                vss_id: ".en"
            }), new g.GX({
                id: "rawcc",
                languageCode: "rawcc",
                languageName: "CC3",
                is_servable: !0,
                is_default: !0,
                is_translateable: !1,
                vss_id: ".en"
            })]
        }
        c = g.b(c);
        for (Y = c.next(); !Y.done; Y = c.next()) g.fZ(this.G, Y.value);
        l.YA()
    };
    g.J.Lj = function() {
        this.K && (this.K.dispose(), this.K = null)
    };
    g.J.KD = function() {
        return ""
    };
    g.J.sD = function() {
        this.K && (this.K.reset(), this.V.EU("captions"))
    };
    var xc = /^#(?:[0-9a-f]{3}){1,2}$/i;
    var yGU = ["left", "right", "center", "justify"];
    g.P(y9, g.B);
    g.J = y9.prototype;
    g.J.pB = function(l, c) {
        this.uQ = l;
        this.iQ = c;
        var Y = g.ak(this.element, this.element.parentElement);
        this.ph = l - Y.x;
        this.Gc = c - Y.y
    };
    g.J.iP = function(l, c) {
        if (l !== this.uQ || c !== this.iQ) {
            g.kV(this.element, "ytp-dragging") || g.Jj(this.element, "ytp-dragging");
            var Y = g.pf(this.element);
            l = l - this.ph - .02 * this.playerWidth;
            var X = c - this.Gc - .02 * this.playerHeight,
                k = (l + Y.width / 2) / this.maxWidth * 3;
            k = Math.floor(g.b0(k, 0, 2));
            var r = (X + Y.height / 2) / this.maxHeight * 3;
            r = Math.floor(g.b0(r, 0, 2));
            c = k + r * 3;
            l = (l + k / 2 * Y.width) / this.maxWidth;
            l = g.b0(l, 0, 1) * 100;
            Y = (X + r / 2 * Y.height) / this.maxHeight;
            Y = g.b0(Y, 0, 1) * 100;
            this.G.params.F4 = c;
            this.G.params.UZ = Y;
            this.G.params.cK =
                l;
            this.G.params.isDefault = !1;
            this.D.F4 = c;
            this.D.UZ = Y;
            this.D.cK = l;
            this.D.isDefault = !1;
            this.Kh.F4 = c;
            this.Kh.UZ = Y;
            this.Kh.cK = l;
            this.Kh.isDefault = !1;
            this.Kn()
        }
    };
    g.J.mL = function() {
        g.yu(this.element, "ytp-dragging")
    };
    g.J.Kn = function() {
        this.yP(this.C)
    };
    g.J.getType = function() {
        return this.type
    };
    g.J.yP = function(l) {
        var c = this.V2 ? 0 : Math.min(this.n6(), this.maxWidth),
            Y = this.Yc(),
            X = this.V2;
        if (X) {
            var k = getComputedStyle(this.T.parentNode);
            k = On(k.borderLeftWidth) + On(k.borderRightWidth) + On(k.paddingLeft) + On(k.paddingRight)
        } else k = 0;
        var r = k;
        k = "";
        this.G.params.oH === 3 && (k = "rotate(180deg)");
        var e = X ? "calc(96% - " + r + "px)" : "96%";
        g.dg(this.element, {
            top: 0,
            left: 0,
            right: "",
            bottom: "",
            width: c ? c + "px" : "",
            height: Y ? Y + "px" : "",
            "max-width": e,
            "max-height": e,
            margin: "",
            transform: ""
        });
        this.EC(l);
        k = {
            transform: k,
            top: "",
            left: "",
            width: c ? c + "px" : "",
            height: Y ? Y + "px" : "",
            "max-width": "",
            "max-height": ""
        };
        var d = this.D.cK * .96 + 2;
        e = this.D.F4;
        switch (e) {
            case 0:
            case 3:
            case 6:
                (X = this.D.QF.fontSizeIncrement) && X > 0 && this.D.oH !== 2 && this.D.oH !== 3 && (d = Math.max(d / (1 + X * 2), 2));
                k.left = d + "%";
                break;
            case 1:
            case 4:
            case 7:
                k.left = d + "%";
                d = this.T.offsetWidth;
                c || d ? (c = c || d + 1, k.width = c + "px", k["margin-left"] = X ? c / -2 - r / 2 + "px" : c / -2 + "px") : k.transform += " translateX(-50%)";
                break;
            case 2:
            case 5:
            case 8:
                k.right = 100 - d + "%"
        }
        X = this.D.UZ * .96 + 2;
        switch (e) {
            case 0:
            case 1:
            case 2:
                k.top =
                    X + "%";
                break;
            case 3:
            case 4:
            case 5:
                k.top = X + "%";
                (Y = Y || this.element.clientHeight) ? (k.height = Y + "px", k["margin-top"] = Y / -2 + "px") : k.transform += " translateY(-50%)";
                break;
            case 6:
            case 7:
            case 8:
                k.bottom = 100 - X + "%"
        }
        g.dg(this.element, k);
        if (this.W) {
            Y = this.T.offsetHeight;
            X = 1;
            for (c = 0; c < l.length; c++) k = l[c], typeof k.text === "string" && (X += k.text.split("\n").length - 1, k.append || c === 0 || X++);
            Y /= X;
            this.W.style.height = Y + "px";
            this.W.style.width = Y + "px";
            this.element.style.paddingLeft = Y + 5 + "px";
            this.element.style.paddingRight = Y +
                5 + "px";
            l = Number(this.element.style.marginLeft.replace("px", "")) - Y - 5;
            Y = Number(this.element.style.marginRight.replace("px", "")) - Y - 5;
            this.element.style.marginLeft = l + "px";
            this.element.style.marginRight = Y + "px"
        }
    };
    g.J.EC = function(l) {
        var c;
        for (c = 0; c < l.length && l[c] === this.C[c]; c++);
        if (this.PU || this.C.length > c) c = 0, this.PU = !1, this.C = [], this.U = this.NQ = this.Ch = null, g.yD(this.T);
        for (; c < l.length; c++) GfL(this, l[c])
    };
    g.J.n6 = function() {
        return 0
    };
    g.J.Yc = function() {
        return 0
    };
    g.J.toString = function() {
        return g.B.prototype.toString.call(this)
    };
    PM7.prototype.clear = function() {
        this.K = this.time = this.mode = 0;
        this.D = [];
        this.reset()
    };
    PM7.prototype.reset = function() {
        this.mode = 0;
        this.T.reset(0);
        this.N.reset(1)
    };
    var bPa = [128, 1, 2, 131, 4, 133, 134, 7, 8, 137, 138, 11, 140, 13, 14, 143, 16, 145, 146, 19, 148, 21, 22, 151, 152, 25, 26, 155, 28, 157, 158, 31, 32, 161, 162, 35, 164, 37, 38, 167, 168, 41, 42, 171, 44, 173, 174, 47, 176, 49, 50, 179, 52, 181, 182, 55, 56, 185, 186, 59, 188, 61, 62, 191, 64, 193, 194, 67, 196, 69, 70, 199, 200, 73, 74, 203, 76, 205, 206, 79, 208, 81, 82, 211, 84, 213, 214, 87, 88, 217, 218, 91, 220, 93, 94, 223, 224, 97, 98, 227, 100, 229, 230, 103, 104, 233, 234, 107, 236, 109, 110, 239, 112, 241, 242, 115, 244, 117, 118, 247, 248, 121, 122, 251, 124, 253, 254, 127, 0, 129, 130, 3, 132, 5, 6, 135, 136, 9, 10, 139,
        12, 141, 142, 15, 144, 17, 18, 147, 20, 149, 150, 23, 24, 153, 154, 27, 156, 29, 30, 159, 160, 33, 34, 163, 36, 165, 166, 39, 40, 169, 170, 43, 172, 45, 46, 175, 48, 177, 178, 51, 180, 53, 54, 183, 184, 57, 58, 187, 60, 189, 190, 63, 192, 65, 66, 195, 68, 197, 198, 71, 72, 201, 202, 75, 204, 77, 78, 207, 80, 209, 210, 83, 212, 85, 86, 215, 216, 89, 90, 219, 92, 221, 222, 95, 96, 225, 226, 99, 228, 101, 102, 231, 232, 105, 106, 235, 108, 237, 238, 111, 240, 113, 114, 243, 116, 245, 246, 119, 120, 249, 250, 123, 252, 125, 126, 255
    ];
    D_.prototype.set = function(l) {
        this.type = l
    };
    D_.prototype.get = function() {
        return this.type
    };
    tB.prototype.clear = function() {
        this.state = 0
    };
    tB.prototype.update = function() {
        this.state = this.state === 2 ? 1 : 0
    };
    tB.prototype.UU = function() {
        return this.state !== 0
    };
    tB.prototype.matches = function(l, c) {
        return this.UU() && l === this.CZ && c === this.Fj
    };
    Rq6.prototype.reset = function() {
        this.timestamp = this.D = 0
    };
    Un.prototype.updateTime = function(l) {
        for (var c = 1; c <= 15; ++c)
            for (var Y = 1; Y <= 32; ++Y) this.K[c][Y].timestamp = l
    };
    Un.prototype.debugString = function() {
        for (var l = "\n", c = 1; c <= 15; ++c) {
            for (var Y = 1; Y <= 32; ++Y) {
                var X = this.K[c][Y];
                l = X.D === 0 ? l + "_" : l + String.fromCharCode(X.D)
            }
            l += "\n"
        }
        return l
    };
    Un.prototype.reset = function(l) {
        for (var c = 0; c <= 15; c++)
            for (var Y = 0; Y <= 32; Y++) this.K[c][Y].reset();
        this.T = l;
        this.D = 0;
        this.G = this.row = 1
    };
    var iPa = [32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 225, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 233, 93, 237, 243, 250, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 231, 247, 209, 241, 9632],
        SuQ = [174, 176, 189, 191, 8482, 162, 163, 9834, 224, 32, 232, 226, 234, 238, 244, 251],
        vxQ = [193, 201, 211, 218, 220, 252, 8216, 161, 42, 39, 9473, 169, 8480, 183, 8220, 8221, 192, 194, 199, 200, 202, 203, 235,
            206, 207, 239, 212, 217, 249, 219, 171, 187
        ],
        x87 = [195, 227, 205, 204, 236, 210, 242, 213, 245, 123, 125, 92, 94, 95, 124, 126, 196, 228, 214, 246, 223, 165, 164, 9475, 197, 229, 216, 248, 9487, 9491, 9495, 9499];
    HPe.prototype.reset = function(l, c) {
        this.N = c;
        this.style.set(2);
        this.G = this.W;
        this.T = this.C;
        this.D = this.G;
        var Y = (l << 2) + (c << 1);
        this.W.reset(Y);
        this.C.reset(Y);
        this.text.reset((l << 2) + (c << 1) + 1)
    };
    fIF.prototype.reset = function(l) {
        this.N = l;
        this.G.clear();
        this.T = this.K;
        this.K.reset(l, 0);
        this.W.reset(l, 1)
    };
    jL7.prototype.T = function() {};
    g.P(qo, g.r8);
    qo.prototype.toString = function() {
        return g.r8.prototype.toString.call(this)
    };
    g.P(au, g.C);
    au.prototype.Xf = function() {
        return []
    };
    au.prototype.reset = function() {};
    g.P(No, g.r8);
    No.prototype.toString = function() {
        return g.r8.prototype.toString.call(this)
    };
    var pC = 0;
    g.P(Ru, au);
    Ru.prototype.reset = function() {
        this.W = {};
        this.G = this.D = null;
        this.N = !0
    };
    Ru.prototype.Xf = function(l, c) {
        l = l.firstChild;
        l.getAttribute("format");
        c = c || 0;
        Number.isFinite(c);
        l = Array.from(l.childNodes);
        l = g.b(l);
        for (var Y = l.next(); !Y.done; Y = l.next())
            if (Y = Y.value, Y.nodeType === 1) switch (Y.tagName) {
                case "head":
                    var X = Y;
                    break;
                case "body":
                    var k = Y
            }
        if (X)
            for (X = Array.from(X.childNodes), X = g.b(X), l = X.next(); !l.done; l = X.next())
                if (l = l.value, l.nodeType === 1) switch (l.tagName) {
                    case "pen":
                        Y = l.getAttribute("id");
                        var r = this.pens,
                            e = {},
                            d = l.getAttribute("p");
                        d && Object.assign(e, this.pens[d]);
                        d = Sa(l, "b");
                        d != null && (e.bold = d);
                        d = Sa(l, "i");
                        d != null && (e.italic = d);
                        d = Sa(l, "u");
                        d != null && (e.underline = d);
                        d = v6(l, "et");
                        d != null && (e.charEdgeStyle = d);
                        d = v6(l, "of");
                        d != null && (e.offset = d);
                        d = zM(l, "bc");
                        d != null && (e.background = d);
                        d = zM(l, "ec");
                        d != null && (e.j2 = d);
                        d = zM(l, "fc");
                        d != null && (e.color = d);
                        d = v6(l, "fs");
                        d != null && d !== 0 && (e.fontFamily = d);
                        d = i$(l, "sz");
                        d !== void 0 && (e.fontSizeIncrement = d / 100 - 1);
                        d = i$(l, "bo");
                        d !== void 0 && (e.backgroundOpacity = d / 255);
                        d = i$(l, "fo");
                        d !== void 0 && (e.textOpacity = d / 255);
                        d = v6(l, "rb");
                        d != null && d !== 10 &&
                            d !== 0 && (e.Ni = d > 10 ? d - 1 : d);
                        l = v6(l, "hg");
                        l != null && (e.YI = l);
                        r[Y] = e;
                        break;
                    case "ws":
                        Y = l.getAttribute("id");
                        this.U[Y] = ZP7(this, l);
                        break;
                    case "wp":
                        Y = l.getAttribute("id"), this.C[Y] = $8Q(this, l)
                }
        if (k) {
            X = [];
            k = Array.from(k.childNodes);
            k = g.b(k);
            for (l = k.next(); !l.done; l = k.next())
                if (l = l.value, l.nodeType === 1) switch (l.tagName) {
                    case "w":
                        this.D = QLE(this, l, c, !1);
                        (l = this.W[this.D.id]) && l.end > this.D.start && (l.end = this.D.start);
                        this.W[this.D.id] = this.D;
                        X.push(this.D);
                        break;
                    case "p":
                        var y = l;
                        d = c;
                        Y = [];
                        r = y.getAttribute("w") ||
                            this.T;
                        e = !!Sa(y, "a");
                        d = (i$(y, "t") || 0) + d;
                        var O = i$(y, "d") || 5E3;
                        e || (!this.N && this.G && this.G.windowId === r && this.G.end > d && (this.G.end = d), this.G && this.G.text === "\n" && (this.G.text = ""));
                        var D = e ? 6 : 5,
                            t = y.getAttribute("p");
                        t = t ? this.pens[t] : null;
                        var U = Array.from(y.childNodes);
                        U.length && (this.N = y.getAttribute("d") != null);
                        for (y = 0; y < U.length; y++) {
                            var G = U[y],
                                f = void 0;
                            y > 0 && (e = !0);
                            var a = void 0;
                            G.nodeType === 1 && (a = G);
                            if (a && a.tagName === "s") {
                                if ((G = (G = a.getAttribute("p")) ? this.pens[G] : null) && G.Ni && (G.Ni === 1 ? (G = U.slice(y,
                                        y + 4), G.length === 4 && (f = oxc(d, O, r, e, D, G, this.pens), y += 3)) : f = oxc(d, O, r, e, D, [a], this.pens)), !f) {
                                    var p = a;
                                    f = d;
                                    a = O;
                                    G = r;
                                    var S = e,
                                        x = D,
                                        h = p.textContent ? p.textContent : "",
                                        K = p.getAttribute("p");
                                    K = K ? this.pens[K] : null;
                                    p = i$(p, "t") || 0;
                                    f = new qo(f + p, a - p, x, G, h, S, K)
                                }
                            } else f = new qo(d, O, D, r, G.textContent || "", e, t);
                            Y.push(f);
                            this.G = f
                        }
                        if (Y.length > 0)
                            for (Y[0].windowId === this.T && (this.D = QLE(this, l, c, !0), X.push(this.D)), l = g.b(Y), Y = l.next(); !Y.done; Y = l.next()) Y = Y.value, Y.windowId = this.D.id, this.D.D.push(Y), X.push(Y)
                }
            c = X
        } else c = [];
        return c
    };
    var imM = new Map([
        [9, 1],
        [10, 1],
        [11, 2],
        [12, 3],
        [13, 4],
        [14, 5]
    ]);
    g.P(nC, au);
    nC.prototype.reset = function() {
        this.G.clear()
    };
    nC.prototype.Xf = function(l, c) {
        var Y = JSON.parse(l);
        if (!Y) return [];
        if (Y.pens) {
            l = 0;
            for (var X = g.b(Y.pens), k = X.next(); !k.done; k = X.next()) {
                k = k.value;
                var r = {},
                    e = k.pParentId;
                e && Object.assign(r, this.D.get(e));
                k.bAttr && (r.bold = !0);
                k.iAttr && (r.italic = !0);
                k.uAttr && (r.underline = !0);
                e = k.ofOffset;
                e != null && (r.offset = e);
                k.szPenSize !== void 0 && (r.fontSizeIncrement = k.szPenSize / 100 - 1);
                e = k.etEdgeType;
                e != null && (r.charEdgeStyle = e);
                k.ecEdgeColor !== void 0 && (r.j2 = hB(k.ecEdgeColor));
                e = k.fsFontStyle;
                e != null && e !== 0 && (r.fontFamily =
                    e);
                k.fcForeColor !== void 0 && (r.color = hB(k.fcForeColor));
                k.foForeAlpha !== void 0 && (r.textOpacity = k.foForeAlpha / 255);
                k.bcBackColor !== void 0 && (r.background = hB(k.bcBackColor));
                k.boBackAlpha !== void 0 && (r.backgroundOpacity = k.boBackAlpha / 255);
                (e = k.rbRuby) && e !== 10 && (r.Ni = e > 10 ? e - 1 : e, r.textEmphasis = imM.get(r.Ni));
                k.hgHorizGroup && (r.YI = k.hgHorizGroup);
                this.D.set(l++, r)
            }
        }
        if (Y.wsWinStyles)
            for (l = 0, X = g.b(Y.wsWinStyles), k = X.next(); !k.done; k = X.next()) k = k.value, r = {}, (e = k.wsParentId) ? Object.assign(r, this.T.get(e)) : Object.assign(r,
                this.N), k.mhModeHint !== void 0 && (r.sF = k.mhModeHint), k.juJustifCode !== void 0 && (r.textAlign = k.juJustifCode), k.pdPrintDir !== void 0 && (r.oH = k.pdPrintDir), k.sdScrollDir !== void 0 && (r.gV = k.sdScrollDir), k.wfcWinFillColor !== void 0 && (r.windowColor = hB(k.wfcWinFillColor)), k.wfoWinFillAlpha !== void 0 && (r.windowOpacity = k.wfoWinFillAlpha / 255), this.T.set(l++, r);
        if (Y.wpWinPositions)
            for (l = 0, X = g.b(Y.wpWinPositions), k = X.next(); !k.done; k = X.next()) k = k.value, r = {}, (e = k.wpParentId) && Object.assign(r, this.K.get(e)), k.ahHorPos !==
                void 0 && (r.cK = k.ahHorPos), k.apPoint !== void 0 && (r.F4 = k.apPoint), k.avVerPos !== void 0 && (r.UZ = k.avVerPos), k.ccCols !== void 0 && (r.EP = k.ccCols), k.rcRows !== void 0 && (r.SU = k.rcRows), this.K.set(l++, r);
        if (Y.events) {
            l = [];
            Y = g.b(Y.events);
            for (X = Y.next(); !X.done; X = Y.next()) {
                var d = X.value;
                k = (d.tStartMs || 0) + c;
                r = d.dDurationMs || 0;
                if (d.id) e = String(d.id), X = m8F(this, d, k, r, e), l.push(X), this.G.set(e, X);
                else {
                    d.wWinId ? e = d.wWinId.toString() : (e = "_" + pC++, X = m8F(this, d, k, r, e), l.push(X), this.G.set(e, X));
                    X = l;
                    var y = d;
                    r === 0 && (r = 5E3);
                    d = this.G.get(e);
                    var O = !!y.aAppend,
                        D = O ? 6 : 5,
                        t = y.segs,
                        U = null;
                    y.pPenId && (U = this.D.get(y.pPenId));
                    for (y = 0; y < t.length; y++) {
                        var G = t[y],
                            f = G.utf8;
                        if (f) {
                            var a = G.tOffsetMs || 0,
                                p = null;
                            G.pPenId && (p = this.D.get(G.pPenId));
                            if ((d.params.sF != null ? d.params.sF : d.D.length > 1 ? 1 : 0) === 2 && O && f === "\n") continue;
                            G = null;
                            var S = [],
                                x;
                            if (x = p && p.Ni === 1) {
                                x = t;
                                var h = y;
                                if (h + 3 >= x.length || !x[h + 1].pPenId || !x[h + 2].pPenId || !x[h + 3].pPenId) x = !1;
                                else {
                                    var K = x[h + 1].pPenId;
                                    (K = this.D.get(K)) && K.Ni && K.Ni === 2 ? (K = x[h + 2].pPenId, K = this.D.get(K), !K || !K.Ni ||
                                        K.Ni < 3 ? x = !1 : (K = x[h + 3].pPenId, x = (K = this.D.get(K)) && K.Ni && K.Ni === 2 ? !0 : !1)) : x = !1
                                }
                            }
                            if (x) a = t[y + 1].utf8, G = t[y + 3].utf8, x = t[y + 2].utf8, h = this.D.get(t[y + 2].pPenId), f = VR7(f, a, x, G, h), G = new qo(k, r, D, e, f, O, p), y += 3;
                            else {
                                if (f.indexOf("<") > -1) {
                                    var Q = void 0;
                                    S = p;
                                    x = U;
                                    h = k;
                                    K = r;
                                    var lc = a,
                                        E = D,
                                        kv = O,
                                        Jg = [],
                                        I = g.Le("<html>" + f + "</html>");
                                    if (!I.getElementsByTagName("parsererror").length && ((Q = I.firstChild) == null ? 0 : Q.childNodes.length))
                                        for (Q = g.b(I.firstChild.childNodes), I = Q.next(); !I.done; I = Q.next()) {
                                            I = I.value;
                                            var W = void 0,
                                                F = void 0,
                                                q = (F = (W = I.textContent) == null ? void 0 : W.replace(/\n/g, "")) != null ? F : "";
                                            if (I.nodeType !== 3 || q && q.match(/^ *$/) == null) {
                                                W = {};
                                                Object.assign(W, S || x);
                                                F = void 0;
                                                switch ((F = I) == null ? void 0 : F.tagName) {
                                                    case "b":
                                                        W.bold = !0;
                                                        break;
                                                    case "i":
                                                        W.italic = !0;
                                                        break;
                                                    case "u":
                                                        W.underline = !0
                                                }
                                                Jg.push(new qo(h + lc, K - lc, E, d.id, q, kv, W))
                                            }
                                        }
                                    S = Jg
                                }
                                S.length || (S = [new qo(k + a, r - a, D, d.id, f, O, p || U)])
                            }
                            if (S.length)
                                for (O = g.b(S), p = O.next(); !p.done; p = O.next()) p = p.value, X.push(p), d.D.push(p);
                            else G && (X.push(G), d.D.push(G))
                        }
                        O = !0
                    }
                }
            }
            c = l
        } else c = [];
        return c
    };
    g.P(H6, g.P1);
    H6.prototype.Co = function(l, c, Y) {
        L7E(this.videoData.videoId, l.vssId, Y.rX)
    };
    H6.prototype.LO = function(l) {
        if (this.audioTrack)
            for (var c = g.b(this.audioTrack.captionTracks), Y = c.next(); !Y.done; Y = c.next()) g.fZ(this.G, Y.value);
        l.YA()
    };
    g.P(wz, y9);
    wz.prototype.EC = function(l) {
        var c = this.G.D;
        y9.prototype.EC.call(this, l);
        for (l = l.length; l < c.length; l++) {
            var Y = c[l];
            if (r && Y.D === k) var X = r;
            else {
                X = {};
                Object.assign(X, Y.D);
                Object.assign(X, SIV);
                var k = Y.D;
                var r = X
            }
            GfL(this, Y, X)
        }
    };
    var SIV = {
        Ohf: !0
    };
    g.P(KC, jL7);
    KC.prototype.T = function(l, c, Y, X, k) {
        if (Y < X) {
            var r = "_" + pC++;
            Y = Y / 1E3 - this.W;
            X = X / 1E3 - this.W;
            l = new No(Y, X - Y, 5, r, {
                textAlign: 0,
                F4: 0,
                cK: c * 2.5,
                UZ: l * 5.33
            });
            k = new qo(Y, X - Y, 5, r, k);
            this.G.push(l);
            this.G.push(k)
        }
    };
    g.P(ou, au);
    ou.prototype.Xf = function(l) {
        l = new KC(l, l.byteLength, this.G);
        if (W3V(l)) {
            for (; l.byteOffset < l.D.byteLength;)
                for (l.version === 0 ? l.K = V9(l) * (1E3 / 45) : l.version === 1 && (l.K = V9(l) * 4294967296 + V9(l)), l.N = TM(l); l.N > 0; l.N--) {
                    var c = TM(l),
                        Y = TM(l),
                        X = TM(l);
                    c & 4 && (c & 3) === this.track && (this.track === 0 || this.track === 1) && (c = this.D, c.D.push({
                        time: l.K,
                        type: this.track,
                        IW: Y,
                        FZ: X,
                        order: c.D.length
                    }))
                }
            psM(this.D, l);
            return l.G
        }
        return []
    };
    ou.prototype.reset = function() {
        this.D.clear()
    };
    g.P(CC, y9);
    g.J = CC.prototype;
    g.J.Kn = function() {
        g.AL(this.nh)
    };
    g.J.To = function() {
        this.Ed && this.element.removeEventListener("transitionend", this.To, !1);
        g.yu(this.element, "ytp-rollup-mode");
        this.yP(this.OV, !0)
    };
    g.J.Yc = function() {
        return this.K ? this.AJ : this.j
    };
    g.J.n6 = function() {
        return this.K ? this.j : this.AJ
    };
    g.J.yP = function(l, c) {
        this.OV = l;
        if (this.G.params.SU) {
            for (var Y = 0, X = 0; X < this.C.length && Y < l.length; X++) this.C[X] === l[Y] && Y++;
            Y > 0 && Y < l.length && (l = this.C.concat(l.slice(Y)));
            this.MJ = this.AJ;
            this.j = this.AJ = 0;
            y9.prototype.yP.call(this, l);
            L3Q(this, c)
        }
        y9.prototype.yP.call(this, l)
    };
    ExE.prototype.unload = function() {
        this.D != null && (this.V.removeEventListener("sabrCaptionsDataLoaded", this.D), this.D = null);
        this.eC = [];
        this.V.publish("sabrCaptionsBufferedRangesUpdated", this.eC)
    };
    ExE.prototype.rN = function(l) {
        return {
            formatId: g.cX(l.info.D.info, this.Hu),
            BU: l.info.BU + (this.Hu ? 0 : 1),
            startTimeMs: l.info.T * 1E3,
            durationMs: l.info.U * 1E3
        }
    };
    g.P(F3e, g.P1);
    g.J = F3e.prototype;
    g.J.Co = function(l, c, Y) {
        this.Lj();
        c = l.getId();
        c = c != null && c in this.D.D ? this.D.D[c] : null;
        c || (c = l.languageCode, c = this.D.isManifestless ? l16(this, c, "386") : l16(this, c));
        c && (this.K = l, this.W = c, AGc(this.C, Y), this.V.publish("sabrCaptionsTrackChanged", g.cX(c.info, this.D.Hu)))
    };
    g.J.LO = function(l) {
        var c = this.D.isManifestless ? IIe(this, "386") : IIe(this);
        c = g.b(c);
        for (var Y = c.next(); !Y.done; Y = c.next()) g.fZ(this.G, Y.value);
        l.YA()
    };
    g.J.Lj = function() {
        this.K && (this.K = this.W = null, this.C.unload(), this.V.publish("sabrCaptionsTrackChanged", null))
    };
    g.J.KD = function() {
        return ""
    };
    g.J.sD = function() {
        this.V.EU("captions")
    };
    g.P(Z_, au);
    Z_.prototype.Xf = function(l, c) {
        var Y = [];
        l = l.split(vP7);
        for (var X = 1; X < l.length; X++) {
            var k = l[X],
                r = c;
            if (k !== "" && !x5M.test(k)) {
                var e = zPL.exec(k);
                if (e && e.length >= 4) {
                    var d = Xaa(e[1]),
                        y = Xaa(e[2]) - d;
                    d += r;
                    var O = (e = e[3]) ? e.split(" ") : [];
                    e = {};
                    var D = null;
                    var t = "";
                    var U = null,
                        G = "";
                    O = g.b(O);
                    for (var f = O.next(); !f.done; f = O.next())
                        if (f = f.value.split(":"), f.length === 2) {
                            var a = f[1];
                            switch (f[0]) {
                                case "line":
                                    f = a.split(",");
                                    f[0].endsWith("%") && (D = f[0], e.UZ = Number.parseInt(D, 10), f.length === 2 && (t = f[1].trim()));
                                    break;
                                case "position":
                                    f =
                                        a.split(",");
                                    U = f[0];
                                    e.cK = Number.parseInt(U, 10);
                                    f.length === 2 && (G = f[1].trim());
                                    break;
                                case "align":
                                    switch (a) {
                                        case "start":
                                            e.textAlign = 0;
                                            break;
                                        case "middle":
                                            e.textAlign = 2;
                                            break;
                                        case "end":
                                            e.textAlign = 1
                                    }
                            }
                        }
                    D || t || (t = "end");
                    if (!U) switch (e.textAlign) {
                        case 0:
                            e.cK = 0;
                            break;
                        case 1:
                            e.cK = 100;
                            break;
                        case 2:
                            e.cK = 50
                    }
                    if (e.textAlign != null) {
                        D = 0;
                        switch (t) {
                            case "center":
                                D += 3;
                                break;
                            case "end":
                                D += 6;
                                break;
                            default:
                                D += 0
                        }
                        switch (G) {
                            case "line-left":
                                D += 0;
                                break;
                            case "center":
                                D += 1;
                                break;
                            case "line-right":
                                D += 2;
                                break;
                            default:
                                switch (e.textAlign) {
                                    case 0:
                                        D +=
                                            0;
                                        break;
                                    case 2:
                                        D += 1;
                                        break;
                                    case 1:
                                        D += 2
                                }
                        }
                        t = D < 0 || D > 8 ? 7 : D;
                        e.F4 = t
                    }
                    k = k.substring(zPL.lastIndex).replace(/[\x01-\x09\x0b-\x1f]/g, "");
                    G = e;
                    e = k;
                    k = {};
                    if (e.indexOf("<") < 0 && e.indexOf("&") < 0) r = kxc(d, y, 5, G), y = new qo(d, y, 5, r.id, e, !1, g.VS(k) ? void 0 : k), Y.push(r), Y.push(y), r.D.push(y);
                    else
                        for (t = e.split(nPL), t.length === 1 ? (e = 5, G = kxc(d, y, e, G)) : (D = e = 6, G = Object.assign({
                                EP: 32
                            }, G), G = new No(d, y, D, "_" + pC++, G)), Y.push(G), D = d, U = 0; U < t.length; U++) O = t[U], U % 2 === 0 ? (f = g.Le("<html>" + O + "</html>"), f.getElementsByTagName("parsererror").length ?
                            (a = f.createElement("span"), a.appendChild(f.createTextNode(O))) : a = f.firstChild, YIi(this, D, y - (D - d), e, G, U > 0, a, k, Y)) : D = Xaa(O) + r
                }
                zPL.lastIndex = 0
            }
        }
        return Y
    };
    var x5M = /^NOTE/,
        vP7 = /(?:\r\n|\r|\n){2,}/,
        zPL = RegExp("^((?:[\\d]{2}:)?[\\d]{2}:[\\d]{2}\\.[\\d]{3})[\\t ]+--\x3e[\\t ]+((?:[\\d]{2}:)?[\\d]{2}:[\\d]{2}\\.[\\d]{3})(?:[\\t ]*)(.*)(?:\\r\\n|\\r|\\n)", "gm"),
        nPL = RegExp("<((?:[\\d]{2}:)?[\\d]{2}:[\\d]{2}\\.[\\d]{3})>");
    g.Tz.Rk(Z_, {
        Xf: "wvppt"
    });
    g.P($c, g.C);
    $c.prototype.Xf = function(l, c, Y, X) {
        X = X || 0;
        Y = ePN(this, l, Y || 0);
        l = [];
        try {
            for (var k = g.b(Y), r = k.next(); !r.done; r = k.next()) {
                var e = r.value,
                    d = e.trackData,
                    y = e.Ac;
                if (typeof d !== "string") {
                    Y = l;
                    var O = Y.concat,
                        D = c,
                        t = d,
                        U = y,
                        G = X;
                    if (!MRF(t)) throw Error("Invalid binary caption track data");
                    this.D || (this.D = new ou(G, D));
                    var f = this.D.Xf(t, U);
                    var a = O.call(Y, f)
                } else {
                    if (d.substring(0, 6) === "WEBVTT") {
                        Y = l;
                        var p = Y.concat;
                        this.D || (this.D = new Z_);
                        var S = this.D.Xf(d, y);
                        Math.random() < .01 && g.Cj(Error("Deprecated subtitles format in web player: WebVTT"));
                        var x =
                            p.call(Y, S)
                    } else {
                        Y = l;
                        var h = Y.concat;
                        a: {
                            D = c;
                            if (d[0] === "{") try {
                                this.D || (this.D = new nC(J87(D)));
                                var K = this.D.Xf(d, y);
                                break a
                            } catch (I) {
                                g.ot(I);
                                K = [];
                                break a
                            }
                            var Q = g.Le(d);
                            if (!Q || !Q.firstChild) {
                                var lc = Error("Invalid caption track data");
                                lc.params = d;
                                throw lc;
                            }
                            if (Q.firstChild.tagName === "timedtext") {
                                if (Number(Q.firstChild.getAttribute("format")) === 3) {
                                    t = Q;
                                    this.D || (this.D = new Ru(J87(D), this.fh));
                                    K = this.D.Xf(t, y);
                                    break a
                                }
                                var E = Error("Unsupported subtitles format in web player (Format2)");
                                E.params = d;
                                throw E;
                            }
                            if (Q.firstChild.tagName ===
                                "transcript") {
                                var kv = Error("Unsupported subtitles format in web player (Format1)");
                                kv.params = d;
                                throw kv;
                            }
                            var Jg = Error("Invalid caption track data");Jg.params = d;
                            throw Jg;
                        }
                        x = h.call(Y, K)
                    }
                    a = x
                }
                l = a
            }
            return l
        } catch (I) {
            return this.logger.D(187101178, "Captions parsing failed: " + I.message + ". "), this.clear(), []
        }
    };
    $c.prototype.clear = function() {
        this.D && this.D.dispose();
        this.D = null
    };
    $c.prototype.reset = function() {
        this.D && this.D.reset()
    };
    $c.prototype.Tz = function() {
        g.C.prototype.Tz.call(this);
        this.clear()
    };
    var gz = {
        windowColor: "#080808",
        windowOpacity: 0,
        textAlign: 2,
        F4: 7,
        cK: 50,
        UZ: 100,
        isDefault: !0,
        QF: {
            background: "#080808",
            backgroundOpacity: .75,
            charEdgeStyle: 0,
            color: "#fff",
            fontFamily: 4,
            fontSizeIncrement: 0,
            textOpacity: 1,
            offset: 1
        }
    };
    g.P(Q9, g.GH);
    g.J = Q9.prototype;
    g.J.Tz = function() {
        if (this.N || this.PU) {
            var l = this.V.Vx();
            l && !l.vU() && l.uJ()
        } else RPE(this, !1);
        g.GH.prototype.Tz.call(this)
    };
    g.J.e$ = function() {
        return this.fh.B("html5_honor_caption_availabilities_in_audio_track") && this.T !== "LIVE" && this.T !== "SABR_LIVE"
    };
    g.J.PH = function() {
        if (this.nh) return this.N || this.PU;
        var l = this.getAudioTrack();
        if (this.e$()) {
            if (!l.captionTracks.length) return !1;
            if (!this.D) return !0
        }
        l = W7L(l, g.A2(this.fh));
        return l === "CAPTIONS_INITIAL_STATE_ON_REQUIRED" ? !0 : l === "CAPTIONS_INITIAL_STATE_OFF_REQUIRED" ? ms(this) : D5L(this) || ms(this) ? !0 : tui(this)
    };
    g.J.load = function() {
        g.GH.prototype.load.call(this);
        this.j = this.getAudioTrack();
        if (this.D) this.G && (this.Ud.clear(), this.N ? GxF(this, !0) : this.player.getPresentingPlayerType() !== 3 && this.D.Co(this.G, "json3", this.V2), this.N || this.PU || sn(this) || this.player.fV("captionschanged", g.PZ(this.G)));
        else {
            var l;
            this.T === "OFFLINE" ? l = new H6(this.player, this.videoData, this.getAudioTrack()) : this.T === "SABR_LIVE" ? l = new F3e(this.videoData.D, this.player) : this.T === "LIVE" ? l = new dz(this.videoData.D, this.player) : this.T === "INNERTUBE" ?
                l = new g.bg(this.player, this.videoData, this.getAudioTrack()) : l = new g.aS(this.player, this.videoData.EG, this.videoData.videoId, g.GKL(this.videoData), this.videoData.y6, this.videoData.eventId);
            this.D = l;
            g.Z(this, this.D);
            this.D.LO(this.V2)
        }
    };
    g.J.unload = function() {
        this.N && this.G ? GxF(this, !1) : (this.yf && g.FY(this.yf), this.player.EU("captions"), this.Ch = [], this.D && this.D.Lj(), this.Ud.clear(), this.AJ && this.player.jk(this.AJ), this.FA());
        g.GH.prototype.unload.call(this);
        this.player.N9();
        this.player.fV("captionschanged", {})
    };
    g.J.create = function() {
        this.PH() && this.load();
        var l;
        a: {
            var c, Y, X;
            if (this.fh.B("web_player_nitrate_promo_tooltip") && ((c = this.videoData.getPlayerResponse()) == null ? 0 : (Y = c.captions) == null ? 0 : (X = Y.playerCaptionsTracklistRenderer) == null ? 0 : X.enableTouchCaptionsNitrate)) {
                var k, r;
                if (c = (l = this.videoData.getPlayerResponse()) == null ? void 0 : (k = l.captions) == null ? void 0 : (r = k.playerCaptionsTracklistRenderer) == null ? void 0 : r.captionTracks)
                    for (l = g.b(c), k = l.next(); !k.done; k = l.next())
                        if (k = k.value, k.kind === "asr" && k.languageCode ===
                            "en") {
                            l = !0;
                            break a
                        }
            }
            l = !1
        }
        l && this.V.publish("showpromotooltip", this.C.element)
    };
    g.J.YA = function() {
        var l = W7L(this.player.getAudioTrack(), g.A2(this.fh));
        var c = l === "CAPTIONS_INITIAL_STATE_ON_REQUIRED" ? Mo(this, this.U) : l === "CAPTIONS_INITIAL_STATE_OFF_REQUIRED" && ms(this) ? W6(this) : D5L(this) || this.U || tui(this) ? Mo(this, this.U) : ms(this) ? W6(this) : null;
        if (this.N || this.PU) {
            var Y = g.c1(this.D.G, !0);
            l = [];
            for (var X = 0; X < Y.length; X++) {
                var k = Y[X],
                    r = g.eR("TRACK");
                r.setAttribute("kind", "subtitles");
                r.setAttribute("label", g.fu(k));
                r.setAttribute("srclang", g.bz(k));
                r.setAttribute("id", k.toString());
                this.PU || r.setAttribute("src", this.D.KD(k, "vtt"));
                k === c && r.setAttribute("default", "1");
                l.push(r)
            }
            c = this.V.Vx();
            c.Zi(l);
            l = c.kM();
            this.Gc && this.JJ.Z(l.textTracks, "change", this.urf)
        } else !this.G && c && En(this, c), this.player.fV("onCaptionsTrackListChanged"), this.player.Fr("onApiChange")
    };
    g.J.urf = function() {
        for (var l = this.V.Vx().kM().textTracks, c = null, Y = 0; Y < l.length; Y++)
            if (l[Y].mode === "showing") a: {
                c = g.c1(this.D.G, !0);
                for (var X = 0; X < c.length; X++)
                    if (c[X].toString() === l[Y].id) {
                        c = c[X];
                        break a
                    }
                c = null
            }(this.loaded ? this.G : null) !== c && En(this, c, !0)
    };
    g.J.vAf = function() {
        !this.G && this.N || this.unload()
    };
    g.J.rX = function(l, c, Y, X) {
        if (l) {
            var k;
            P_E(this, (k = this.G) != null ? k : void 0);
            this.D.O0() && (this.Ch = [], this.V.EU("captions"), ea(this.NQ), this.Ud.reset());
            if (this.videoData.wC) {
                var r;
                Y = ((r = Y) != null ? r : 0) + this.videoData.wC
            }
            l = this.Ud.Xf(l, c, Y, X);
            if (this.uQ)
                for (c = g.b(l), Y = c.next(); !Y.done; Y = c.next()) Y = Y.value, Y.K = this.videoData.clientPlaybackNonce, Y.KF = this.videoData.wC;
            c = !this.fh.B("html5_keep_caption_data_after_seek") && (this.T === "LIVE" || this.T === "SABR_LIVE");
            this.player.jk(l, void 0, c);
            !this.U || this.PU || sn(this) ||
                g.nz(this.fh) || g.o1(this.fh) || g.Zq(this.fh) || this.fh.PU === "shortspage" || this.player.isInline() || (g.FY(this.yf), l = CMQ({
                    F4: 0,
                    cK: 5,
                    UZ: 5,
                    SU: 2,
                    textAlign: 0,
                    oH: 0,
                    lang: "en"
                }), this.ZA = [l], c = ["Click ", " for settings"], this.iQ || (Y = new g.tu(g.HA()), g.Z(this, Y), this.iQ = Y.element), Y = l.end - l.start, (X = g.fu(this.G)) && this.ZA.push(new qo(l.start, Y, 0, l.id, X)), this.ZA.push(new qo(l.start, Y, 0, l.id, c[0]), new qo(l.start, Y, 0, l.id, this.iQ, !0), new qo(l.start, Y, 0, l.id, c[1], !0)), this.player.jk(this.ZA), g.uf(this.yf));
            !this.U ||
                this.PU || sn(this) || (g.A2(this.fh) ? B6(this, !0) : LC(this, !0), this.j && (this.j.T = this.G), this.player.N9());
            this.U = !1
        }
    };
    g.J.onCueRangeEnter = function(l) {
        this.Ch.push(l);
        ea(this.NQ)
    };
    g.J.onCueRangeExit = function(l) {
        g.IU(this.Ch, l);
        this.D instanceof dz && this.D.C && this.player.xP([l]);
        ea(this.NQ)
    };
    g.J.getCaptionWindowContainerId = function() {
        return this.C.element.id
    };
    g.J.ouT = function() {
        paQ(this, this.ZA);
        this.ZA = null
    };
    g.J.XA = function() {
        var l = this;
        if (!this.Pu || !this.N) {
            this.NQ.stop();
            g.WVy(this.Ed);
            this.Ch.sort(g.ej);
            var c = this.Ch;
            if (this.AJ) {
                var Y = g.yo(c, function(r) {
                    return this.AJ.indexOf(r) === -1
                }, this);
                Y.length && (c = Y)
            }
            c = g.b(c);
            for (Y = c.next(); !Y.done; Y = c.next()) qIN(this, Y.value);
            c = g.b(Object.entries(this.xT));
            var X = c.next();
            for (Y = {}; !X.done; Y = {
                    n9: void 0,
                    TB: void 0
                }, X = c.next()) {
                var k = g.b(X.value);
                X = k.next().value;
                k = k.next().value;
                Y.n9 = X;
                Y.TB = k;
                this.Ed[Y.n9] ? (Y.TB.element.parentNode || (Y.TB instanceof CC || Y.TB instanceof wz || g.n8(this.xT, function(r) {
                    return function(e, d) {
                        d !== r.n9 && e.G.params.F4 === r.TB.G.params.F4 && e.G.params.cK === r.TB.G.params.cK && e.G.params.UZ === r.TB.G.params.UZ && (e.dispose(), delete l.xT[d]);
                        return d === r.n9
                    }
                }(Y), this), this.C.element.appendChild(Y.TB.element)), Y.TB.yP(this.Ed[Y.n9])) : (Y.TB.dispose(), delete this.xT[Y.n9])
            }
        }
    };
    g.J.miA = function() {
        y8N(this, {}, !0);
        this.player.fV("captionssettingschanged")
    };
    g.J.jB = function() {
        var l = gz.QF;
        l = {
            background: l.background,
            backgroundOpacity: l.backgroundOpacity,
            charEdgeStyle: l.charEdgeStyle,
            color: l.color,
            fontFamily: l.fontFamily,
            fontSizeIncrement: l.fontSizeIncrement,
            fontStyle: l.bold && l.italic ? 3 : l.bold ? 1 : l.italic ? 2 : 0,
            textOpacity: l.textOpacity,
            windowColor: gz.windowColor,
            windowOpacity: gz.windowOpacity
        };
        var c = F7N() || {};
        c.background != null && (l.background = c.background);
        c.backgroundOverride != null && (l.backgroundOverride = c.backgroundOverride);
        c.backgroundOpacity != null && (l.backgroundOpacity =
            c.backgroundOpacity);
        c.backgroundOpacityOverride != null && (l.backgroundOpacityOverride = c.backgroundOpacityOverride);
        c.charEdgeStyle != null && (l.charEdgeStyle = c.charEdgeStyle);
        c.charEdgeStyleOverride != null && (l.charEdgeStyleOverride = c.charEdgeStyleOverride);
        c.color != null && (l.color = c.color);
        c.colorOverride != null && (l.colorOverride = c.colorOverride);
        c.fontFamily != null && (l.fontFamily = c.fontFamily);
        c.fontFamilyOverride != null && (l.fontFamilyOverride = c.fontFamilyOverride);
        c.fontSizeIncrement != null && (l.fontSizeIncrement =
            c.fontSizeIncrement);
        c.fontSizeIncrementOverride != null && (l.fontSizeIncrementOverride = c.fontSizeIncrementOverride);
        c.fontStyle != null && (l.fontStyle = c.fontStyle);
        c.fontStyleOverride != null && (l.fontStyleOverride = c.fontStyleOverride);
        c.textOpacity != null && (l.textOpacity = c.textOpacity);
        c.textOpacityOverride != null && (l.textOpacityOverride = c.textOpacityOverride);
        c.windowColor != null && (l.windowColor = c.windowColor);
        c.windowColorOverride != null && (l.windowColorOverride = c.windowColorOverride);
        c.windowOpacity != null &&
            (l.windowOpacity = c.windowOpacity);
        c.windowOpacityOverride != null && (l.windowOpacityOverride = c.windowOpacityOverride);
        return l
    };
    g.J.O2 = function(l, c) {
        var Y = {};
        Object.assign(Y, F7N());
        Object.assign(Y, l);
        y8N(this, Y, c);
        this.player.fV("captionssettingschanged")
    };
    g.J.FA = function() {
        !this.N && this.loaded && (g.v0(this.xT, function(l, c) {
            l.dispose();
            delete this.xT[c]
        }, this), this.XA())
    };
    g.J.tC = function(l, c) {
        switch (l) {
            case "fontSize":
                if (isNaN(c)) break;
                l = g.b0(c, -2, 4);
                this.O2({
                    fontSizeIncrement: l
                });
                return l;
            case "reload":
                c && !this.N && En(this, this.G, !0);
                break;
            case "stickyLoading":
                c !== void 0 && this.fh.C && (g.A2(this.fh) ? B6(this, !!c) : LC(this, !!c));
                break;
            case "track":
                return N3U(this, c);
            case "tracklist":
                return this.D ? g.vL(g.c1(this.D.G, !(!c || !c.includeAsr)), function(Y) {
                    return g.PZ(Y)
                }) : [];
            case "translationLanguages":
                return this.D ? this.D.N.map(function(Y) {
                    return Object.assign({}, Y)
                }) : [];
            case "sampleSubtitles":
                this.N || c === void 0 || RPE(this, !!c);
                break;
            case "sampleSubtitlesCustomized":
                this.N || RPE(this, !!c, c);
                break;
            case "recommendedTranslationLanguages":
                return g.sc();
            case "defaultTranslationSourceTrackIndices":
                return this.D ? this.D.U : []
        }
    };
    g.J.getOptions = function() {
        var l = "reload fontSize track tracklist translationLanguages sampleSubtitle".split(" ");
        this.fh.C && l.push("stickyLoading");
        return l
    };
    g.J.Ko = function() {
        var l = this.G;
        if (this.V.b7("captions")) {
            if (this.fh.B("html5_modify_caption_vss_logging")) {
                var c;
                return (l = (c = this.videoData.lm) != null ? c : null) ? {
                    cc: g.KLS(l)
                } : {}
            }
            if (l) return c = l.vssId, l.translationLanguage && c && (c = "t" + c + "." + g.bz(l)), {
                cc: c
            }
        }
        return {}
    };
    g.J.zTf = function() {
        this.isSubtitlesOn() ? (g.A2(this.fh) ? B6(this, !1) : LC(this, !1), P_E(this), En(this, null, !0)) : this.kp()
    };
    g.J.kp = function() {
        var l = sn(this) || !this.G ? Mo(this, !0) : this.G;
        l && this.RD(l.vssId, "m");
        this.isSubtitlesOn() || En(this, sn(this) || !this.G ? Mo(this, !0) : this.G, !0)
    };
    g.J.isSubtitlesOn = function() {
        return !!this.loaded && !!this.G && !sn(this)
    };
    g.J.x0h = function() {
        var l = sn(this);
        ms(this, l) ? En(this, this.getAudioTrack().D, !1) : this.videoData.captionTracks.length && (this.loaded && this.unload(), this.e$() && (this.U = !1, this.G = null, this.D && (this.D.dispose(), this.D = null)), this.PH() && (l ? En(this, Mo(this, !1), !1) : this.load()))
    };
    g.J.QU = function(l) {
        l && (this.Kh = {
            top: l.top,
            right: l.right,
            bottom: l.bottom,
            left: l.left,
            width: 1 - l.left - l.right,
            height: 1 - l.top - l.bottom
        }, this.C.element.style.top = this.Kh.top * 100 + "%", this.C.element.style.left = this.Kh.left * 100 + "%", this.C.element.style.width = this.Kh.width * 100 + "%", this.C.element.style.height = this.Kh.height * 100 + "%", this.C.element.style.position = "absolute", l = a1L(this)) && (this.C.element.style.width = l.width + "px", this.C.element.style.height = l.height + "px")
    };
    g.J.onVideoDataChange = function(l, c) {
        l === "newdata" && (this.videoData = c, this.loaded && this.unload(), this.U = !1, this.G = null, this.D && (this.D.dispose(), this.D = null, this.player.fV("captionschanged", {})), this.PH() && this.load())
    };
    g.J.getAudioTrack = function() {
        return this.uQ && this.player.getPresentingPlayerType() === 2 ? this.videoData.Fw : this.player.getAudioTrack()
    };
    g.J.RlJ = function() {
        var l = this.V.Vx();
        l && !l.vU() && l.uJ();
        this.V.isFullscreen() ? (this.N = this.nh = !0, this.loaded && this.YA()) : (this.nh = this.fh.controlsType === "3", this.N = d5N(this));
        En(this, this.G)
    };
    g.J.FU = function() {
        var l, c, Y, X = (l = this.videoData.getPlayerResponse()) == null ? void 0 : (c = l.captions) == null ? void 0 : (Y = c.playerCaptionsTracklistRenderer) == null ? void 0 : Y.openTranscriptCommand;
        X && this.player.cU("innertubeCommand", X)
    };
    g.J.zO = function(l, c, Y) {
        var X = /&|,|:|;|(\n)|(\s)|(\/)|(\\)/gm,
            k = "";
        l && (k = l.vssId, k = k.replace(X, ""));
        var r = "";
        l && l.getId() && (r = l.getId() || "");
        l && l.getXtags() && (l = l.getXtags(), l = l.replace(X, ""), r = r.concat(";" + l));
        this.V.zO(c ? k : "", c ? r : "", Y)
    };
    g.J.RD = function(l, c) {
        l = (l || "").replace(/&|,|:|;|(\n)|(\s)|(\/)|(\\)/gm, "");
        l.length > 0 && this.V.RD(l, c)
    };
    g.J.sD = function() {
        this.D && this.D.sD()
    };
    g.Tz.Rk(Q9, {
        XA: "smucd"
    });
    g.U$("captions", Q9);
})(_yt_player);