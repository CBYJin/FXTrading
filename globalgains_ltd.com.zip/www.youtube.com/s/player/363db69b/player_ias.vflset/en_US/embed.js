(function(g) {
    var window = this;
    'use strict';
    var hP7 = function(l) {
            l.mutedAutoplay = !1;
            l.endSeconds = NaN;
            l.limitedPlaybackDurationInSeconds = NaN;
            g.Er(l)
        },
        Hma = function() {
            return {
                J: "svg",
                S: {
                    height: "100%",
                    version: "1.1",
                    viewBox: "0 0 110 26",
                    width: "100%"
                },
                Y: [{
                    J: "path",
                    xF: !0,
                    X: "ytp-svg-fill",
                    S: {
                        d: "M 16.68,.99 C 13.55,1.03 7.02,1.16 4.99,1.68 c -1.49,.4 -2.59,1.6 -2.99,3 -0.69,2.7 -0.68,8.31 -0.68,8.31 0,0 -0.01,5.61 .68,8.31 .39,1.5 1.59,2.6 2.99,3 2.69,.7 13.40,.68 13.40,.68 0,0 10.70,.01 13.40,-0.68 1.5,-0.4 2.59,-1.6 2.99,-3 .69,-2.7 .68,-8.31 .68,-8.31 0,0 .11,-5.61 -0.68,-8.31 -0.4,-1.5 -1.59,-2.6 -2.99,-3 C 29.11,.98 18.40,.99 18.40,.99 c 0,0 -0.67,-0.01 -1.71,0 z m 72.21,.90 0,21.28 2.78,0 .31,-1.37 .09,0 c .3,.5 .71,.88 1.21,1.18 .5,.3 1.08,.40 1.68,.40 1.1,0 1.99,-0.49 2.49,-1.59 .5,-1.1 .81,-2.70 .81,-4.90 l 0,-2.40 c 0,-1.6 -0.11,-2.90 -0.31,-3.90 -0.2,-0.89 -0.5,-1.59 -1,-2.09 -0.5,-0.4 -1.10,-0.59 -1.90,-0.59 -0.59,0 -1.18,.19 -1.68,.49 -0.49,.3 -1.01,.80 -1.21,1.40 l 0,-7.90 -3.28,0 z m -49.99,.78 3.90,13.90 .18,6.71 3.31,0 0,-6.71 3.87,-13.90 -3.37,0 -1.40,6.31 c -0.4,1.89 -0.71,3.19 -0.81,3.99 l -0.09,0 c -0.2,-1.1 -0.51,-2.4 -0.81,-3.99 l -1.37,-6.31 -3.40,0 z m 29.59,0 0,2.71 3.40,0 0,17.90 3.28,0 0,-17.90 3.40,0 c 0,0 .00,-2.71 -0.09,-2.71 l -9.99,0 z m -53.49,5.12 8.90,5.18 -8.90,5.09 0,-10.28 z m 89.40,.09 c -1.7,0 -2.89,.59 -3.59,1.59 -0.69,.99 -0.99,2.60 -0.99,4.90 l 0,2.59 c 0,2.2 .30,3.90 .99,4.90 .7,1.1 1.8,1.59 3.5,1.59 1.4,0 2.38,-0.3 3.18,-1 .7,-0.7 1.09,-1.69 1.09,-3.09 l 0,-0.5 -2.90,-0.21 c 0,1 -0.08,1.6 -0.28,2 -0.1,.4 -0.5,.62 -1,.62 -0.3,0 -0.61,-0.11 -0.81,-0.31 -0.2,-0.3 -0.30,-0.59 -0.40,-1.09 -0.1,-0.5 -0.09,-1.21 -0.09,-2.21 l 0,-0.78 5.71,-0.09 0,-2.62 c 0,-1.6 -0.10,-2.78 -0.40,-3.68 -0.2,-0.89 -0.71,-1.59 -1.31,-1.99 -0.7,-0.4 -1.48,-0.59 -2.68,-0.59 z m -50.49,.09 c -1.09,0 -2.01,.18 -2.71,.68 -0.7,.4 -1.2,1.12 -1.49,2.12 -0.3,1 -0.5,2.27 -0.5,3.87 l 0,2.21 c 0,1.5 .10,2.78 .40,3.78 .2,.9 .70,1.62 1.40,2.12 .69,.5 1.71,.68 2.81,.78 1.19,0 2.08,-0.28 2.78,-0.68 .69,-0.4 1.09,-1.09 1.49,-2.09 .39,-1 .49,-2.30 .49,-3.90 l 0,-2.21 c 0,-1.6 -0.2,-2.87 -0.49,-3.87 -0.3,-0.89 -0.8,-1.62 -1.49,-2.12 -0.7,-0.5 -1.58,-0.68 -2.68,-0.68 z m 12.18,.09 0,11.90 c -0.1,.3 -0.29,.48 -0.59,.68 -0.2,.2 -0.51,.31 -0.81,.31 -0.3,0 -0.58,-0.10 -0.68,-0.40 -0.1,-0.3 -0.18,-0.70 -0.18,-1.40 l 0,-10.99 -3.40,0 0,11.21 c 0,1.4 .18,2.39 .68,3.09 .49,.7 1.21,1 2.21,1 1.4,0 2.48,-0.69 3.18,-2.09 l .09,0 .31,1.78 2.59,0 0,-14.99 c 0,0 -3.40,.00 -3.40,-0.09 z m 17.31,0 0,11.90 c -0.1,.3 -0.29,.48 -0.59,.68 -0.2,.2 -0.51,.31 -0.81,.31 -0.3,0 -0.58,-0.10 -0.68,-0.40 -0.1,-0.3 -0.21,-0.70 -0.21,-1.40 l 0,-10.99 -3.40,0 0,11.21 c 0,1.4 .21,2.39 .71,3.09 .5,.7 1.18,1 2.18,1 1.39,0 2.51,-0.69 3.21,-2.09 l .09,0 .28,1.78 2.62,0 0,-14.99 c 0,0 -3.40,.00 -3.40,-0.09 z m 20.90,2.09 c .4,0 .58,.11 .78,.31 .2,.3 .30,.59 .40,1.09 .1,.5 .09,1.21 .09,2.21 l 0,1.09 -2.5,0 0,-1.09 c 0,-1 -0.00,-1.71 .09,-2.21 0,-0.4 .11,-0.8 .31,-1 .2,-0.3 .51,-0.40 .81,-0.40 z m -50.49,.12 c .5,0 .8,.18 1,.68 .19,.5 .28,1.30 .28,2.40 l 0,4.68 c 0,1.1 -0.08,1.90 -0.28,2.40 -0.2,.5 -0.5,.68 -1,.68 -0.5,0 -0.79,-0.18 -0.99,-0.68 -0.2,-0.5 -0.31,-1.30 -0.31,-2.40 l 0,-4.68 c 0,-1.1 .11,-1.90 .31,-2.40 .2,-0.5 .49,-0.68 .99,-0.68 z m 39.68,.09 c .3,0 .61,.10 .81,.40 .2,.3 .27,.67 .37,1.37 .1,.6 .12,1.51 .12,2.71 l .09,1.90 c 0,1.1 .00,1.99 -0.09,2.59 -0.1,.6 -0.19,1.08 -0.49,1.28 -0.2,.3 -0.50,.40 -0.90,.40 -0.3,0 -0.51,-0.08 -0.81,-0.18 -0.2,-0.1 -0.39,-0.29 -0.59,-0.59 l 0,-8.5 c .1,-0.4 .29,-0.7 .59,-1 .3,-0.3 .60,-0.40 .90,-0.40 z"
                    }
                }]
            }
        },
        waa = function() {
            return {
                J: "svg",
                S: {
                    fill: "none",
                    height: "100%",
                    viewBox: "0 0 143 51",
                    width: "100%"
                },
                Y: [{
                    J: "path",
                    S: {
                        d: "M58.37 41.39H62.79V27.23C62.79 23.03 62.69 18.69 62.43 13.59H62.93L63.69 16.89L68.67 41.39H73.17L78.07 16.89L78.89 13.59H79.37C79.15 18.45 79.03 22.89 79.03 27.23V41.39H83.45V8.79H75.95L73.41 20.81C72.35 25.85 71.51 32.01 71.01 35.19H70.73C70.33 31.95 69.49 25.81 68.41 20.85L65.81 8.79H58.37V41.39Z",
                        fill: "white"
                    }
                }, {
                    J: "path",
                    S: {
                        d: "M91.45 41.73C93.91 41.73 95.83 40.59 97.17 38.13H97.35L97.69 41.39H101.43V17.73H96.47V36.61C95.91 37.67 94.81 38.29 93.73 38.29C92.33 38.29 91.89 37.17 91.89 35.13V17.73H86.93V35.43C86.93 39.49 88.19 41.73 91.45 41.73Z",
                        fill: "white"
                    }
                }, {
                    J: "path",
                    S: {
                        d: "M110.79 41.89C115.15 41.89 117.75 39.83 117.75 35.65C117.75 31.79 115.93 30.39 111.85 27.47C109.67 25.91 108.39 25.09 108.39 22.95C108.39 21.47 109.27 20.61 110.89 20.61C112.69 20.61 113.33 21.81 113.33 25.29L117.45 25.07C117.77 19.57 115.71 17.23 110.97 17.23C106.57 17.23 104.17 19.27 104.17 23.45C104.17 27.25 105.97 28.83 108.93 31.03C111.89 33.23 113.55 34.53 113.55 36.23C113.55 37.75 112.51 38.61 111.01 38.61C109.13 38.61 108.11 36.97 108.29 34.41L104.21 34.49C103.51 39.25 105.89 41.89 110.79 41.89Z",
                        fill: "white"
                    }
                }, {
                    J: "path",
                    S: {
                        d: "M122.5 14.59C124.22 14.59 125.04 13.99 125.04 11.59C125.04 9.33 124.16 8.65 122.5 8.65C120.84 8.65 119.94 9.27 119.94 11.59C119.94 13.99 120.82 14.59 122.5 14.59ZM120.2 41.39H125V17.73H120.2V41.39Z",
                        fill: "white"
                    }
                }, {
                    J: "path",
                    S: {
                        d: "M134.95 41.79C137.31 41.79 138.63 41.49 139.71 40.47C141.31 39.01 141.97 36.63 141.85 33.11L137.41 32.87C137.41 36.87 136.81 38.45 135.03 38.45C133.13 38.45 132.77 36.45 132.77 31.97V27.21C132.77 22.41 133.23 20.51 135.07 20.51C136.67 20.51 137.29 22.01 137.29 26.47L141.65 26.15C141.97 22.93 141.59 20.29 140.09 18.83C139.01 17.77 137.37 17.29 135.15 17.29C129.65 17.29 127.75 20.73 127.75 28.03V31.17C127.75 38.47 129.23 41.79 134.95 41.79Z",
                        fill: "white"
                    }
                }, {
                    J: "path",
                    S: {
                        "clip-rule": "evenodd",
                        d: "M24.99 49C29.74 49.00 34.38 47.59 38.32 44.95C42.27 42.32 45.35 38.57 47.17 34.18C48.98 29.80 49.46 24.97 48.53 20.32C47.61 15.66 45.32 11.38 41.97 8.03C38.61 4.67 34.33 2.38 29.68 1.46C25.02 .53 20.20 1.01 15.81 2.82C11.43 4.64 7.68 7.71 5.04 11.66C2.40 15.61 1 20.25 1 25C0.99 28.15 1.61 31.27 2.82 34.18C4.03 37.09 5.79 39.74 8.02 41.97C10.25 44.19 12.89 45.96 15.81 47.17C18.72 48.37 21.84 49 24.99 49ZM24.99 12.36C27.49 12.36 29.94 13.10 32.02 14.48C34.10 15.87 35.72 17.84 36.68 20.15C37.64 22.46 37.89 25.01 37.41 27.46C36.92 29.91 35.72 32.17 33.95 33.94C32.18 35.70 29.93 36.91 27.48 37.40C25.02 37.89 22.48 37.64 20.17 36.68C17.86 35.72 15.88 34.10 14.50 32.02C13.11 29.94 12.37 27.50 12.37 25C12.37 21.65 13.70 18.44 16.07 16.07C18.43 13.70 21.64 12.37 24.99 12.36ZM24.99 10.43C22.11 10.43 19.29 11.28 16.89 12.88C14.50 14.48 12.63 16.76 11.53 19.42C10.42 22.09 10.13 25.02 10.70 27.85C11.26 30.67 12.65 33.27 14.69 35.31C16.73 37.35 19.32 38.73 22.15 39.30C24.98 39.86 27.91 39.57 30.57 38.46C33.23 37.36 35.51 35.49 37.11 33.09C38.71 30.70 39.57 27.88 39.56 25C39.56 23.08 39.19 21.19 38.46 19.42C37.72 17.65 36.65 16.04 35.30 14.69C33.94 13.34 32.34 12.27 30.57 11.53C28.80 10.80 26.90 10.43 24.99 10.43ZM32.63 24.99L20.36 32.09V17.91L32.63 24.99Z",
                        fill: "white",
                        "fill-rule": "evenodd"
                    }
                }]
            }
        },
        Kre = function(l) {
            g.B.call(this, {
                J: "div",
                X: "ytp-related-on-error-overlay"
            });
            var c = this;
            this.api = l;
            this.W = this.G = 0;
            this.T = new g.Cr(this);
            this.D = [];
            this.suggestionData = [];
            this.columns = this.containerWidth = 0;
            this.title = new g.B({
                J: "h2",
                X: "ytp-related-title",
                Qf: "{{title}}"
            });
            this.previous = new g.B({
                J: "button",
                WU: ["ytp-button", "ytp-previous"],
                S: {
                    "aria-label": "Show previous suggested videos"
                },
                Y: [g.ps()]
            });
            this.j = new g.E8(function(r) {
                c.suggestions.element.scrollLeft = -r
            });
            this.K = this.scrollPosition = 0;
            this.C = !0;
            this.next = new g.B({
                J: "button",
                WU: ["ytp-button", "ytp-next"],
                S: {
                    "aria-label": "Show more suggested videos"
                },
                Y: [g.Rw()]
            });
            g.Z(this, this.T);
            l = l.L();
            this.api.B("embeds_web_enable_pause_overlay_rounding") && g.Jj(this.element, "ytp-error-overlay-round-corners");
            this.U = l.T;
            g.Z(this, this.title);
            this.title.Vf(this.element);
            this.suggestions = new g.B({
                J: "div",
                X: "ytp-suggestions"
            });
            g.Z(this, this.suggestions);
            this.suggestions.Vf(this.element);
            g.Z(this, this.previous);
            this.previous.Vf(this.element);
            this.previous.listen("click", this.jE, this);
            g.Z(this, this.j);
            for (var Y = {
                    Y0: 0
                }; Y.Y0 < 16; Y = {
                    Y0: Y.Y0
                }, Y.Y0++) {
                var X = new g.B({
                    J: "a",
                    X: "ytp-suggestion-link",
                    S: {
                        href: "{{link}}",
                        target: l.j,
                        "aria-label": "{{aria_label}}"
                    },
                    Y: [{
                        J: "div",
                        X: "ytp-suggestion-image",
                        Y: [{
                            J: "div",
                            S: {
                                "data-is-live": "{{is_live}}"
                            },
                            X: "ytp-suggestion-duration",
                            Qf: "{{duration}}"
                        }]
                    }, {
                        J: "div",
                        X: "ytp-suggestion-title",
                        S: {
                            title: "{{hover_title}}"
                        },
                        Qf: "{{title}}"
                    }, {
                        J: "div",
                        X: "ytp-suggestion-author",
                        Qf: "{{views_or_author}}"
                    }]
                });
                g.Z(this, X);
                X.Vf(this.suggestions.element);
                var k = X.wf("ytp-suggestion-link");
                g.dg(k, "transitionDelay", Y.Y0 / 20 + "s");
                this.T.Z(k, "click", function(r) {
                    return function(e) {
                        var d = r.Y0,
                            y = c.suggestionData[d],
                            O = y.sessionData;
                        g.h2(c.api.L()) && c.api.B("web_player_log_click_before_generating_ve_conversion_params") ? (c.api.logClick(c.D[d].element), d = y.If(), y = {}, g.T$(c.api, y), d = g.Il(d, y), g.yF(d, c.api, e)) : g.d2(e, c.api, c.U, O || void 0) && c.api.vn(y.videoId, O, y.playlistId)
                    }
                }(Y));
                this.D.push(X)
            }
            g.Z(this, this.next);
            this.next.Vf(this.element);
            this.next.listen("click", this.SE, this);
            this.T.Z(this.api, "videodatachange", this.onVideoDataChange);
            this.resize(this.api.m0().getPlayerSize());
            this.onVideoDataChange();
            this.show()
        },
        T3c = function(l, c) {
            if (l.api.L().B("web_player_log_click_before_generating_ve_conversion_params"))
                for (var Y = Math.floor(-l.scrollPosition / (l.K + l.G)), X = Math.min(Y + l.columns, l.suggestionData.length) - 1; Y <= X; Y++) l.api.logVisibility(l.D[Y].element, c)
        },
        jlF = function(l) {
            l.next.element.style.bottom =
                l.W + "px";
            l.previous.element.style.bottom = l.W + "px";
            var c = l.scrollPosition,
                Y = l.containerWidth - l.suggestionData.length * (l.K + l.G);
            g.DK(l.element, "ytp-scroll-min", c >= 0);
            g.DK(l.element, "ytp-scroll-max", c <= Y)
        },
        Vue = function(l) {
            for (var c = 0; c < l.suggestionData.length; c++) {
                var Y = l.suggestionData[c],
                    X = l.D[c],
                    k = Y.shortViewCount ? Y.shortViewCount : Y.author,
                    r = Y.If(),
                    e = l.api.L();
                if (g.h2(e) && !e.B("web_player_log_click_before_generating_ve_conversion_params")) {
                    var d = {};
                    g.Uz(l.api, "addEmbedsConversionTrackingParams", [d]);
                    r = g.Il(r, d)
                }
                X.element.style.display = "";
                d = X.wf("ytp-suggestion-title");
                g.PT.test(Y.title) ? d.dir = "rtl" : g.E6E.test(Y.title) && (d.dir = "ltr");
                d = X.wf("ytp-suggestion-author");
                g.PT.test(k) ? d.dir = "rtl" : g.E6E.test(k) && (d.dir = "ltr");
                X.update({
                    views_or_author: k,
                    duration: Y.isLivePlayback ? "Live" : Y.lengthSeconds ? g.vE(Y.lengthSeconds) : "",
                    link: r,
                    hover_title: Y.title,
                    title: Y.title,
                    aria_label: Y.ariaLabel || null,
                    is_live: Y.isLivePlayback
                });
                k = Y.Bp();
                X.wf("ytp-suggestion-image").style.backgroundImage = k ? "url(" + k + ")" : "";
                e.B("web_player_log_click_before_generating_ve_conversion_params") && (l.api.createServerVe(X.element, X), (Y = (Y = Y.sessionData) && Y.itct) && l.api.setTrackingParams(X.element, Y))
            }
            for (; c < l.D.length; c++) l.D[c].element.style.display = "none";
            jlF(l)
        },
        u$ = function(l) {
            g.j6.call(this, l);
            var c = this;
            this.D = null;
            var Y = l.L(),
                X = {
                    target: Y.j
                },
                k = ["ytp-small-redirect"];
            Y.K ? k.push("no-link") : (Y = g.kr(Y), X.href = Y, X["aria-label"] = "Visit YouTube to search for more videos");
            var r = new g.B({
                J: "a",
                WU: k,
                S: X,
                Y: [{
                    J: "svg",
                    S: {
                        fill: "#fff",
                        height: "100%",
                        viewBox: "0 0 24 24",
                        width: "100%"
                    },
                    Y: [{
                        J: "path",
                        S: {
                            d: "M0 0h24v24H0V0z",
                            fill: "none"
                        }
                    }, {
                        J: "path",
                        S: {
                            d: "M21.58 7.19c-.23-.86-.91-1.54-1.77-1.77C18.25 5 12 5 12 5s-6.25 0-7.81.42c-.86.23-1.54.91-1.77 1.77C2 8.75 2 12 2 12s0 3.25.42 4.81c.23.86.91 1.54 1.77 1.77C5.75 19 12 19 12 19s6.25 0 7.81-.42c.86-.23 1.54-.91 1.77-1.77C22 15.25 22 12 22 12s0-3.25-.42-4.81zM10 15V9l5.2 3-5.2 3z"
                        }
                    }]
                }]
            });
            r.Vf(this.element);
            l.createClientVe(r.element, this, 178053);
            this.Z(r.element, "click", function(e) {
                oP7(c, e, r.element)
            });
            g.Z(this, r);
            l.L().K || (this.D = new Kre(l), this.D.Vf(this.element), g.Z(this, this.D));
            this.Z(l, "videodatachange", function() {
                c.show()
            });
            this.resize(this.api.m0().getPlayerSize())
        },
        oP7 = function(l, c, Y) {
            c.preventDefault();
            l.api.logClick(Y);
            c = Y.getAttribute("href");
            Y = {};
            g.Uz(l.api, "addEmbedsConversionTrackingParams", [Y]);
            c = g.VS(Y) ? c : g.Il(c, Y);
            g.sY(window, c)
        },
        C_i = function(l, c) {
            l.wf("ytp-error-content").style.paddingTop = "0px";
            var Y = l.wf("ytp-error-content"),
                X = Y.clientHeight;
            l.D && l.D.resize(c, c.height - X);
            Y.style.paddingTop = (c.height - (l.D ? l.D.element.clientHeight : 0)) / 2 - X / 2 + "px"
        },
        QlN = function(l, c) {
            var Y = l.api.L(),
                X;
            c.reason && (Zmc(c.reason) ? X = g.aw(c.reason) : X = g.Vy(g.qf(c.reason)), l.jb(X, "content"));
            var k;
            c.subreason && (Zmc(c.subreason) ? k = g.aw(c.subreason) : k = g.Vy(g.qf(c.subreason)), l.jb(k, "subreason"));
            if (c.proceedButton && c.proceedButton.buttonRenderer) {
                X = l.wf("ytp-error-content-wrap-subreason");
                c = c.proceedButton.buttonRenderer;
                var r = g.eR("A");
                if (c.text && c.text.simpleText && (k = c.text.simpleText, r.textContent = k, !$5M(X, k) && (!Y.K || Y.embedsErrorLinks))) {
                    var e;
                    Y = (e = g.m(c == null ? void 0 : c.navigationEndpoint, g.ZF)) == null ?
                        void 0 : e.url;
                    var d;
                    e = (d = g.m(c == null ? void 0 : c.navigationEndpoint, g.ZF)) == null ? void 0 : d.target;
                    Y && (r.setAttribute("href", Y), l.api.createClientVe(r, l, 178424), l.Z(r, "click", function(y) {
                        oP7(l, y, r)
                    }));
                    e && r.setAttribute("target", e);
                    d = g.eR("DIV");
                    d.appendChild(r);
                    X.appendChild(d)
                }
            }
        },
        Zmc = function(l) {
            if (l.runs)
                for (var c = 0; c < l.runs.length; c++)
                    if (l.runs[c].navigationEndpoint) return !0;
            return !1
        },
        $5M = function(l, c) {
            l = g.Ad("A", l);
            for (var Y = 0; Y < l.length; Y++)
                if (l[Y].textContent === c) return !0;
            return !1
        },
        m57 = function(l, c) {
            g.B.call(this, {
                J: "a",
                WU: ["ytp-impression-link"],
                S: {
                    target: "{{target}}",
                    href: "{{url}}",
                    "aria-label": "Watch on YouTube"
                },
                Y: [{
                    J: "div",
                    X: "ytp-impression-link-content",
                    S: {
                        "aria-hidden": "true"
                    },
                    Y: [{
                        J: "div",
                        X: "ytp-impression-link-text",
                        Qf: "Watch on"
                    }, {
                        J: "div",
                        X: "ytp-impression-link-logo",
                        Qf: "{{logoSvg}}"
                    }]
                }]
            });
            this.api = l;
            this.D = c;
            this.updateValue("target", l.L().j);
            this.Z(l, "videodatachange", this.onVideoDataChange);
            this.Z(this.api, "presentingplayerstatechange", this.WW);
            this.Z(this.api, "videoplayerreset", this.Sr);
            this.Z(this.element,
                "click", this.onClick);
            this.onVideoDataChange();
            this.Sr()
        },
        Wrc = function(l) {
            var c = {};
            g.Uz(l.api, "addEmbedsConversionTrackingParams", [c]);
            l = l.api.getVideoUrl();
            return l = g.Il(l, c)
        },
        AB = function(l) {
            g.B.call(this, {
                J: "div",
                WU: ["ytp-mobile-a11y-hidden-seek-button"],
                Y: [{
                    J: "button",
                    WU: ["ytp-mobile-a11y-hidden-seek-button-rewind", "ytp-button"],
                    S: {
                        "aria-label": "Rewind 10 seconds",
                        "aria-hidden": "false"
                    }
                }, {
                    J: "button",
                    WU: ["ytp-mobile-a11y-hidden-seek-button-forward", "ytp-button"],
                    S: {
                        "aria-label": "Fast forward 10 seconds",
                        "aria-hidden": "false"
                    }
                }]
            });
            this.api = l;
            this.D = this.wf("ytp-mobile-a11y-hidden-seek-button-rewind");
            this.forwardButton = this.wf("ytp-mobile-a11y-hidden-seek-button-forward");
            this.api.createClientVe(this.D, this,
                141902);
            this.api.createClientVe(this.forwardButton, this, 141903);
            this.Z(this.api, "presentingplayerstatechange", this.WW);
            this.Z(this.D, "click", this.G);
            this.Z(this.forwardButton, "click", this.K);
            this.WW()
        },
        Ft = function(l) {
            g.B.call(this, {
                J: "div",
                X: "ytp-muted-autoplay-endscreen-overlay",
                Y: [{
                    J: "div",
                    X: "ytp-muted-autoplay-end-panel",
                    Y: [{
                        J: "button",
                        WU: ["ytp-muted-autoplay-end-text", "ytp-button"],
                        Qf: "{{text}}"
                    }]
                }]
            });
            this.api = l;
            this.T = this.wf("ytp-muted-autoplay-end-panel");
            this.G = !1;
            this.api.createClientVe(this.element, this, 52428);
            this.Z(this.api, "presentingplayerstatechange", this.K);
            this.Z(l, "onMutedAutoplayStarts", this.onMutedAutoplayStarts);
            this.listen("click", this.onClick);
            this.hide()
        },
        Iu = function(l) {
            var c = l.L();
            g.B.call(this, {
                J: "a",
                WU: ["ytp-watermark", "yt-uix-sessionlink"],
                S: {
                    target: c.j,
                    href: "{{url}}",
                    "aria-label": g.qi("Watch on $WEBSITE", {
                        WEBSITE: g.BN(c)
                    }),
                    "data-sessionlink": "feature=player-watermark"
                },
                Qf: "{{logoSvg}}"
            });
            this.api = l;
            this.D = null;
            this.G = !1;
            this.state = l.getPlayerStateObject();
            this.Z(l, "videodatachange", this.onVideoDataChange);
            this.Z(l, "presentingplayerstatechange", this.onStateChange);
            this.Z(l, "appresize", this.i9);
            this.onVideoDataChange();
            this.cA(this.state);
            this.i9(l.m0().getPlayerSize())
        },
        MuU = function(l) {
            var c = l.api.getVideoData(),
                Y = l.api.L();
            Y = Y.oe && !g.L(l.state, 2) && !g.Xo(l.api.getVideoData(1)) && !(Y.B("embeds_enable_emc3ds_woyt_counterfactual") && l.api.getPlayerStateObject().isCued());
            c.mutedAutoplay || l.QB(Y);
            l.api.logVisibility(l.element, Y)
        },
        Lri = function(l) {
            g.B.call(this, {
                J: "div",
                X: "ytp-muted-autoplay-overlay",
                Y: [{
                    J: "div",
                    X: "ytp-muted-autoplay-bottom-buttons",
                    Y: [{
                        J: "button",
                        WU: ["ytp-muted-autoplay-equalizer", "ytp-button"],
                        S: {
                            "aria-label": "Muted Playback Indicator"
                        },
                        Y: [{
                            J: "div",
                            WU: ["ytp-muted-autoplay-equalizer-icon"],
                            Y: [{
                                J: "svg",
                                S: {
                                    height: "100%",
                                    version: "1.1",
                                    viewBox: "-4 -4 24 24",
                                    width: "100%"
                                },
                                Y: [{
                                    J: "g",
                                    S: {
                                        fill: "#fff"
                                    },
                                    Y: [{
                                            J: "rect",
                                            X: "ytp-equalizer-bar-left",
                                            S: {
                                                height: "9",
                                                width: "4",
                                                x: "1",
                                                y: "7"
                                            }
                                        }, {
                                            J: "rect",
                                            X: "ytp-equalizer-bar-middle",
                                            S: {
                                                height: "14",
                                                width: "4",
                                                x: "6",
                                                y: "2"
                                            }
                                        },
                                        {
                                            J: "rect",
                                            X: "ytp-equalizer-bar-right",
                                            S: {
                                                height: "12",
                                                width: "4",
                                                x: "11",
                                                y: "4"
                                            }
                                        }
                                    ]
                                }]
                            }]
                        }]
                    }]
                }]
            });
            var c = this;
            this.api = l;
            this.bottomButtons = this.wf("ytp-muted-autoplay-bottom-buttons");
            this.K = new g.gY(this.oTf, 4E3, this);
            this.G = !1;
            l.createClientVe(this.element, this, 39306);
            this.Z(l, "presentingplayerstatechange", this.d5);
            this.Z(l, "onMutedAutoplayStarts", function() {
                sl6(c);
                c.d5();
                B3Q(c);
                c.G = !1
            });
            this.Z(l, "onAutoplayBlocked", this.onAutoplayBlocked);
            this.listen("click", this.onClick);
            this.Z(l, "onMutedAutoplayEnds", this.onMutedAutoplayEnds);
            this.hide();
            l.isMutedByEmbedsMutedAutoplay() && (sl6(this), this.d5(), B3Q(this));
            g.Z(this, this.K)
        },
        B3Q = function(l) {
            l.Ag && l.D && (l.D.show(), l.K.start())
        },
        sl6 = function(l) {
            l.watermark || (l.watermark = new Iu(l.api), g.Z(l, l.watermark), l.watermark.Vf(l.bottomButtons, 0), g.DK(l.watermark.element, "ytp-muted-autoplay-watermark", !0), l.D = new g.Xz(l.watermark, 0, !0, 100), g.Z(l,
                l.D))
        },
        lK = function(l) {
            g.B.call(this, {
                J: "div",
                X: "ytp-pause-overlay",
                S: {
                    tabIndex: "-1"
                }
            });
            var c = this;
            this.api = l;
            this.K = new g.Cr(this);
            this.fade = new g.Xz(this, 1E3, !1, 100, function() {
                c.D.G = !1
            }, function() {
                c.D.G = !0
            });
            this.G = !1;
            this.expandButton = new g.B({
                J: "button",
                WU: ["ytp-button", "ytp-expand"],
                Qf: this.api.isEmbedsShortsMode() ? "More shorts" : "More videos"
            });
            l.L().controlsType === "0" && g.Jj(l.getRootNode(), "ytp-pause-overlay-controls-hidden");
            this.api.B("embeds_web_enable_pause_overlay_rounding") && g.Jj(this.element, "ytp-pause-overlay-round-corners");
            g.Z(this, this.K);
            g.Z(this, this.fade);
            var Y = new g.B({
                J: "button",
                WU: ["ytp-button", "ytp-collapse"],
                S: {
                    "aria-label": this.api.isEmbedsShortsMode() ? "Hide more shorts" : "Hide more videos"
                },
                Y: [{
                    J: "div",
                    X: "ytp-collapse-icon",
                    Y: [g.wl()]
                }]
            });
            g.Z(this, Y);
            Y.Vf(this.element);
            Y.listen("click", this.T, this);
            g.Z(this, this.expandButton);
            this.expandButton.Vf(this.element);
            this.expandButton.listen("click", this.W, this);
            this.D = new g.gU(l);
            g.Z(this, this.D);
            this.D.G = !1;
            this.D.Vf(this.element);
            this.api.isEmbedsShortsMode() ? this.api.createClientVe(this.element, this, 157212) : this.api.createClientVe(this.element, this, 172777);
            this.K.Z(this.api, "presentingplayerstatechange", this.df);
            this.K.Z(this.api, "videodatachange",
                this.df);
            this.hide()
        },
        c$ = function(l) {
            g.B.call(this, {
                J: "div",
                WU: ["ytp-player-content", "ytp-iv-player-content"],
                Y: [{
                    J: "div",
                    X: "ytp-countdown-timer",
                    Y: [{
                        J: "svg",
                        S: {
                            height: "100%",
                            version: "1.1",
                            viewBox: "0 0 72 72",
                            width: "100%"
                        },
                        Y: [{
                            J: "circle",
                            X: "ytp-svg-countdown-timer-ring",
                            S: {
                                cx: "-36",
                                cy: "36",
                                "fill-opacity": "0",
                                r: "33.5",
                                stroke: "#FFFFFF",
                                "stroke-dasharray": "211",
                                "stroke-dashoffset": "-211",
                                "stroke-width": "4",
                                transform: "rotate(-90)"
                            }
                        }, {
                            J: "circle",
                            X: "ytp-svg-countdown-timer-background",
                            S: {
                                cx: "-36",
                                cy: "36",
                                "fill-opacity": "0",
                                r: "33.5",
                                stroke: "#FFFFFF",
                                "stroke-opacity": "0.3",
                                "stroke-width": "4",
                                transform: "rotate(-90)"
                            }
                        }]
                    }, {
                        J: "span",
                        X: "ytp-countdown-timer-time",
                        Qf: "{{duration}}"
                    }]
                }]
            });
            this.api = l;
            this.C = this.wf("ytp-svg-countdown-timer-ring");
            this.D = null;
            this.T = this.K = 0;
            this.G = !1;
            this.W = 0;
            this.api.createClientVe(this.element, this, 159628)
        },
        gPQ = function(l) {
            l.D || (l.K = 5E3, l.T = (0, g.nb)(), l.D = new g.Ee(function() {
                EPU(l)
            }, null), EPU(l))
        },
        EPU = function(l) {
            if (!l.G) {
                var c = Math.min((0, g.nb)() - l.T, l.K);
                var Y = l.K - c;
                c = l.K === 0 ? 0 : Math.max(Y / l.K, 0);
                Y = Math.round(Y / 1E3);
                l.C.setAttribute("stroke-dashoffset", "" + -211 * (c + 1));
                l.updateValue("duration", Y);
                c <= 0 && l.D ? Yd(l) : l.D && l.D.start()
            }
        },
        Yd = function(l) {
            l.D && (l.D.dispose(), l.D = null, l.G = !1)
        },
        A8L = function(l) {
            g.GH.call(this, l);
            this.V = l;
            this.D = new g.Cr(this);
            this.G = null;
            this.C = !1;
            this.countdownTimer = null;
            this.j = !1;
            uPM(this);
            g.Z(this, this.D);
            this.load()
        },
        I1E = function(l) {
            var c = g.ygN(l.V);
            c !== l.j && (l.j = c, l.N && (l.N.dispose(), l.N = null), l.K && (l.K.dispose(), l.K = null), l.T && (l.T.dispose(), l.T = null), l.G && (l.G.stop(), l.G.dispose(), l.G = null), c && (c = g.qu(l.V), l.V.isEmbedsShortsMode() && (l.T = new g.B({
                J: "div",
                X: "ytp-pause-overlay-backdrop",
                S: {
                    tabIndex: "-1"
                }
            }), g.Z(l, l.T), g.oD(l.V, l.T.element, 4), l.G = new g.Xz(l.T, 1E3, !1, 100), g.Z(l, l.G), l.T.hide()), l.N = new g.B({
                J: "div",
                X: "ytp-pause-overlay-container",
                S: {
                    tabIndex: "-1"
                }
            }), g.Z(l, l.N), l.K = new lK(l.V, c), g.Z(l, l.K), l.K.Vf(l.N.element), g.oD(l.V, l.N.element,
                4), FrQ(l, l.V.getPlayerStateObject())))
        },
        FrQ = function(l, c) {
            l.G && (!g.L(c, 4) && !g.L(c, 2) || g.L(c, 1024) ? l.G.hide() : l.G.show())
        },
        uPM = function(l) {
            var c = l.V;
            l = !!c.isEmbedsShortsMode();
            g.DK(c.getRootNode(), "ytp-shorts-mode", l);
            if (c = c.getVideoData()) c.xn = l
        },
        XV = function(l, c) {
            var Y = l.V.L();
            l = {
                adSource: "EMBEDS_AD_SOURCE_YOUTUBE",
                breakType: l.V.getCurrentTime() === 0 ? "EMBEDS_AD_BREAK_TYPE_PRE_ROLL" : l.V.getPlayerState() === 0 ? "EMBEDS_AD_BREAK_TYPE_POST_ROLL" : "EMBEDS_AD_BREAK_TYPE_MID_ROLL",
                embedUrl: g.PCv(l.V.L().loaderUrl),
                eventType: c,
                youtubeHost: g.Lm(l.V.L().VA) || ""
            };
            l.embeddedPlayerMode = Y.JJ;
            g.Oq("embedsAdEvent", l)
        };
    g.P(Kre, g.B);
    g.J = Kre.prototype;
    g.J.hide = function() {
        this.C = !0;
        g.B.prototype.hide.call(this);
        T3c(this, !1)
    };
    g.J.show = function() {
        this.C = !1;
        g.B.prototype.show.call(this);
        T3c(this, !0)
    };
    g.J.isHidden = function() {
        return this.C
    };
    g.J.SE = function() {
        this.scrollTo(this.scrollPosition - this.containerWidth)
    };
    g.J.jE = function() {
        this.scrollTo(this.scrollPosition + this.containerWidth)
    };
    g.J.resize = function(l, c) {
        var Y = this.api.L(),
            X = 16 / 9,
            k = l.width >= 650,
            r = l.width < 480 || l.height < 290,
            e = Math.min(this.suggestionData.length, this.D.length);
        if (Math.min(l.width, l.height) <= 150 || e === 0 || !Y.U$) this.hide();
        else {
            var d;
            if (k) {
                var y = d = 28;
                this.G = 16
            } else this.G = y = d = 8;
            if (r) {
                var O = 6;
                k = 14;
                var D = 12;
                r = 24;
                Y = 12
            } else O = 8, k = 18, D = 16, r = 36, Y = 16;
            l = l.width - (48 + d + y);
            d = Math.ceil(l / 150);
            d = Math.min(3, d);
            y = l / d - this.G;
            var t = Math.floor(y / X);
            c && t + 100 > c && y > 50 && (t = Math.max(c, 50 / X), d = Math.ceil(l / (X * (t - 100) + this.G)), y = l / d - this.G,
                t = Math.floor(y / X));
            y < 50 || g.KX(this.api) ? this.hide() : this.show();
            for (c = 0; c < e; c++) {
                X = this.D[c];
                var U = X.wf("ytp-suggestion-image");
                U.style.width = y + "px";
                U.style.height = t + "px";
                X.wf("ytp-suggestion-title").style.width = y + "px";
                X.wf("ytp-suggestion-author").style.width = y + "px";
                X = X.wf("ytp-suggestion-duration");
                X.style.display = X && y < 100 ? "none" : ""
            }
            e = k + O + D + 4;
            this.W = e + Y + (t - r) / 2;
            this.suggestions.element.style.height = t + e + "px";
            this.K = y;
            this.containerWidth = l;
            this.columns = d;
            this.scrollPosition = 0;
            this.suggestions.element.scrollLeft = -0;
            jlF(this)
        }
    };
    g.J.onVideoDataChange = function() {
        var l = this.api.getVideoData(),
            c = this.api.L();
        this.U = l.UG ? !1 : c.T;
        l.suggestions ? this.suggestionData = g.yo(l.suggestions, function(Y) {
            return Y && !Y.playlistId
        }) : this.suggestionData.length = 0;
        Vue(this);
        l.UG ? this.title.update({
            title: g.qi("More videos from $DNI_RELATED_CHANNEL", {
                DNI_RELATED_CHANNEL: l.author
            })
        }) : this.title.update({
            title: "More videos on YouTube"
        })
    };
    g.J.scrollTo = function(l) {
        l = g.b0(l, this.containerWidth - this.suggestionData.length * (this.K + this.G), 0);
        this.j.start(this.scrollPosition, l, 1E3);
        this.scrollPosition = l;
        jlF(this);
        T3c(this, !0)
    };
    g.P(u$, g.j6);
    u$.prototype.show = function() {
        g.j6.prototype.show.call(this);
        C_i(this, this.api.m0().getPlayerSize())
    };
    u$.prototype.resize = function(l) {
        g.j6.prototype.resize.call(this, l);
        this.D && (C_i(this, l), g.DK(this.element, "related-on-error-overlay-visible", !this.D.isHidden()))
    };
    u$.prototype.G = function(l) {
        g.j6.prototype.G.call(this, l);
        var c = this.api.getVideoData();
        if (c.ZX || c.playerErrorMessageRenderer)(l = c.ZX) ? QlN(this, l) : c.playerErrorMessageRenderer && QlN(this, c.playerErrorMessageRenderer);
        else {
            var Y;
            l.uH && (c.nZ ? Zmc(c.nZ) ? Y = g.aw(c.nZ) : Y = g.Vy(g.qf(c.nZ)) : Y = g.Vy(l.uH), this.jb(Y, "subreason"))
        }
    };
    g.P(m57, g.B);
    g.J = m57.prototype;
    g.J.onVideoDataChange = function() {
        var l = this.api.getVideoData(),
            c = Hma(),
            Y = 96714;
        g.rP(l) ? (c = waa(), Y = 216165, g.Jj(this.element, "ytp-music-impression-link")) : g.yu(this.element, "ytp-music-impression-link");
        this.api.L().B("embeds_enable_emc3ds_woyt_counterfactual") && g.Jj(this.element, "ytp-woyt-emc3ds-cf");
        this.updateValue("logoSvg", c);
        this.api.hasVe(this.element) && this.api.destroyVe(this.element);
        this.api.createClientVe(this.element, this, Y)
    };
    g.J.WW = function() {
        this.api.getPlayerStateObject().isCued() || (this.hide(), this.api.logVisibility(this.element, !1))
    };
    g.J.Sr = function() {
        var l = this.api.getVideoData(),
            c = this.api.L(),
            Y = this.api.getVideoData().UG,
            X = c.oe && !c.B("embeds_enable_emc3ds_woyt_counterfactual"),
            k = !c.U$,
            r = this.D.QA() && !c.B("embeds_enable_emc3ds_woyt_counterfactual");
        c = c.K;
        X || r || Y || k || c || this.api.isEmbedsShortsMode() || !l.videoId ? (this.hide(), this.api.logVisibility(this.element, !1)) : (l = Wrc(this), this.updateValue("url", l), this.show())
    };
    g.J.onClick = function(l) {
        this.api.B("web_player_log_click_before_generating_ve_conversion_params") && this.api.logClick(this.element);
        var c = Wrc(this);
        g.yF(c, this.api, l);
        this.api.B("web_player_log_click_before_generating_ve_conversion_params") || this.api.logClick(this.element)
    };
    g.J.show = function() {
        this.api.getPlayerStateObject().isCued() && (g.B.prototype.show.call(this), this.api.hasVe(this.element) && this.api.logVisibility(this.element, !0))
    };
    g.P(AB, g.B);
    AB.prototype.WW = function() {
        var l = this.api.getPlayerStateObject();
        !this.api.yA() || g.L(l, 2) && g.h7(this.api) || g.L(l, 64) ? (this.api.logVisibility(this.D, !1), this.api.logVisibility(this.forwardButton, !1), this.hide()) : (this.show(), this.api.logVisibility(this.D, !0), this.api.logVisibility(this.forwardButton, !0))
    };
    AB.prototype.G = function() {
        this.api.seekBy(-10 * this.api.getPlaybackRate(), void 0, void 0, 83);
        this.api.logClick(this.D)
    };
    AB.prototype.K = function() {
        this.api.seekBy(10 * this.api.getPlaybackRate(), void 0, void 0, 82);
        this.api.logClick(this.forwardButton)
    };
    g.P(Ft, g.B);
    Ft.prototype.K = function() {
        var l = this.api.getPlayerStateObject(),
            c = this.api.getVideoData();
        this.api.L().B("embeds_enable_muted_autoplay_shorts_endscreen_fix") && g.DK(this.element, "ytp-shorts-mode", this.api.isEmbedsShortsMode());
        !c.mutedAutoplay || c.limitedPlaybackDurationInSeconds === 0 && c.endSeconds === 0 && c.mutedAutoplayDurationMode === 2 || (g.L(l, 2) && !this.Ag ? (this.show(), this.D || (this.D = new g.KZ(this.api), g.Z(this, this.D), this.D.Vf(this.T, 0), this.D.show()), l = this.api.getVideoData(), this.updateValue("text", l.hn),
            g.DK(this.element, "ytp-muted-autoplay-show-end-panel", !0), this.api.logVisibility(this.element, this.Ag), this.api.fV("onMutedAutoplayEnds")) : this.hide())
    };
    Ft.prototype.onClick = function() {
        if (!this.G) {
            this.D && (this.D.Tz(), this.D = null);
            g.DK(this.api.getRootNode(), "ytp-muted-autoplay", !1);
            var l = this.api.getVideoData(),
                c = this.api.getCurrentTime();
            hP7(l);
            this.api.loadVideoById(l.videoId, c);
            this.api.N2();
            this.api.logClick(this.element);
            this.hide();
            this.G = !0
        }
    };
    Ft.prototype.onMutedAutoplayStarts = function() {
        this.G = !1;
        this.D && (this.D.Tz(), this.D = null)
    };
    g.P(Iu, g.B);
    g.J = Iu.prototype;
    g.J.onStateChange = function(l) {
        this.cA(l.state)
    };
    g.J.cA = function(l) {
        this.state !== l && (this.state = l);
        MuU(this)
    };
    g.J.onVideoDataChange = function() {
        var l = this.api.L();
        l.K && g.Jj(this.element, "ytp-no-hover");
        var c = this.api.getVideoData();
        c.videoId && !l.K ? (l = this.api.getVideoUrl(!0, !1, !1, !0), this.updateValue("url", l), this.D || (this.D = this.listen("click", this.onClick))) : this.D && (this.updateValue("url", null), this.BA(this.D), this.D = null);
        l = Hma();
        var Y = 76758;
        g.rP(c) && (l = waa(), Y = 216164);
        this.updateValue("logoSvg", l);
        this.api.hasVe(this.element) && this.api.destroyVe(this.element);
        this.api.createClientVe(this.element, this,
            Y);
        MuU(this)
    };
    g.J.onClick = function(l) {
        this.api.B("web_player_log_click_before_generating_ve_conversion_params") && this.api.logClick(this.element);
        var c = this.api.getVideoUrl(!g.x1(l), !1, !0, !0);
        if (this.api.B("web_player_log_click_before_generating_ve_conversion_params")) {
            var Y = {};
            g.Uz(this.api, "addEmbedsConversionTrackingParams", [Y]);
            c = g.Il(c, Y)
        }
        g.yF(c, this.api, l);
        this.api.B("web_player_log_click_before_generating_ve_conversion_params") || this.api.logClick(this.element)
    };
    g.J.i9 = function(l) {
        if ((l = l.width < 480) && !this.G || !l && this.G) {
            var c = new g.B(Hma()),
                Y = this.wf("ytp-watermark");
            g.DK(Y, "ytp-watermark-small", l);
            g.yD(Y);
            c.Vf(Y);
            this.G = l
        }
    };
    g.P(Lri, g.B);
    g.J = Lri.prototype;
    g.J.d5 = function() {
        var l = this.api.getPlayerStateObject();
        !this.api.getVideoData().mutedAutoplay || g.L(l, 2) ? this.hide() : this.Ag || (g.B.prototype.show.call(this), this.api.logVisibility(this.element, this.Ag))
    };
    g.J.oTf = function() {
        this.D && this.D.hide()
    };
    g.J.onAutoplayBlocked = function() {
        this.hide();
        hP7(this.api.getVideoData())
    };
    g.J.onClick = function() {
        if (!this.G) {
            g.DK(this.api.getRootNode(), "ytp-muted-autoplay", !1);
            var l = this.api.getVideoData(),
                c = this.api.getCurrentTime();
            hP7(l);
            this.api.loadVideoById(l.videoId, c);
            this.api.N2();
            this.api.logClick(this.element);
            this.api.fV("onMutedAutoplayEnds");
            this.G = !0
        }
    };
    g.J.onMutedAutoplayEnds = function() {
        this.watermark && (this.watermark.Tz(), this.watermark = null)
    };
    g.P(lK, g.B);
    lK.prototype.hide = function() {
        g.yu(this.api.getRootNode(), "ytp-expand-pause-overlay");
        g.B.prototype.hide.call(this)
    };
    lK.prototype.T = function() {
        this.G = !0;
        g.yu(this.api.getRootNode(), "ytp-expand-pause-overlay");
        this.api.isEmbedsShortsMode() && this.api.logVisibility(this.element, !1);
        this.expandButton.focus()
    };
    lK.prototype.W = function() {
        this.G = !1;
        g.Jj(this.api.getRootNode(), "ytp-expand-pause-overlay");
        this.api.isEmbedsShortsMode() && this.api.logVisibility(this.element, !0);
        this.focus()
    };
    lK.prototype.df = function() {
        var l = this.api.getPlayerStateObject();
        g.L(l, 1) || g.L(l, 16) || g.L(l, 32) || (!g.L(l, 4) || g.L(l, 2) || g.L(l, 1024) ? (this.G || this.api.logVisibility(this.element, !1), this.fade.hide()) : this.D.hasSuggestions() && (this.G || (g.Jj(this.api.getRootNode(), "ytp-expand-pause-overlay"), g.uy(this.D), this.D.show(), this.api.logVisibility(this.element, !0)), this.fade.show()))
    };
    g.P(c$, g.B);
    c$.prototype.show = function() {
        g.B.prototype.show.call(this);
        this.api.logVisibility(this.element, !0)
    };
    c$.prototype.Tz = function() {
        Yd(this);
        g.B.prototype.Tz.call(this)
    };
    g.P(A8L, g.GH);
    g.J = A8L.prototype;
    g.J.Pn = function() {
        return !1
    };
    g.J.create = function() {
        var l = this.V.L(),
            c = g.qu(this.V),
            Y, X = (Y = this.V.getVideoData()) == null ? void 0 : Y.clientPlaybackNonce;
        X && g.m$({
            clientPlaybackNonce: X
        });
        l.uQ && !l.disableOrganicUi && I1E(this);
        var k;
        (k = l.getWebPlayerContextConfig()) != null && k.embedsEnableEmc3ds || (this.U = new Lri(this.V), g.Z(this, this.U), g.oD(this.V, this.U.element, 4), this.Kh = new Ft(this.V), g.Z(this, this.Kh), g.oD(this.V, this.Kh.element, 4));
        l.oe && (this.watermark = new Iu(this.V), g.Z(this, this.watermark), g.oD(this.V, this.watermark.element, 8));
        c && !l.disableOrganicUi && (this.W = new m57(this.V, c), g.Z(this, this.W), g.oD(this.V, this.W.element, 8), this.V.isMutedByEmbedsMutedAutoplay() && (this.onMutedAutoplayStarts(), this.W.hide()));
        l.G && !l.disableOrganicUi && (this.AJ = new AB(this.V), g.Z(this, this.AJ), g.oD(this.V, this.AJ.element, 4));
        this.D.Z(this.V, "appresize", this.i9);
        this.D.Z(this.V, "presentingplayerstatechange", this.WW);
        this.D.Z(this.V, "videodatachange", this.onVideoDataChange);
        this.D.Z(this.V, "videoplayerreset", this.onReset);
        this.D.Z(this.V, "onMutedAutoplayStarts",
            this.onMutedAutoplayStarts);
        this.D.Z(this.V, "onAdStart", this.onAdStart);
        this.D.Z(this.V, "onAdComplete", this.onAdComplete);
        this.D.Z(this.V, "onAdSkip", this.onAdSkip);
        this.D.Z(this.V, "onAdStateChange", this.onAdStateChange);
        if (this.C = g.D0(g.ZW(l))) this.countdownTimer = new c$(this.V), g.Z(this, this.countdownTimer), g.oD(this.V, this.countdownTimer.element, 4), this.countdownTimer.hide(), this.D.Z(this.V, g.Jv("embeds"), this.onCueRangeEnter), this.D.Z(this.V, g.d8("embeds"), this.onCueRangeExit);
        this.JW(this.V.getPlayerStateObject());
        this.player.Qd("embed");
        var r, e;
        ((r = this.V.L().getWebPlayerContextConfig()) == null ? 0 : (e = r.embedsHostFlags) == null ? 0 : e.allowOverridingVisitorDataPlayerVars) && (l = g.Ln("IDENTITY_MEMENTO")) && this.V.Fr("onMementoChange", l)
    };
    g.J.onCueRangeEnter = function(l) {
        l.getId() === "countdown timer" && this.countdownTimer && (this.countdownTimer.show(), gPQ(this.countdownTimer))
    };
    g.J.onCueRangeExit = function(l) {
        l.getId() === "countdown timer" && this.countdownTimer && (Yd(this.countdownTimer), this.countdownTimer.hide())
    };
    g.J.i9 = function() {
        var l = this.V.m0().getPlayerSize();
        this.Zf && this.Zf.resize(l)
    };
    g.J.onReset = function() {
        uPM(this)
    };
    g.J.WW = function(l) {
        this.JW(l.state)
    };
    g.J.JW = function(l) {
        g.L(l, 128) ? (this.Zf || (this.Zf = new u$(this.V), g.Z(this, this.Zf), g.oD(this.V, this.Zf.element, 4)), this.Zf.G(l.j0), this.Zf.show(), g.Jj(this.V.getRootNode(), "ytp-embed-error")) : this.Zf && (this.Zf.dispose(), this.Zf = null, g.yu(this.V.getRootNode(), "ytp-embed-error"));
        if (this.countdownTimer && this.countdownTimer.D)
            if (g.L(l, 64)) this.countdownTimer.hide(), Yd(this.countdownTimer);
            else if (l.isPaused()) {
            var c = this.countdownTimer;
            c.G || (c.G = !0, c.W = (0, g.nb)())
        } else l.isPlaying() && this.countdownTimer.G &&
            (c = this.countdownTimer, c.G && (c.T += (0, g.nb)() - c.W, c.G = !1, EPU(c)));
        FrQ(this, l)
    };
    g.J.onMutedAutoplayStarts = function() {
        this.V.getVideoData().mutedAutoplay && this.U && g.DK(this.V.getRootNode(), "ytp-muted-autoplay", !0)
    };
    g.J.onVideoDataChange = function(l, c) {
        var Y = this.qp !== c.videoId;
        l = !Y && l === "dataloaded";
        var X = {
            isShortsModeEnabled: !!this.V.isEmbedsShortsMode()
        };
        g.Oq("embedsVideoDataDidChange", {
            clientPlaybackNonce: c.clientPlaybackNonce,
            isReload: l,
            runtimeEnabledFeatures: X
        });
        Y && (this.qp = c.videoId, this.countdownTimer && (this.countdownTimer.show(), this.countdownTimer.hide()), this.C && (this.V.EU("embeds"), c.isAd() || c.limitedPlaybackDurationInSeconds < 5 || g.KX(this.V) || (c = Math.max((c.startSeconds + c.limitedPlaybackDurationInSeconds -
            5) * 1E3, 0), c = new g.r8(c, c + 5E3, {
            id: "countdown timer",
            namespace: "embeds"
        }), this.V.jk([c]))), this.V.L().uQ && !this.V.L().disableOrganicUi && (uPM(this), I1E(this)));
        this.V.L().K && this.K && this.K.detach()
    };
    g.J.onAdStart = function() {
        XV(this, "EMBEDS_AD_EVENT_TYPE_AD_STARTED")
    };
    g.J.onAdComplete = function() {
        XV(this, "EMBEDS_AD_EVENT_TYPE_AD_COMPLETED")
    };
    g.J.onAdSkip = function() {
        XV(this, "EMBEDS_AD_EVENT_TYPE_AD_SKIPPED")
    };
    g.J.onAdStateChange = function(l) {
        l === 2 && XV(this, "EMBEDS_AD_EVENT_TYPE_AD_PAUSED")
    };
    g.U$("embed", A8L);
})(_yt_player);