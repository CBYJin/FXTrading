(function(g) {
    var window = this;
    'use strict';
    var l9N = function(l) {
            l.publish("autonavvisibility")
        },
        cRe = function(l, c) {
            l.cU("onAutonavCoundownStarted", c)
        },
        YQ7 = function(l) {
            var c, Y, X;
            return l == null ? void 0 : (c = l.playerOverlays) == null ? void 0 : (Y = c.playerOverlayRenderer) == null ? void 0 : (X = Y.autoplay) == null ? void 0 : X.playerOverlayAutoplayRenderer
        },
        kd = function(l, c, Y) {
            g.DK(l.element, "ytp-suggestion-set", !!c.videoId);
            var X = c.playlistId;
            Y = c.Bp(Y ? Y : "mqdefault.jpg");
            var k = null,
                r = null;
            c instanceof g.vZ && (c.lengthText ? (k = c.lengthText || null, r = c.Z9 || null) : c.lengthSeconds && (k = g.vE(c.lengthSeconds), r = g.vE(c.lengthSeconds, !0)));
            var e = !!X;
            X = e && g.iz(X).type === "RD";
            var d = c instanceof g.vZ ? c.isLivePlayback : null,
                y = c instanceof g.vZ ? c.isUpcoming : null,
                O = c.author,
                D = c.shortViewCount,
                t = c.publishedTimeText,
                U = [],
                G = [];
            O && U.push(O);
            D && (U.push(D), G.push(D));
            t && G.push(t);
            Y = {
                title: c.title,
                author: O,
                author_and_views: U.join(" \u2022 "),
                aria_label: c.ariaLabel ||
                    g.qi("Watch $TITLE", {
                        TITLE: c.title
                    }),
                duration: k,
                timestamp: r,
                url: c.If(),
                is_live: d,
                is_upcoming: y,
                is_list: e,
                is_mix: X,
                background: Y ? "background-image: url(" + Y + ")" : "",
                views_and_publish_time: G.join(" \u2022 "),
                autoplayAlternativeHeader: c.Im
            };
            c instanceof g.SK && (Y.playlist_length = c.playlistLength);
            l.update(Y)
        },
        rc = function(l) {
            var c = l.L(),
                Y = c.T;
            g.B.call(this, {
                J: "a",
                X: "ytp-autonav-suggestion-card",
                S: {
                    href: "{{url}}",
                    target: Y ? c.j : "",
                    "aria-label": "{{aria_label}}",
                    "data-is-live": "{{is_live}}",
                    "data-is-list": "{{is_list}}",
                    "data-is-mix": "{{is_mix}}",
                    "data-is-upcoming": "{{is_upcoming}}"
                },
                Y: [{
                    J: "div",
                    WU: ["ytp-autonav-endscreen-upnext-thumbnail", "ytp-autonav-thumbnail-small"],
                    S: {
                        style: "{{background}}"
                    },
                    Y: [{
                        J: "div",
                        S: {
                            "aria-label": "{{timestamp}}"
                        },
                        WU: ["ytp-autonav-timestamp"],
                        Qf: "{{duration}}"
                    }, {
                        J: "div",
                        WU: ["ytp-autonav-live-stamp"],
                        Qf: "Live"
                    }, {
                        J: "div",
                        WU: ["ytp-autonav-upcoming-stamp"],
                        Qf: "Upcoming"
                    }, {
                        J: "div",
                        X: "ytp-autonav-list-overlay",
                        Y: [{
                            J: "div",
                            X: "ytp-autonav-mix-text",
                            Qf: "Mix"
                        }, {
                            J: "div",
                            X: "ytp-autonav-mix-icon"
                        }]
                    }]
                }, {
                    J: "div",
                    WU: ["ytp-autonav-endscreen-upnext-title", "ytp-autonav-title-card"],
                    Qf: "{{title}}"
                }, {
                    J: "div",
                    WU: ["ytp-autonav-endscreen-upnext-author", "ytp-autonav-author-card"],
                    Qf: "{{author}}"
                }, {
                    J: "div",
                    WU: ["ytp-autonav-endscreen-upnext-author", "ytp-autonav-view-and-date-card"],
                    Qf: "{{views_and_publish_time}}"
                }]
            });
            this.V = l;
            this.suggestion =
                null;
            this.D = Y;
            this.listen("click", this.onClick);
            this.listen("keypress", this.onKeyPress)
        },
        eY = function(l, c) {
            c = c === void 0 ? !1 : c;
            g.B.call(this, {
                J: "div",
                X: "ytp-autonav-endscreen-countdown-overlay"
            });
            var Y = this;
            this.C = c;
            this.cancelCommand = this.W = void 0;
            this.K = 0;
            this.container = new g.B({
                J: "div",
                X: "ytp-autonav-endscreen-countdown-container"
            });
            g.Z(this, this.container);
            this.container.Vf(this.element);
            c = l.L();
            var X = c.T;
            this.V = l;
            this.suggestion = null;
            this.onVideoDataChange("newdata", this.V.getVideoData());
            this.Z(l, "videodatachange", this.onVideoDataChange);
            this.D = new g.B({
                J: "div",
                X: "ytp-autonav-endscreen-upnext-container",
                S: {
                    "aria-label": "{{aria_label}}",
                    "data-is-live": "{{is_live}}",
                    "data-is-list": "{{is_list}}",
                    "data-is-mix": "{{is_mix}}",
                    "data-is-upcoming": "{{is_upcoming}}"
                },
                Y: [{
                    J: "div",
                    X: "ytp-autonav-endscreen-upnext-header"
                }, {
                    J: "div",
                    X: "ytp-autonav-endscreen-upnext-alternative-header",
                    Qf: "{{autoplayAlternativeHeader}}"
                }, {
                    J: "a",
                    X: "ytp-autonav-endscreen-link-container",
                    S: {
                        href: "{{url}}",
                        target: X ? c.j : ""
                    },
                    Y: [{
                        J: "div",
                        X: "ytp-autonav-endscreen-upnext-thumbnail",
                        S: {
                            style: "{{background}}"
                        },
                        Y: [{
                            J: "div",
                            S: {
                                "aria-label": "{{timestamp}}"
                            },
                            WU: ["ytp-autonav-timestamp"],
                            Qf: "{{duration}}"
                        }, {
                            J: "div",
                            WU: ["ytp-autonav-live-stamp"],
                            Qf: "Live"
                        }, {
                            J: "div",
                            WU: ["ytp-autonav-upcoming-stamp"],
                            Qf: "Upcoming"
                        }]
                    }, {
                        J: "div",
                        X: "ytp-autonav-endscreen-video-info",
                        Y: [{
                            J: "div",
                            X: "ytp-autonav-endscreen-premium-badge"
                        }, {
                            J: "div",
                            X: "ytp-autonav-endscreen-upnext-title",
                            Qf: "{{title}}"
                        }, {
                            J: "div",
                            X: "ytp-autonav-endscreen-upnext-author",
                            Qf: "{{author}}"
                        }, {
                            J: "div",
                            X: "ytp-autonav-view-and-date",
                            Qf: "{{views_and_publish_time}}"
                        }, {
                            J: "div",
                            X: "ytp-autonav-author-and-view",
                            Qf: "{{author_and_views}}"
                        }]
                    }]
                }]
            });
            g.Z(this, this.D);
            this.D.Vf(this.container.element);
            X || this.Z(this.D.wf("ytp-autonav-endscreen-link-container"), "click", this.f1);
            this.V.createClientVe(this.container.element, this, 115127);
            this.V.createClientVe(this.D.wf("ytp-autonav-endscreen-link-container"), this, 115128);
            this.overlay = new g.B({
                J: "div",
                X: "ytp-autonav-overlay"
            });
            g.Z(this, this.overlay);
            this.overlay.Vf(this.container.element);
            this.G = new g.B({
                J: "div",
                X: "ytp-autonav-endscreen-button-container"
            });
            g.Z(this, this.G);
            this.G.Vf(this.container.element);
            this.cancelButton = new g.B({
                J: "button",
                WU: ["ytp-autonav-endscreen-upnext-button", "ytp-autonav-endscreen-upnext-cancel-button", c.B("web_modern_buttons") ? "ytp-autonav-endscreen-upnext-button-rounded" : ""],
                S: {
                    "aria-label": "Cancel autoplay"
                },
                Qf: "Cancel"
            });
            g.Z(this, this.cancelButton);
            this.cancelButton.Vf(this.G.element);
            this.cancelButton.listen("click", this.D4, this);
            this.V.createClientVe(this.cancelButton.element, this, 115129);
            this.playButton = new g.B({
                J: "a",
                WU: ["ytp-autonav-endscreen-upnext-button", "ytp-autonav-endscreen-upnext-play-button",
                    c.B("web_modern_buttons") ? "ytp-autonav-endscreen-upnext-button-rounded" : ""
                ],
                S: {
                    href: "{{url}}",
                    role: "button",
                    "aria-label": "Play next video"
                },
                Qf: "Play Now"
            });
            g.Z(this, this.playButton);
            this.playButton.Vf(this.G.element);
            this.playButton.listen("click", this.f1, this);
            this.V.createServerVe(this.playButton.element, this.playButton, !0);
            (c = this.V.getVideoData()) && Xbc(this, c);
            this.T = new g.gY(function() {
                kFN(Y)
            }, 500);
            g.Z(this, this.T);
            this.jr();
            this.Z(l, "autonavvisibility", this.jr);
            this.V.B("web_autonav_color_transition") && (this.Z(l, "autonavchange", this.f5), this.Z(l, "onAutonavCoundownStarted", this.gFA))
        },
        JK = function(l) {
            var c = l.V.ag(!0, l.V.isFullscreen());
            g.DK(l.container.element, "ytp-autonav-endscreen-small-mode", l.QA(c));
            g.DK(l.container.element, "ytp-autonav-endscreen-is-premium", !!l.suggestion && !!l.suggestion.Fzf);
            g.DK(l.V.getRootNode(), "ytp-autonav-endscreen-cancelled-state", !l.V.yF());
            g.DK(l.V.getRootNode(), "countdown-running", l.u5());
            g.DK(l.container.element, "ytp-player-content", l.V.yF());
            g.dg(l.overlay.element, {
                width: c.width + "px"
            });
            if (!l.u5()) {
                l.V.yF() ? rRE(l, Math.round(eVL(l) / 1E3)) : rRE(l);
                c = !!l.suggestion && !!l.suggestion.Im;
                var Y = l.V.yF() ||
                    !c;
                g.DK(l.container.element, "ytp-autonav-endscreen-upnext-alternative-header-only", !Y && c);
                g.DK(l.container.element, "ytp-autonav-endscreen-upnext-no-alternative-header", Y && !c);
                l.G.QB(l.V.yF());
                g.DK(l.element, "ytp-enable-w2w-color-transitions", JRi(l))
            }
        },
        kFN = function(l) {
            var c = eVL(l),
                Y = Math,
                X = Y.min;
            var k = l.K ? Date.now() - l.K : 0;
            Y = X.call(Y, k, c);
            rRE(l, Math.ceil((c - Y) / 1E3));
            c - Y <= 500 && l.u5() ? l.select(!0) : l.u5() && l.T.start()
        },
        eVL = function(l) {
            if (l.V.isFullscreen()) {
                var c;
                l = (c = l.V.getVideoData()) == null ? void 0 : c.Az;
                return l === -1 || l === void 0 ? 8E3 : l
            }
            return l.V.Rm() >= 0 ? l.V.Rm() : g.GR(l.V.L().experiments, "autoplay_time") || 1E4
        },
        Xbc = function(l, c) {
            c = c.getWatchNextResponse();
            var Y, X;
            c = (Y = YQ7(c)) == null ? void 0 : (X = Y.nextButton) == null ? void 0 : X.buttonRenderer;
            l.W = c == null ? void 0 : c.navigationEndpoint;
            Y = c == null ? void 0 : c.trackingParams;
            l.playButton && Y && l.V.setTrackingParams(l.playButton.element, Y)
        },
        JRi = function(l) {
            var c;
            return !((c = l.V.getVideoData()) == null || !c.watchToWatchTransitionRenderer)
        },
        rRE = function(l, c) {
            c = c === void 0 ? -1 : c;
            l = l.D.wf("ytp-autonav-endscreen-upnext-header");
            g.yD(l);
            if (c >= 0) {
                c = String(c);
                var Y = "Up next in $SECONDS".match(RegExp("\\$SECONDS", "gi"))[0],
                    X = "Up next in $SECONDS".indexOf(Y);
                if (X >= 0) {
                    l.appendChild(g.JG("Up next in $SECONDS".slice(0, X)));
                    var k = g.eR("span");
                    g.XO(k, "ytp-autonav-endscreen-upnext-header-countdown-number");
                    g.Uu(k, c);
                    l.appendChild(k);
                    l.appendChild(g.JG("Up next in $SECONDS".slice(X + Y.length)));
                    return
                }
            }
            g.Uu(l, "Up next")
        },
        dc = function(l, c) {
            g.B.call(this, {
                J: "div",
                WU: ["html5-endscreen", "ytp-player-content", c || "base-endscreen"]
            });
            this.created = !1;
            this.player = l
        },
        y2 = function(l) {
            g.B.call(this, {
                J: "div",
                WU: ["ytp-upnext", "ytp-player-content"],
                S: {
                    "aria-label": "{{aria_label}}"
                },
                Y: [{
                    J: "div",
                    X: "ytp-cued-thumbnail-overlay-image",
                    S: {
                        style: "{{background}}"
                    }
                }, {
                    J: "span",
                    X: "ytp-upnext-top",
                    Y: [{
                        J: "span",
                        X: "ytp-upnext-header",
                        Qf: "Up Next"
                    }, {
                        J: "span",
                        X: "ytp-upnext-title",
                        Qf: "{{title}}"
                    }, {
                        J: "span",
                        X: "ytp-upnext-author",
                        Qf: "{{author}}"
                    }]
                }, {
                    J: "a",
                    X: "ytp-upnext-autoplay-icon",
                    S: {
                        role: "button",
                        href: "{{url}}",
                        "aria-label": "Play next video"
                    },
                    Y: [{
                        J: "svg",
                        S: {
                            height: "100%",
                            version: "1.1",
                            viewBox: "0 0 72 72",
                            width: "100%"
                        },
                        Y: [{
                            J: "circle",
                            X: "ytp-svg-autoplay-circle",
                            S: {
                                cx: "36",
                                cy: "36",
                                fill: "#fff",
                                "fill-opacity": "0.3",
                                r: "31.5"
                            }
                        }, {
                            J: "circle",
                            X: "ytp-svg-autoplay-ring",
                            S: {
                                cx: "-36",
                                cy: "36",
                                "fill-opacity": "0",
                                r: "33.5",
                                stroke: "#FFFFFF",
                                "stroke-dasharray": "211",
                                "stroke-dashoffset": "-211",
                                "stroke-width": "4",
                                transform: "rotate(-90)"
                            }
                        }, {
                            J: "path",
                            X: "ytp-svg-fill",
                            S: {
                                d: "M 24,48 41,36 24,24 V 48 z M 44,24 v 24 h 4 V 24 h -4 z"
                            }
                        }]
                    }]
                }, {
                    J: "span",
                    X: "ytp-upnext-bottom",
                    Y: [{
                        J: "span",
                        X: "ytp-upnext-cancel"
                    }, {
                        J: "span",
                        X: "ytp-upnext-paused",
                        Qf: "Autoplay is paused"
                    }]
                }]
            });
            this.api = l;
            this.cancelButton = null;
            this.W = this.wf("ytp-svg-autoplay-ring");
            this.K = this.notification = this.D = this.suggestion = null;
            this.T = new g.gY(this.wP, 5E3, this);
            this.G = 0;
            var c = this.wf("ytp-upnext-cancel");
            this.cancelButton = new g.B({
                J: "button",
                WU: ["ytp-upnext-cancel-button", "ytp-button"],
                S: {
                    tabindex: "0",
                    "aria-label": "Cancel autoplay"
                },
                Qf: "Cancel"
            });
            g.Z(this, this.cancelButton);
            this.cancelButton.listen("click", this.Gk, this);
            this.cancelButton.Vf(c);
            this.cancelButton && this.api.createClientVe(this.cancelButton.element,
                this, 115129);
            g.Z(this, this.T);
            this.api.createClientVe(this.element, this, 18788);
            c = this.wf("ytp-upnext-autoplay-icon");
            this.Z(c, "click", this.Ak);
            this.api.createClientVe(c, this, 115130);
            this.D2();
            this.Z(l, "autonavvisibility", this.D2);
            this.Z(l, "mdxnowautoplaying", this.iCf);
            this.Z(l, "mdxautoplaycanceled", this.pAh);
            g.DK(this.element, "ytp-upnext-mobile", this.api.L().G)
        },
        dgN = function(l, c) {
            if (c) return c;
            if (l.api.isFullscreen()) {
                var Y;
                l = (Y = l.api.getVideoData()) == null ? void 0 : Y.Az;
                return l === -1 || l === void 0 ? 8E3 : l
            }
            return l.api.Rm() >= 0 ? l.api.Rm() : g.GR(l.api.L().experiments, "autoplay_time") || 1E4
        },
        yRi = function(l, c) {
            c = dgN(l, c);
            var Y = Math,
                X = Y.min;
            var k = (0, g.nb)() - l.G;
            Y = X.call(Y, k, c);
            c = c === 0 ? 1 : Math.min(Y / c, 1);
            l.W.setAttribute("stroke-dashoffset", "" + -211 * (c + 1));
            c >= 1 && l.u5() && l.api.getPresentingPlayerType() !== 3 ? l.select(!0) : l.u5() && l.D.start()
        },
        Ok = function(l) {
            dc.call(this, l, "autonav-endscreen");
            this.overlay = this.videoData = null;
            this.table = new g.B({
                J: "div",
                X: "ytp-suggestion-panel",
                Y: [{
                    J: "div",
                    WU: ["ytp-autonav-endscreen-upnext-header", "ytp-autonav-endscreen-more-videos"],
                    Qf: "More videos"
                }]
            });
            this.U = new g.B({
                J: "div",
                X: "ytp-suggestions-container"
            });
            this.videos = [];
            this.K = null;
            this.W = this.C = !1;
            this.G = new eY(this.player);
            g.Z(this, this.G);
            this.G.Vf(this.element);
            l.getVideoData().Sk ? this.D = this.G : (this.D = new y2(l), g.oD(this.player, this.D.element, 4), g.Z(this, this.D));
            this.overlay = new g.B({
                J: "div",
                X: "ytp-autonav-overlay-cancelled-state"
            });
            g.Z(this, this.overlay);
            this.overlay.Vf(this.element);
            this.T = new g.Cr(this);
            g.Z(this, this.T);
            g.Z(this, this.table);
            this.table.Vf(this.element);
            this.table.show();
            g.Z(this, this.U);
            this.U.Vf(this.table.element);
            this.hide()
        },
        D2 = function(l) {
            var c = l.yF();
            c !== l.W && (l.W = c, l9N(l.player), l.W ? (l.G !== l.D && l.G.hide(), l.table.hide()) : (l.G !== l.D && l.G.show(), l.table.show()))
        },
        tK = function(l, c) {
            g.B.call(this, {
                J: "button",
                WU: ["ytp-watch-on-youtube-button", "ytp-button"],
                Qf: "{{content}}"
            });
            this.V = l;
            this.buttonType = this.buttonType = c;
            this.qf();
            this.buttonType === 2 && g.Jj(this.element, "ytp-continue-watching-button");
            this.listen("click", this.onClick);
            this.listen("videodatachange", this.qf);
            this.QB(!0)
        },
        Uk = function(l, c) {
            dc.call(this, l, "embeds-lite-endscreen");
            this.V = l;
            this.D = c;
            this.V.createClientVe(this.element, this, 156943);
            this.watchButton = new tK(l, 2);
            g.Z(this, this.watchButton);
            this.watchButton.Vf(this.element);
            this.hide()
        },
        GC = function(l) {
            var c = l.L(),
                Y = g.Th || g.zn ? {
                    style: "will-change: opacity"
                } : void 0,
                X = c.T,
                k = ["ytp-modern-videowall-still"];
            c.G && k.push("ytp-videowall-show-text");
            g.B.call(this, {
                J: "a",
                WU: k,
                S: {
                    href: "{{url}}",
                    target: X ? c.j : "",
                    "aria-label": "{{aria_label}}",
                    "data-is-live": "{{is_live}}",
                    "data-is-list": "{{is_list}}",
                    "data-is-mix": "{{is_mix}}"
                },
                Y: [{
                    J: "div",
                    X: "ytp-modern-videowall-still-image",
                    S: {
                        style: "{{background}}"
                    },
                    Y: [{
                        J: "span",
                        X: "ytp-modern-videowall-still-info-duration",
                        Qf: "{{duration}}"
                    }]
                }, {
                    J: "span",
                    X: "ytp-modern-videowall-still-info",
                    S: {
                        "aria-hidden": "true"
                    },
                    Y: [{
                        J: "span",
                        X: "ytp-modern-videowall-still-info-bg",
                        Y: [{
                            J: "span",
                            X: "ytp-modern-videowall-still-info-content",
                            S: Y,
                            Y: [{
                                J: "span",
                                X: "ytp-modern-videowall-still-info-title",
                                Qf: "{{title}}"
                            }, {
                                J: "span",
                                X: "ytp-modern-videowall-still-info-author",
                                Qf: "{{author_and_views}}"
                            }, {
                                J: "span",
                                X: "ytp-modern-videowall-still-info-live",
                                Qf: "Live"
                            }]
                        }]
                    }]
                }, {
                    J: "span",
                    WU: ["ytp-modern-videowall-still-listlabel-regular", "ytp-modern-videowall-still-listlabel"],
                    S: {
                        "aria-hidden": "true"
                    },
                    Y: [{
                        J: "span",
                        X: "ytp-modern-videowall-still-listlabel-icon"
                    }, "Playlist", {
                        J: "span",
                        X: "ytp-modern-videowall-still-listlabel-length",
                        Y: [" (", {
                            J: "span",
                            Qf: "{{playlist_length}}"
                        }, ")"]
                    }]
                }, {
                    J: "span",
                    WU: ["ytp-modern-videowall-still-listlabel-mix", "ytp-modern-videowall-still-listlabel"],
                    S: {
                        "aria-hidden": "true"
                    },
                    Y: [{
                        J: "span",
                        X: "ytp-modern-videowall-still-listlabel-mix-icon"
                    }, "Mix", {
                        J: "span",
                        X: "ytp-modern-videowall-still-listlabel-length",
                        Qf: " (50+)"
                    }]
                }]
            });
            this.suggestion = null;
            this.G = X;
            this.api = l;
            this.D = new g.Cr(this);
            g.Z(this, this.D);
            this.listen("click", this.onClick);
            this.listen("keypress", this.onKeyPress);
            this.D.Z(l, "videodatachange",
                this.onVideoDataChange);
            l.createServerVe(this.element, this);
            this.onVideoDataChange()
        },
        O3Q = function(l) {
            dc.call(this, l, "videowall-endscreen");
            var c = this;
            this.V = l;
            this.stills = [];
            this.K = this.videoData = null;
            this.T = this.C = !1;
            this.U = null;
            g.Jj(this.element, "modern-videowall-endscreen");
            this.G = new g.Cr(this);
            g.Z(this, this.G);
            this.W = new g.gY(function() {
                g.Jj(c.element, "ytp-show-tiles")
            }, 0);
            g.Z(this, this.W);
            this.table = new g.tu({
                J: "div",
                X: "ytp-modern-endscreen-content"
            });
            g.Z(this, this.table);
            this.table.Vf(this.element);
            l.getVideoData().Sk ? this.D = new eY(l, !0) : this.D = new y2(l);
            g.Z(this, this.D);
            g.oD(this.player, this.D.element, 4);
            l.createClientVe(this.element, this, 158789);
            this.hide()
        },
        fT = function(l) {
            return g.CX(l.player) && l.Nz() && !l.K
        },
        P$ = function(l) {
            var c = l.yF();
            c !== l.C && (l.C = c, l9N(l.player))
        },
        DgU = function(l) {
            dc.call(this, l, "subscribecard-endscreen");
            this.D = new g.B({
                J: "div",
                X: "ytp-subscribe-card",
                Y: [{
                    J: "img",
                    X: "ytp-author-image",
                    S: {
                        src: "{{profilePicture}}"
                    }
                }, {
                    J: "div",
                    X: "ytp-subscribe-card-right",
                    Y: [{
                        J: "div",
                        X: "ytp-author-name",
                        Qf: "{{author}}"
                    }, {
                        J: "div",
                        X: "html5-subscribe-button-container"
                    }]
                }]
            });
            g.Z(this, this.D);
            this.D.Vf(this.element);
            var c = l.getVideoData();
            this.subscribeButton = new g.E$("Subscribe", null, "Unsubscribe", null, !0, !1, c.NZ, c.subscribed, "trailer-endscreen", null, l, !1);
            g.Z(this, this.subscribeButton);
            this.subscribeButton.Vf(this.D.wf("html5-subscribe-button-container"));
            this.Z(l, "videodatachange", this.df);
            this.df();
            this.hide()
        },
        bK = function(l) {
            var c = l.L(),
                Y = g.Th || g.zn ? {
                    style: "will-change: opacity"
                } : void 0,
                X = c.T,
                k = ["ytp-videowall-still"];
            c.G && k.push("ytp-videowall-show-text");
            g.B.call(this, {
                J: "a",
                WU: k,
                S: {
                    href: "{{url}}",
                    target: X ? c.j : "",
                    "aria-label": "{{aria_label}}",
                    "data-is-live": "{{is_live}}",
                    "data-is-list": "{{is_list}}",
                    "data-is-mix": "{{is_mix}}"
                },
                Y: [{
                    J: "div",
                    X: "ytp-videowall-still-image",
                    S: {
                        style: "{{background}}"
                    }
                }, {
                    J: "span",
                    X: "ytp-videowall-still-info",
                    S: {
                        "aria-hidden": "true"
                    },
                    Y: [{
                        J: "span",
                        X: "ytp-videowall-still-info-bg",
                        Y: [{
                            J: "span",
                            X: "ytp-videowall-still-info-content",
                            S: Y,
                            Y: [{
                                    J: "span",
                                    X: "ytp-videowall-still-info-title",
                                    Qf: "{{title}}"
                                },
                                {
                                    J: "span",
                                    X: "ytp-videowall-still-info-author",
                                    Qf: "{{author_and_views}}"
                                }, {
                                    J: "span",
                                    X: "ytp-videowall-still-info-live",
                                    Qf: "Live"
                                }, {
                                    J: "span",
                                    X: "ytp-videowall-still-info-duration",
                                    Qf: "{{duration}}"
                                }
                            ]
                        }]
                    }]
                }, {
                    J: "span",
                    WU: ["ytp-videowall-still-listlabel-regular", "ytp-videowall-still-listlabel"],
                    S: {
                        "aria-hidden": "true"
                    },
                    Y: [{
                        J: "span",
                        X: "ytp-videowall-still-listlabel-icon"
                    }, "Playlist", {
                        J: "span",
                        X: "ytp-videowall-still-listlabel-length",
                        Y: [" (", {
                            J: "span",
                            Qf: "{{playlist_length}}"
                        }, ")"]
                    }]
                }, {
                    J: "span",
                    WU: ["ytp-videowall-still-listlabel-mix",
                        "ytp-videowall-still-listlabel"
                    ],
                    S: {
                        "aria-hidden": "true"
                    },
                    Y: [{
                        J: "span",
                        X: "ytp-videowall-still-listlabel-mix-icon"
                    }, "Mix", {
                        J: "span",
                        X: "ytp-videowall-still-listlabel-length",
                        Qf: " (50+)"
                    }]
                }]
            });
            this.suggestion = null;
            this.G = X;
            this.api = l;
            this.D = new g.Cr(this);
            g.Z(this, this.D);
            this.listen("click", this.onClick);
            this.listen("keypress", this.onKeyPress);
            this.D.Z(l, "videodatachange", this.onVideoDataChange);
            l.createServerVe(this.element, this);
            this.onVideoDataChange()
        },
        qv = function(l) {
            dc.call(this, l, "videowall-endscreen");
            var c = this;
            this.V = l;
            this.K = 0;
            this.stills = [];
            this.T = this.videoData = null;
            this.W = this.U = !1;
            this.j = null;
            this.G = new g.Cr(this);
            g.Z(this, this.G);
            this.C = new g.gY(function() {
                g.Jj(c.element, "ytp-show-tiles")
            }, 0);
            g.Z(this, this.C);
            var Y = new g.B({
                J: "button",
                WU: ["ytp-button", "ytp-endscreen-previous"],
                S: {
                    "aria-label": "Previous"
                },
                Y: [g.ps()]
            });
            g.Z(this, Y);
            Y.Vf(this.element);
            Y.listen("click", this.gI, this);
            this.table = new g.tu({
                J: "div",
                X: "ytp-endscreen-content"
            });
            g.Z(this, this.table);
            this.table.Vf(this.element);
            Y = new g.B({
                J: "button",
                WU: ["ytp-button", "ytp-endscreen-next"],
                S: {
                    "aria-label": "Next"
                },
                Y: [g.Rw()]
            });
            g.Z(this, Y);
            Y.Vf(this.element);
            Y.listen("click", this.xv, this);
            l.getVideoData().Sk ? this.D = new eY(l, !0) : this.D =
                new y2(l);
            g.Z(this, this.D);
            g.oD(this.player, this.D.element, 4);
            l.createClientVe(this.element, this, 158789);
            this.hide()
        },
        aK = function(l) {
            return g.CX(l.player) && l.Nz() && !l.T
        },
        Nv = function(l) {
            var c = l.yF();
            c !== l.U && (l.U = c, l9N(l.player))
        },
        pT = function(l) {
            dc.call(this, l, "watch-again-on-youtube-endscreen");
            this.watchButton = new tK(l, 1);
            g.Z(this, this.watchButton);
            this.watchButton.Vf(this.element);
            g.ygN(l) && (this.D = new g.gU(l), g.Z(this, this.D), this.G = new g.B({
                J: "div",
                WU: ["ytp-watch-again-on-youtube-endscreen-more-videos-container"],
                S: {
                    tabIndex: "-1"
                },
                Y: [this.D]
            }), g.Z(this, this.G), this.D.Vf(this.G.element), this.G.Vf(this.element));
            l.createClientVe(this.element, this, 156914);
            this.hide()
        },
        f9E = function(l) {
            g.GH.call(this, l);
            var c = this;
            this.endScreen = null;
            this.G = this.D = this.K = this.T = !1;
            this.listeners = new g.Cr(this);
            g.Z(this, this.listeners);
            var Y = l.L(),
                X = l.getVideoData();
            X = X && X.limitedPlaybackDurationInSeconds !== 0;
            g.D0(g.ZW(Y)) && X && !g.KX(l) ? (this.G = !0, this.endScreen = new Uk(l, g.qu(l))) : l.isEmbedsShortsMode() ? this.endScreen = new pT(l) : tDQ(l) ? (this.T = !0, Ug6(this), this.D ? this.endScreen = new Ok(l) : Y.B("delhi_modern_endscreen") ? this.endScreen = new O3Q(l) : this.endScreen = new qv(l)) : Y.uh ? this.endScreen = new DgU(l) : this.endScreen = new dc(l);
            g.Z(this, this.endScreen);
            g.oD(l, this.endScreen.element, 4);
            GFU(this);
            this.listeners.Z(l, "videodatachange", this.onVideoDataChange, this);
            this.listeners.Z(l, g.Jv("endscreen"), function(k) {
                c.onCueRangeEnter(k)
            });
            this.listeners.Z(l, g.d8("endscreen"), function(k) {
                c.onCueRangeExit(k)
            })
        },
        Ug6 = function(l) {
            var c = l.player.getVideoData();
            if (!c || l.D === c.sM && l.K === c.Sk) return !1;
            l.D = c.sM;
            l.K = c.Sk;
            return !0
        },
        tDQ = function(l) {
            l = l.L();
            return l.U$ && !l.uh && !l.disableOrganicUi
        },
        GFU = function(l) {
            l.player.EU("endscreen");
            var c = l.player.getVideoData();
            c = new g.r8(Math.max((c.lengthSeconds - 10) * 1E3, 0), 0x8000000000000, {
                id: "preload",
                namespace: "endscreen"
            });
            var Y = new g.r8(0x8000000000000, 0x8000000000000, {
                id: "load",
                priority: 8,
                namespace: "endscreen"
            });
            l.player.jk([c, Y])
        };
    g.nX.prototype.Rm = g.dy(14, function() {
        return this.app.Rm()
    });
    g.Pk.prototype.Rm = g.dy(13, function() {
        return this.getVideoData().rJ
    });
    g.S$.prototype.Gh = g.dy(12, function(l) {
        this.qx().Gh(l)
    });
    g.Dx.prototype.Gh = g.dy(11, function(l) {
        this.D !== l && (this.D = l, this.df())
    });
    g.nq.prototype.Gh = g.dy(10, function(l) {
        this.overflowButton && this.overflowButton.Gh(l)
    });
    g.S$.prototype.AG = g.dy(9, function(l) {
        this.qx().AG(l)
    });
    g.P_.prototype.AG = g.dy(8, function(l) {
        this.G !== l && (this.G = l, this.df())
    });
    g.nq.prototype.AG = g.dy(7, function(l) {
        this.shareButton && this.shareButton.AG(l)
    });
    g.S$.prototype.NI = g.dy(6, function(l) {
        this.qx().NI(l)
    });
    g.Qy.prototype.NI = g.dy(5, function(l) {
        this.s0 !== l && (this.s0 = l, this.bI())
    });
    g.S$.prototype.Wq = g.dy(4, function(l) {
        this.qx().Wq(l)
    });
    g.nq.prototype.Wq = g.dy(3, function(l) {
        this.Xm !== l && (this.Xm = l, this.X8())
    });
    g.P(rc, g.B);
    rc.prototype.select = function() {
        this.V.vn(this.suggestion.videoId, this.suggestion.sessionData, this.suggestion.playlistId, void 0, void 0, this.suggestion.Qy || void 0) && this.V.logClick(this.element)
    };
    rc.prototype.onClick = function(l) {
        g.d2(l, this.V, this.D, this.suggestion.sessionData || void 0) && this.select()
    };
    rc.prototype.onKeyPress = function(l) {
        switch (l.keyCode) {
            case 13:
            case 32:
                l.defaultPrevented || (this.select(), l.preventDefault())
        }
    };
    g.P(eY, g.B);
    g.J = eY.prototype;
    g.J.B4 = function(l) {
        this.suggestion !== l && (this.suggestion = l, kd(this.D, l), this.playButton.updateValue("url", this.suggestion.If()), JK(this))
    };
    g.J.u5 = function() {
        return this.K > 0
    };
    g.J.lX = function() {
        this.u5() || (this.K = Date.now(), kFN(this), cRe(this.V, eVL(this)), g.DK(this.V.getRootNode(), "countdown-running", this.u5()))
    };
    g.J.D0 = function() {
        this.qr();
        kFN(this);
        var l = this.D.wf("ytp-autonav-endscreen-upnext-header");
        l && g.Uu(l, "Up next")
    };
    g.J.qr = function() {
        this.u5() && (this.T.stop(), this.K = 0)
    };
    g.J.select = function(l) {
        this.V.nextVideo(!1, l === void 0 ? !1 : l);
        this.qr()
    };
    g.J.f1 = function(l) {
        g.d2(l, this.V) && (l.currentTarget === this.playButton.element ? this.V.logClick(this.playButton.element) : l.currentTarget === this.D.wf("ytp-autonav-endscreen-link-container") && (l = this.D.wf("ytp-autonav-endscreen-link-container"), this.V.logVisibility(l, !0), this.V.logClick(l)), this.W ? (this.V.cU("innertubeCommand", this.W), this.qr()) : this.select())
    };
    g.J.D4 = function() {
        this.V.logClick(this.cancelButton.element);
        g.Hx(this.V, !0);
        this.cancelCommand && this.V.cU("innertubeCommand", this.cancelCommand)
    };
    g.J.onVideoDataChange = function(l, c) {
        Xbc(this, c);
        l = c.getWatchNextResponse();
        var Y, X;
        l = (Y = YQ7(l)) == null ? void 0 : (X = Y.cancelButton) == null ? void 0 : X.buttonRenderer;
        this.cancelCommand = l == null ? void 0 : l.command
    };
    g.J.gFA = function(l) {
        if (JRi(this)) {
            var c = this.V.getVideoData().watchToWatchTransitionRenderer,
                Y = c == null ? void 0 : c.fromColorPaletteDark;
            c = c == null ? void 0 : c.toColorPaletteDark;
            if (Y && c) {
                var X = this.element;
                X.style.setProperty("--w2w-start-background-color", g.QO(Y.surgeColor));
                X.style.setProperty("--w2w-start-primary-text-color", g.QO(Y.primaryTitleColor));
                X.style.setProperty("--w2w-start-secondary-text-color", g.QO(Y.secondaryTitleColor));
                X.style.setProperty("--w2w-end-background-color", g.QO(c.surgeColor));
                X.style.setProperty("--w2w-end-primary-text-color", g.QO(c.primaryTitleColor));
                X.style.setProperty("--w2w-end-secondary-text-color", g.QO(c.secondaryTitleColor));
                X.style.setProperty("--w2w-animation-duration", l + "ms")
            }
            g.DK(this.element, "ytp-w2w-animate", !0)
        }
    };
    g.J.f5 = function(l) {
        this.V.B("web_autonav_color_transition") && l !== 2 && g.DK(this.element, "ytp-w2w-animate", !1)
    };
    g.J.jr = function() {
        var l = this.V.yF();
        this.C && this.Ag !== l && this.QB(l);
        JK(this);
        this.V.logVisibility(this.container.element, l);
        this.V.logVisibility(this.cancelButton.element, l);
        this.V.logVisibility(this.D.wf("ytp-autonav-endscreen-link-container"), l);
        this.V.logVisibility(this.playButton.element, l)
    };
    g.J.QA = function(l) {
        return l.width < 400 || l.height < 459
    };
    g.P(dc, g.B);
    g.J = dc.prototype;
    g.J.create = function() {
        this.created = !0
    };
    g.J.destroy = function() {
        this.created = !1
    };
    g.J.Nz = function() {
        return !1
    };
    g.J.yF = function() {
        return !1
    };
    g.J.Yj = function() {
        return !1
    };
    g.P(y2, g.B);
    g.J = y2.prototype;
    g.J.wP = function() {
        this.notification && (this.T.stop(), this.BA(this.K), this.K = null, this.notification.close(), this.notification = null)
    };
    g.J.B4 = function(l) {
        this.suggestion = l;
        kd(this, l, "hqdefault.jpg")
    };
    g.J.D2 = function() {
        this.QB(this.api.yF());
        this.api.logVisibility(this.element, this.api.yF());
        this.api.logVisibility(this.wf("ytp-upnext-autoplay-icon"), this.api.yF());
        this.cancelButton && this.api.logVisibility(this.cancelButton.element, this.api.yF())
    };
    g.J.KXU = function() {
        window.focus();
        this.wP()
    };
    g.J.lX = function(l) {
        var c = this;
        this.u5() || (g.y5("a11y-announce", "Up Next " + this.suggestion.title), this.G = (0, g.nb)(), this.D = new g.gY(function() {
            yRi(c, l)
        }, 25), yRi(this, l), cRe(this.api, dgN(this, l)));
        g.yu(this.element, "ytp-upnext-autoplay-paused")
    };
    g.J.hide = function() {
        g.B.prototype.hide.call(this)
    };
    g.J.u5 = function() {
        return !!this.D
    };
    g.J.D0 = function() {
        this.qr();
        this.G = (0, g.nb)();
        yRi(this);
        g.Jj(this.element, "ytp-upnext-autoplay-paused")
    };
    g.J.qr = function() {
        this.u5() && (this.D.dispose(), this.D = null)
    };
    g.J.select = function(l) {
        l = l === void 0 ? !1 : l;
        if (this.api.L().B("autonav_notifications") && l && window.Notification && typeof document.hasFocus === "function") {
            var c = Notification.permission;
            c === "default" ? Notification.requestPermission() : c !== "granted" || document.hasFocus() || (this.wP(), this.notification = new Notification("Up Next", {
                body: this.suggestion.title,
                icon: this.suggestion.Bp()
            }), this.K = this.Z(this.notification, "click", this.KXU), this.T.start())
        }
        this.qr();
        this.api.nextVideo(!1, l)
    };
    g.J.Ak = function(l) {
        !g.tG(this.cancelButton.element, l.target) && g.d2(l, this.api) && (this.api.yF() && this.api.logClick(this.wf("ytp-upnext-autoplay-icon")), this.select())
    };
    g.J.Gk = function() {
        this.api.yF() && this.cancelButton && this.api.logClick(this.cancelButton.element);
        g.Hx(this.api, !0)
    };
    g.J.iCf = function(l) {
        this.api.getPresentingPlayerType();
        this.show();
        this.lX(l)
    };
    g.J.pAh = function() {
        this.api.getPresentingPlayerType();
        this.qr();
        this.hide()
    };
    g.J.Tz = function() {
        this.qr();
        this.wP();
        g.B.prototype.Tz.call(this)
    };
    g.P(Ok, dc);
    g.J = Ok.prototype;
    g.J.create = function() {
        dc.prototype.create.call(this);
        this.T.Z(this.player, "appresize", this.Nw);
        this.T.Z(this.player, "onVideoAreaChange", this.Nw);
        this.T.Z(this.player, "videodatachange", this.onVideoDataChange);
        this.T.Z(this.player, "autonavchange", this.G4);
        this.T.Z(this.player, "onAutonavCancelled", this.K5);
        this.onVideoDataChange()
    };
    g.J.show = function() {
        dc.prototype.show.call(this);
        (this.C || this.K && this.K !== this.videoData.clientPlaybackNonce) && g.Hx(this.player, !1);
        g.CX(this.player) && this.Nz() && !this.K ? (D2(this), this.videoData.autonavState === 2 ? this.player.getVisibilityState() === 3 ? this.D.select(!0) : this.D.lX() : this.videoData.autonavState === 3 && this.D.D0()) : (g.Hx(this.player, !0), D2(this));
        this.Nw()
    };
    g.J.hide = function() {
        dc.prototype.hide.call(this);
        this.D.D0();
        D2(this)
    };
    g.J.Nw = function() {
        var l = this.player.ag(!0, this.player.isFullscreen());
        D2(this);
        JK(this.G);
        g.DK(this.element, "ytp-autonav-cancelled-small-mode", this.QA(l));
        g.DK(this.element, "ytp-autonav-cancelled-tiny-mode", this.GH(l));
        g.DK(this.element, "ytp-autonav-cancelled-mini-mode", l.width <= 400 || l.height <= 360);
        this.overlay && g.dg(this.overlay.element, {
            width: l.width + "px"
        });
        if (!this.W)
            for (l = 0; l < this.videos.length; l++) g.DK(this.videos[l].element, "ytp-suggestion-card-with-margin", l % 2 === 1)
    };
    g.J.onVideoDataChange = function() {
        var l = this.player.getVideoData();
        if (this.videoData !== l && l) {
            this.videoData = l;
            if ((l = this.videoData.suggestions) && l.length || this.player.B("web_player_autonav_empty_suggestions_fix")) {
                var c = g.cY(this.videoData);
                c && (this.D.B4(c), this.D !== this.G && this.G.B4(c))
            }
            if (l && l.length)
                for (c = 0; c < PdV.length; ++c) {
                    var Y = PdV[c];
                    if (l && l[Y]) {
                        this.videos[c] = new rc(this.player);
                        var X = this.videos[c];
                        Y = l[Y];
                        X.suggestion !== Y && (X.suggestion = Y, kd(X, Y));
                        g.Z(this, this.videos[c]);
                        this.videos[c].Vf(this.U.element)
                    }
                }
            this.Nw()
        }
    };
    g.J.G4 = function(l) {
        l === 1 ? (this.C = !1, this.K = this.videoData.clientPlaybackNonce, this.D.qr(), this.Ag && this.Nw()) : (this.C = !0, this.yF() && (l === 2 ? this.D.lX() : l === 3 && this.D.D0()))
    };
    g.J.K5 = function(l) {
        l ? this.G4(1) : (this.K = null, this.C = !1)
    };
    g.J.Nz = function() {
        return this.videoData.autonavState !== 1
    };
    g.J.QA = function(l) {
        return (l.width < 910 || l.height < 459) && !this.GH(l) && !(l.width <= 400 || l.height <= 360)
    };
    g.J.GH = function(l) {
        return l.width < 800 && !(l.width <= 400 || l.height <= 360)
    };
    g.J.yF = function() {
        return this.Ag && g.CX(this.player) && this.Nz() && !this.K
    };
    var PdV = [1, 3, 2, 4];
    g.P(tK, g.B);
    g.J = tK.prototype;
    g.J.qf = function() {
        switch (this.buttonType) {
            case 1:
                var l = "Watch again on YouTube";
                var c = 156915;
                break;
            case 2:
                l = "Continue watching on YouTube";
                c = 156942;
                break;
            default:
                l = "Continue watching on YouTube", c = 156942
        }
        this.update({
            content: l
        });
        this.V.hasVe(this.element) && this.V.destroyVe(this.element);
        this.V.createClientVe(this.element, this, c)
    };
    g.J.onClick = function(l) {
        this.V.B("web_player_log_click_before_generating_ve_conversion_params") && this.V.logClick(this.element);
        g.yF(this.getVideoUrl(), this.V, l);
        this.V.B("web_player_log_click_before_generating_ve_conversion_params") || this.V.logClick(this.element)
    };
    g.J.getVideoUrl = function() {
        var l = !0;
        switch (this.buttonType) {
            case 1:
                l = !0;
                break;
            case 2:
                l = !1
        }
        l = this.V.getVideoUrl(l, !1, !1, !0);
        var c = this.V.L();
        if (g.h2(c)) {
            var Y = {};
            g.h2(c) && g.Uz(this.V, "addEmbedsConversionTrackingParams", [Y]);
            l = g.Il(l, Y)
        }
        return l
    };
    g.J.logVisibility = function() {
        this.V.logVisibility(this.element, this.Ag && this.N)
    };
    g.J.show = function() {
        g.B.prototype.show.call(this);
        this.logVisibility()
    };
    g.J.hide = function() {
        g.B.prototype.hide.call(this);
        this.logVisibility()
    };
    g.J.UV = function(l) {
        g.B.prototype.UV.call(this, l);
        this.logVisibility()
    };
    g.P(Uk, dc);
    Uk.prototype.show = function() {
        this.player.getPlayerState() !== 3 && (dc.prototype.show.call(this), this.D.Wq(!0), this.D.AG(!0), this.V.L().vI || this.D.Gh(!0), this.V.logVisibility(this.element, !0), this.watchButton.UV(!0))
    };
    Uk.prototype.hide = function() {
        dc.prototype.hide.call(this);
        this.D.Wq(!1);
        this.D.AG(!1);
        this.D.Gh(!1);
        this.V.logVisibility(this.element, !1);
        this.watchButton.UV(!1)
    };
    g.P(GC, g.B);
    GC.prototype.select = function() {
        this.api.vn(this.suggestion.videoId, this.suggestion.sessionData, this.suggestion.playlistId, void 0, void 0, this.suggestion.Qy || void 0) && this.api.logClick(this.element)
    };
    GC.prototype.onClick = function(l) {
        if (g.h2(this.api.L()) && this.api.B("web_player_log_click_before_generating_ve_conversion_params")) {
            this.api.logClick(this.element);
            var c = this.suggestion.If(),
                Y = {};
            g.T$(this.api, Y);
            c = g.Il(c, Y);
            g.yF(c, this.api, l)
        } else g.d2(l, this.api, this.G, this.suggestion.sessionData || void 0) && this.select()
    };
    GC.prototype.onKeyPress = function(l) {
        switch (l.keyCode) {
            case 13:
            case 32:
                l.defaultPrevented || (this.select(), l.preventDefault())
        }
    };
    GC.prototype.onVideoDataChange = function() {
        var l = this.api.getVideoData(),
            c = this.api.L();
        this.G = l.UG ? !1 : c.T
    };
    g.P(O3Q, dc);
    g.J = O3Q.prototype;
    g.J.create = function() {
        dc.prototype.create.call(this);
        var l = this.player.getVideoData();
        l && (this.videoData = l);
        this.ov();
        this.G.Z(this.player, "appresize", this.ov);
        this.G.Z(this.player, "onVideoAreaChange", this.ov);
        this.G.Z(this.player, "videodatachange", this.onVideoDataChange);
        this.G.Z(this.player, "autonavchange", this.Zq);
        this.G.Z(this.player, "onAutonavCancelled", this.Qo);
        l = this.videoData.autonavState;
        l !== this.U && this.Zq(l);
        this.G.Z(this.element, "transitionend", this.Tk)
    };
    g.J.destroy = function() {
        g.HJ(this.G);
        g.ON(this.stills);
        this.stills = [];
        dc.prototype.destroy.call(this);
        g.yu(this.element, "ytp-show-tiles");
        this.W.stop();
        this.U = this.videoData.autonavState
    };
    g.J.Nz = function() {
        return this.videoData.autonavState !== 1
    };
    g.J.show = function() {
        var l = this.Ag;
        dc.prototype.show.call(this);
        g.yu(this.element, "ytp-show-tiles");
        this.player.L().G ? g.AL(this.W) : this.W.start();
        (this.T || this.K && this.K !== this.videoData.clientPlaybackNonce) && g.Hx(this.player, !1);
        fT(this) ? (P$(this), this.videoData.autonavState === 2 ? this.player.getVisibilityState() === 3 ? this.D.select(!0) : this.D.lX() : this.videoData.autonavState === 3 && this.D.D0()) : (g.Hx(this.player, !0), P$(this));
        l !== this.Ag && this.player.logVisibility(this.element, !0)
    };
    g.J.hide = function() {
        var l = this.Ag;
        dc.prototype.hide.call(this);
        this.D.D0();
        P$(this);
        l !== this.Ag && this.player.logVisibility(this.element, !1)
    };
    g.J.Tk = function(l) {
        l.target === this.element && this.ov()
    };
    g.J.ov = function() {
        var l, c, Y, X;
        var k = ((l = this.videoData) == null ? 0 : (c = l.suggestions) == null ? 0 : c.length) ? (Y = this.videoData) == null ? void 0 : Y.suggestions : [(X = this.videoData) == null ? void 0 : g.cY(X)];
        if (k.length) {
            c = this.V.ag(!0, this.V.isFullscreen());
            l = Math.floor((c.width - 64 + 16) / (g.b0(c.width * .27, 250, 450) + 16));
            c = Math.min(3, Math.floor((c.height - 64) / ((c.width - 64 - (l - 1) * 16) / l * .5625 + 70)));
            g.OD(this.element, ["ytp-modern-endscreen-limit-rows-1", "ytp-modern-endscreen-limit-rows-2", "ytp-modern-endscreen-limit-rows-3"]);
            g.Jj(this.element, "ytp-modern-endscreen-limit-rows-" + c);
            g.DK(this.element, "ytp-modern-endscreen-single-item", l === 1);
            g.DK(this.element, "ytp-modern-endscreen-row-0", c === 0);
            l = this.table.element;
            l.ariaLive = "polite";
            this.D.B4(g.cY(this.videoData));
            this.D instanceof eY && JK(this.D);
            g.DK(this.element, "ytp-endscreen-takeover", fT(this));
            P$(this);
            c = 0;
            l.ariaBusy = "true";
            Y = k.length;
            for (X = 0; X < Y; X++) {
                var r = X % Y,
                    e = this.stills[X];
                e || (e = new GC(this.player), this.stills[X] = e, l.appendChild(e.element));
                r = k[r];
                if (e.suggestion !==
                    r) {
                    e.suggestion = r;
                    var d = e.api.L();
                    kd(e, r, "hqdefault.jpg");
                    if (g.h2(d) && !e.api.B("web_player_log_click_before_generating_ve_conversion_params")) {
                        d = r.If();
                        var y = {};
                        g.Uz(e.api, "addEmbedsConversionTrackingParams", [y]);
                        d = g.Il(d, y);
                        e.updateValue("url", d)
                    }(r = (r = r.sessionData) && r.itct) && e.api.setTrackingParams(e.element, r)
                }
                c++
            }
            this.stills.length = c
        }
    };
    g.J.onVideoDataChange = function() {
        var l = this.player.getVideoData(1);
        this.videoData !== l && (l != null && g.cY(l) ? (this.videoData = l, this.ov()) : this.player.Gz("missg", {
            vid: (l == null ? void 0 : l.videoId) || "",
            cpn: (l == null ? void 0 : l.clientPlaybackNonce) || ""
        }))
    };
    g.J.Yj = function() {
        return this.D.u5()
    };
    g.J.Zq = function(l) {
        l === 1 ? (this.T = !1, this.K = this.videoData.clientPlaybackNonce, this.D.qr(), this.Ag && this.ov()) : (this.T = !0, this.Ag && fT(this) && (l === 2 ? this.D.lX() : l === 3 && this.D.D0()))
    };
    g.J.Qo = function(l) {
        if (l) {
            for (l = 0; l < this.stills.length; l++) this.V.logVisibility(this.stills[l].element, !0);
            this.Zq(1)
        } else this.K = null, this.T = !1;
        this.ov()
    };
    g.J.yF = function() {
        return this.Ag && fT(this)
    };
    g.P(DgU, dc);
    DgU.prototype.df = function() {
        var l = this.player.getVideoData();
        this.D.update({
            profilePicture: l.profilePicture,
            author: l.author
        });
        this.subscribeButton.channelId = l.NZ;
        var c = this.subscribeButton;
        l.subscribed ? c.D() : c.G()
    };
    g.P(bK, g.B);
    bK.prototype.select = function() {
        this.api.vn(this.suggestion.videoId, this.suggestion.sessionData, this.suggestion.playlistId, void 0, void 0, this.suggestion.Qy || void 0) && this.api.logClick(this.element)
    };
    bK.prototype.onClick = function(l) {
        if (g.h2(this.api.L()) && this.api.B("web_player_log_click_before_generating_ve_conversion_params")) {
            this.api.logClick(this.element);
            var c = this.suggestion.If(),
                Y = {};
            g.T$(this.api, Y);
            c = g.Il(c, Y);
            g.yF(c, this.api, l)
        } else g.d2(l, this.api, this.G, this.suggestion.sessionData || void 0) && this.select()
    };
    bK.prototype.onKeyPress = function(l) {
        switch (l.keyCode) {
            case 13:
            case 32:
                l.defaultPrevented || (this.select(), l.preventDefault())
        }
    };
    bK.prototype.onVideoDataChange = function() {
        var l = this.api.getVideoData(),
            c = this.api.L();
        this.G = l.UG ? !1 : c.T
    };
    g.P(qv, dc);
    g.J = qv.prototype;
    g.J.create = function() {
        dc.prototype.create.call(this);
        var l = this.player.getVideoData();
        l && (this.videoData = l);
        this.UQ();
        this.G.Z(this.player, "appresize", this.UQ);
        this.G.Z(this.player, "onVideoAreaChange", this.UQ);
        this.G.Z(this.player, "videodatachange", this.onVideoDataChange);
        this.G.Z(this.player, "autonavchange", this.Ev);
        this.G.Z(this.player, "onAutonavCancelled", this.zk);
        l = this.videoData.autonavState;
        l !== this.j && this.Ev(l);
        this.G.Z(this.element, "transitionend", this.wI)
    };
    g.J.destroy = function() {
        g.HJ(this.G);
        g.ON(this.stills);
        this.stills = [];
        dc.prototype.destroy.call(this);
        g.yu(this.element, "ytp-show-tiles");
        this.C.stop();
        this.j = this.videoData.autonavState
    };
    g.J.Nz = function() {
        return this.videoData.autonavState !== 1
    };
    g.J.show = function() {
        var l = this.Ag;
        dc.prototype.show.call(this);
        g.yu(this.element, "ytp-show-tiles");
        this.player.L().G ? g.AL(this.C) : this.C.start();
        (this.W || this.T && this.T !== this.videoData.clientPlaybackNonce) && g.Hx(this.player, !1);
        aK(this) ? (Nv(this), this.videoData.autonavState === 2 ? this.player.getVisibilityState() === 3 ? this.D.select(!0) : this.D.lX() : this.videoData.autonavState === 3 && this.D.D0()) : (g.Hx(this.player, !0), Nv(this));
        l !== this.Ag && this.player.logVisibility(this.element, !0)
    };
    g.J.hide = function() {
        var l = this.Ag;
        dc.prototype.hide.call(this);
        this.D.D0();
        Nv(this);
        l !== this.Ag && this.player.logVisibility(this.element, !1)
    };
    g.J.wI = function(l) {
        l.target === this.element && this.UQ()
    };
    g.J.UQ = function() {
        var l, c, Y, X;
        var k = ((l = this.videoData) == null ? 0 : (c = l.suggestions) == null ? 0 : c.length) ? (Y = this.videoData) == null ? void 0 : Y.suggestions : [(X = this.videoData) == null ? void 0 : g.cY(X)];
        if (k.length) {
            g.Jj(this.element, "ytp-endscreen-paginate");
            var r = this.V.ag(!0, this.V.isFullscreen());
            if (l = g.qu(this.V)) l = l.oD() ? 48 : 32, r.width -= l * 2;
            var e = r.width / r.height;
            X = 96 / 54;
            c = l = 2;
            var d = Math.max(r.width / 96, 2),
                y = Math.max(r.height / 54, 2);
            Y = k.length;
            var O = Y * 4;
            for (O -= 4; O > 0 && (l < d || c < y);) {
                var D = l / 2,
                    t = c / 2,
                    U = l <= d - 2 && O >=
                    t * 4,
                    G = c <= y - 2 && O >= D * 4;
                if ((D + 1) / t * X / e > e / (D / (t + 1) * X) && G) O -= D * 4, c += 2;
                else if (U) O -= t * 4, l += 2;
                else if (G) O -= D * 4, c += 2;
                else break
            }
            X = !1;
            O >= 12 && Y * 4 - O <= 6 && (c >= 4 || l >= 4) && (X = !0);
            O = l * 96;
            d = c * 54;
            e = O / d < e ? r.height / d : r.width / O;
            e = Math.min(e, 2);
            O = Math.floor(Math.min(r.width, O * e));
            d = Math.floor(Math.min(r.height, d * e));
            r = this.table.element;
            r.ariaLive = "polite";
            g.Ne(r, O, d);
            g.dg(r, {
                marginLeft: O / -2 + "px",
                marginTop: d / -2 + "px"
            });
            this.D.B4(g.cY(this.videoData));
            this.D instanceof eY && JK(this.D);
            g.DK(this.element, "ytp-endscreen-takeover",
                aK(this));
            Nv(this);
            O += 4;
            d += 4;
            e = 0;
            r.ariaBusy = "true";
            for (y = 0; y < l; y++)
                for (D = 0; D < c; D++)
                    if (t = e, G = 0, X && y >= l - 2 && D >= c - 2 ? G = 1 : D % 2 === 0 && y % 2 === 0 && (D < 2 && y < 2 ? D === 0 && y === 0 && (G = 2) : G = 2), t = g.qU(t + this.K, Y), G !== 0) {
                        U = this.stills[e];
                        U || (U = new bK(this.player), this.stills[e] = U, r.appendChild(U.element));
                        var f = Math.floor(d * D / c),
                            a = Math.floor(O * y / l),
                            p = Math.floor(d * (D + G) / c) - f - 4,
                            S = Math.floor(O * (y + G) / l) - a - 4;
                        g.Pq(U.element, a, f);
                        g.Ne(U.element, S, p);
                        g.dg(U.element, "transitionDelay", (D + y) / 20 + "s");
                        g.DK(U.element, "ytp-videowall-still-mini",
                            G === 1);
                        g.DK(U.element, "ytp-videowall-still-large", G > 2);
                        G = Math.max(S, p);
                        g.DK(U.element, "ytp-videowall-still-round-large", G >= 256);
                        g.DK(U.element, "ytp-videowall-still-round-medium", G > 96 && G < 256);
                        g.DK(U.element, "ytp-videowall-still-round-small", G <= 96);
                        t = k[t];
                        U.suggestion !== t && (U.suggestion = t, G = U.api.L(), f = g.kV(U.element, "ytp-videowall-still-large") ? "hqdefault.jpg" : "mqdefault.jpg", kd(U, t, f), g.h2(G) && !U.api.B("web_player_log_click_before_generating_ve_conversion_params") && (G = t.If(), f = {}, g.Uz(U.api, "addEmbedsConversionTrackingParams", [f]), G = g.Il(G, f), U.updateValue("url", G)), (t = (t = t.sessionData) && t.itct) && U.api.setTrackingParams(U.element, t));
                        e++
                    }
            r.ariaBusy = "false";
            g.DK(this.element, "ytp-endscreen-paginate", e < Y);
            for (k = this.stills.length - 1; k >= e; k--) l = this.stills[k], g.DI(l.element), g.y7(l);
            this.stills.length = e
        }
    };
    g.J.onVideoDataChange = function() {
        var l = this.player.getVideoData(1);
        this.videoData !== l && (l != null && g.cY(l) ? (this.K = 0, this.videoData = l, this.UQ()) : this.player.Gz("missg", {
            vid: (l == null ? void 0 : l.videoId) || "",
            cpn: (l == null ? void 0 : l.clientPlaybackNonce) || ""
        }))
    };
    g.J.xv = function() {
        this.K += this.stills.length;
        this.UQ()
    };
    g.J.gI = function() {
        this.K -= this.stills.length;
        this.UQ()
    };
    g.J.Yj = function() {
        return this.D.u5()
    };
    g.J.Ev = function(l) {
        l === 1 ? (this.W = !1, this.T = this.videoData.clientPlaybackNonce, this.D.qr(), this.Ag && this.UQ()) : (this.W = !0, this.Ag && aK(this) && (l === 2 ? this.D.lX() : l === 3 && this.D.D0()))
    };
    g.J.zk = function(l) {
        if (l) {
            for (l = 0; l < this.stills.length; l++) this.V.logVisibility(this.stills[l].element, !0);
            this.Ev(1)
        } else this.T = null, this.W = !1;
        this.UQ()
    };
    g.J.yF = function() {
        return this.Ag && aK(this)
    };
    g.P(pT, dc);
    pT.prototype.hasSuggestions = function() {
        var l;
        return (l = this.D) == null ? void 0 : l.hasSuggestions()
    };
    pT.prototype.show = function() {
        if (this.player.getPlayerState() !== 3) {
            dc.prototype.show.call(this);
            var l = this.G;
            if (l) {
                var c = this.D.hasSuggestions();
                g.DK(this.element, "ytp-shorts-branded-ui", c);
                c ? l.show() : l.hide()
            }
            var Y;
            (Y = g.qu(this.player)) == null || Y.NI(!0);
            this.player.logVisibility(this.element, !0);
            this.watchButton.UV(!0)
        }
    };
    pT.prototype.hide = function() {
        dc.prototype.hide.call(this);
        var l;
        (l = g.qu(this.player)) == null || l.NI(!1);
        this.player.logVisibility(this.element, !1);
        this.watchButton.UV(!1)
    };
    g.P(f9E, g.GH);
    g.J = f9E.prototype;
    g.J.PH = function() {
        var l = this.player.getVideoData(),
            c = l.mutedAutoplay && (l.limitedPlaybackDurationInSeconds > 0 || l.endSeconds > 0 || l.mutedAutoplayDurationMode !== 2);
        if ((this.player.isEmbedsShortsMode() || this.G) && !c) return !0;
        var Y;
        var X = !!((l == null ? 0 : g.cY(l)) || (l == null ? 0 : (Y = l.suggestions) == null ? 0 : Y.length));
        X = !tDQ(this.player) || X;
        l = l.PK;
        Y = this.player.MY();
        return X && !l && !Y && !c
    };
    g.J.yF = function() {
        return this.endScreen.yF()
    };
    g.J.Sdf = function() {
        return this.yF() ? this.endScreen.Yj() : !1
    };
    g.J.Tz = function() {
        this.player.EU("endscreen");
        g.GH.prototype.Tz.call(this)
    };
    g.J.load = function() {
        var l = this.player.getVideoData();
        var c = l.transitionEndpointAtEndOfStream;
        if (c && c.videoId) {
            var Y = this.player.wB().AV.get("heartbeat"),
                X = g.cY(l);
            !X || c.videoId !== X.videoId || l.cB ? (this.player.vn(c.videoId, void 0, void 0, !0, !0, c), Y && Y.lY("HEARTBEAT_ACTION_TRIGGER_AT_STREAM_END", "HEARTBEAT_ACTION_TRANSITION_REASON_HAS_NEW_STREAM_TRANSITION_ENDPOINT"), l = !0) : l = !1
        } else l = !1;
        l || (g.GH.prototype.load.call(this), this.endScreen.show())
    };
    g.J.unload = function() {
        g.GH.prototype.unload.call(this);
        this.endScreen.hide();
        this.endScreen.destroy()
    };
    g.J.onCueRangeEnter = function(l) {
        this.PH() && (this.endScreen.created || this.endScreen.create(), l.getId() === "load" && this.load())
    };
    g.J.onCueRangeExit = function(l) {
        l.getId() === "load" && this.loaded && this.unload()
    };
    g.J.onVideoDataChange = function() {
        GFU(this);
        this.T && Ug6(this) && (this.endScreen && (this.endScreen.hide(), this.endScreen.created && this.endScreen.destroy(), this.endScreen.dispose()), this.D ? this.endScreen = new Ok(this.player) : this.endScreen = new qv(this.player), g.Z(this, this.endScreen), g.oD(this.player, this.endScreen.element, 4))
    };
    g.U$("endscreen", f9E);
})(_yt_player);